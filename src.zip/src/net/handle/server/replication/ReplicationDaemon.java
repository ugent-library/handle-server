/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
 \*************************************************************************/
package net.handle.server.replication;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import net.cnri.util.FastDateFormat;
import net.cnri.util.StreamTable;
import net.cnri.util.StreamVector;
import net.cnri.util.StringUtils;
import net.handle.hdllib.AbstractMessage;
import net.handle.hdllib.AbstractResponse;
import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.Common;
import net.handle.hdllib.DumpHandlesCallback;
import net.handle.hdllib.DumpHandlesRequest;
import net.handle.hdllib.DumpHandlesResponse;
import net.handle.hdllib.GenericRequest;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.HandleResolver;
import net.handle.hdllib.HandleStorage;
import net.handle.hdllib.HandleValue;
import net.handle.hdllib.PublicKeyAuthenticationInfo;
import net.handle.hdllib.ReplicationDaemonInterface;
import net.handle.hdllib.RetrieveTxnRequest;
import net.handle.hdllib.RetrieveTxnResponse;
import net.handle.hdllib.SecretKeyAuthenticationInfo;
import net.handle.hdllib.ServerInfo;
import net.handle.hdllib.SiteInfo;
import net.handle.hdllib.Transaction;
import net.handle.hdllib.TransactionCallback;
import net.handle.hdllib.Util;
import net.handle.server.HandleServer;
import net.handle.server.Main;
import net.handle.server.ServerLog;

/*****************************************************************************
 * Thread that retrieves handle transactions from the primary servers or 
 * some other source of transactions, according to the server configuration.
 *****************************************************************************/
public class ReplicationDaemon
extends Thread implements ReplicationDaemonInterface
{
    public static final String REPLICATION_INTERVAL = "replication_interval";
    public static final String REPLICATION_AUTH = "replication_authentication";
    public static final String REPLICATION_VALIDATOR_CLASS = "replication_validator_class";
    public static final String REPLICATION_COPY_TRANSACTIONS = "replication_copy_transactions";
    public static final String REPLICATION_SERVER_INFO_FILE = "txnsrcsv.bin";
    public static final String REPLICATION_STATUS_FILE = "txnstat.dct";
    public static final String REPLICATION_PRIV_KEY_FILE = "replpriv.bin";
    public static final String REPLICATION_SECRET_KEY_FILE = "replsec.bin";
    public static final String REPLICATION_TIMEOUT = "replication_timeout";
    public static final String REPLICATION_SITES_HANDLE = "replication_sites_handle";
    public static final String REPLICATION_SOURCES = "sources";
    public static final String LAST_TXN_ID = "last_txn_id";
    public static final String LAST_TIMESTAMP = "last_timestamp";
    
    public volatile boolean keepRunning = true;
    private ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    
    private int replicationTimeout = 300000;  // default timeout of 5 minutes
    private File replicationStatusFile = null;
    private AuthenticationInfo replicationAuth;
    private MultiReplicationSiteInfo replicationSites;
    // time between replication refreshes default: 3 minutes
    private long replicationInterval = 3 * 60 * 1000;  

    private boolean initializedReplicationStatus = false;
    
    private Main main;
    private HandleServer server;
    private boolean caseSensitive;
    private SiteInfo thisSite;
    private int thisServerNum;

    private HandleResolver retrievalResolver = new HandleResolver();
    
    private final ReplicationValidator replicationValidator;
    private final boolean replicationCopyTransactions;

    public ReplicationDaemon(Main main, HandleServer server, StreamTable config, File configDir) throws HandleException, IOException, InvalidKeySpecException {
        this.main = main;
        this.server = server;
        this.thisSite = server.getSiteInfo();
        this.thisServerNum = server.getServerNum();
        this.caseSensitive = config.getBoolean(HandleServer.CASE_SENSITIVE);
        this.redumpNeededFile = new File(configDir, "SERVER_NEEDS_REDUMP.txt");
        
        this.replicationCopyTransactions = config.getBoolean(REPLICATION_COPY_TRANSACTIONS,false);
        
        if(config.containsKey(REPLICATION_TIMEOUT))
            replicationTimeout =
                Integer.parseInt(String.valueOf(config.get(REPLICATION_TIMEOUT)));
        else
            replicationTimeout = 5*60*1000; // default replication timeout is 5 mins
        retrievalResolver.setTcpTimeout(replicationTimeout);

        retrievalResolver.traceMessages = main.getResolver().traceMessages;
        
        if(config.containsKey(REPLICATION_INTERVAL)) {
            String repIntStr = String.valueOf(config.get(REPLICATION_INTERVAL));
            try {
                replicationInterval = Long.parseLong(repIntStr);
            } catch (Exception e) {
                System.err.println("Error: invalid replication interval \""+repIntStr+
                        "\"; using default: "+replicationInterval+" milliseconds");
            }
        }

        if(config.containsKey(REPLICATION_VALIDATOR_CLASS)) {
            try {
                String rvClassName = String.valueOf(config.get(REPLICATION_VALIDATOR_CLASS)).trim();
                Class rvClass = Class.forName(rvClassName);
                Object obj = rvClass.newInstance();
                replicationValidator = (ReplicationValidator)obj;
                replicationValidator.setServer(server);
            }
            catch(Exception e) {
                throw new HandleException(HandleException.INVALID_VALUE,"Error setting up replication validator",e);
            }
        }
        else {
            replicationValidator = null;
        }
        
        if(config.containsKey(REPLICATION_AUTH)) {
            String replAuthSpec = config.getStr(REPLICATION_AUTH,"");
            String replFields[] = StringUtils.split(replAuthSpec,':');
            if(replFields.length<3) 
                throw new HandleException(HandleException.INVALID_VALUE,
                        "Invalid replication auth descriptor: "+
                        replAuthSpec);
            int replHdlIdx = Integer.parseInt(replFields[1]);
            if(replFields[0].equals("privatekey")) {
                // private key replication
                byte passphrase[] = null;

                File privKeyFile = new File(configDir,REPLICATION_PRIV_KEY_FILE);
                byte privKeyBytes[] = new byte[(int)privKeyFile.length()];
                FileInputStream in = new FileInputStream(privKeyFile);
                int r=0;
                int n=0;
                while(n < privKeyBytes.length && 
                        ((r = in.read(privKeyBytes,n,privKeyBytes.length-n)) >= 0))
                    n += r;

                try {
                    if (Util.requiresSecretKey(privKeyBytes)) {
                        passphrase = Util.getPassphrase("Enter the passphrase for this servers replication private key: ");
                    }
                    privKeyBytes = Util.decrypt(privKeyBytes, passphrase);
                } catch (Exception e) {
                    throw new HandleException(HandleException.INVALID_VALUE,
                            "Error decrypting private key: "+e);
                } finally {
                    if (passphrase != null)
                        for(int i=0; i<passphrase.length; i++) passphrase[i] = (byte)0;
                }

                AuthenticationInfo info = null;
                replicationAuth = new 
                PublicKeyAuthenticationInfo(Util.encodeString(replFields[2]), replHdlIdx,
                        Util.getPrivateKeyFromBytes(privKeyBytes,0));
            } else if(replAuthSpec.startsWith("secretkey:")) {
                File secKeyFile = new File(configDir,REPLICATION_SECRET_KEY_FILE);
                byte secKeyBytes[] = new byte[(int)secKeyFile.length()];
                FileInputStream in = new FileInputStream(secKeyFile);
                int r=0;
                int n=0;
                while(n < secKeyBytes.length &&
                        ((r = in.read(secKeyBytes, n, secKeyBytes.length-n)) >=0 ))
                    n += r;

                replicationAuth = new
                SecretKeyAuthenticationInfo(Util.encodeString(replFields[2]), replHdlIdx,
                        secKeyBytes);
            } else {
                throw new HandleException(HandleException.INVALID_VALUE,
                        "Unknown authentication type: "+replFields[0]);
            }
        } else {
            throw new HandleException(HandleException.INVALID_VALUE,
                    "Servers using replication need to specify "+
            "replication authentication information");
        }

        String replicationSitesHandle = config.getStr(REPLICATION_SITES_HANDLE,null);
        boolean sitesFromHandle = false;
        if(replicationSitesHandle==null || "".equals(replicationSitesHandle)) {
            // need to read the replication source information here....
            // this needs to be read from a file that it can be written back
            // to after it is updated dynamically.  The configuration should
            // include the servers public key information so that it can be
            // authenticated as the true source of the transaction handles.

            // read the primary (or replication source) site information from
            // the appropriate file.  I used a site info record because we
            // basically need all of the site info (public key, admin ports, etc)
            // and there's no sense in specifying a different config file layout
            // just for this
            File replicationSvrInfoFile = 
                new File(configDir,REPLICATION_SERVER_INFO_FILE);

            if(!replicationSvrInfoFile.exists()) {
                throw new HandleException(HandleException.CONFIGURATION_ERROR,
                        "No replication site found ("+
                        replicationSvrInfoFile+")");
            }

            replicationSites = MultiReplicationSiteInfo.fromFile(replicationSvrInfoFile);
        }
        else {
            sitesFromHandle = true;
            replicationSites = MultiReplicationSiteInfo.fromHandle(replicationSitesHandle,
                                                                   retrievalResolver,
                                                                   thisSite.servers[thisServerNum],
                                                                   this.server);
        }
  
// wait for this
//        replicationSites.refreshSiteInfo();

        // Read in the status of the replication.  This should set
        // the default values for the replication status if the 
        // status file doesn't exist.
        replicationStatusFile = 
            new File(configDir,REPLICATION_STATUS_FILE);
        
        // last transaction dates database
        if(thisSite.isPrimary || sitesFromHandle) {
            replicationDb = new ReplicationDb(configDir, main);
        }
    }

    private void loadInitialReplicationStatus() {
        if(replicationStatusFile.exists()) {
            try {
                StreamTable replicationConfig = new StreamTable();
                replicationConfig.readFromFile(replicationStatusFile);
                replicationSites.loadReplicationStatus(replicationConfig);
            }
            catch (Exception e) {
                main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                        "Exception while reading replication status information: " + e);
                e.printStackTrace();

            }
        }
    }

    public StreamTable replicationStatus() throws HandleException {
        if(replicationSites==null) return null;
        return replicationSites.replicationStatus();
    }
    
    private void saveReplicationInfo()
    throws HandleException
    {
        try {
            StreamTable replicationConfig = replicationSites.replicationStatus();
            replicationConfig.writeToFile(replicationStatusFile);
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            if(e instanceof HandleException)
                throw (HandleException)e;
            throw new HandleException(HandleException.INTERNAL_ERROR,
                    "Error saving replication state: "+e);
        }
    }

    
    
    public void dumpHandles(boolean deleteAll) 
    throws HandleException, IOException
    {
      // TODO Auto-generated method stub
      // allow hot-update of replication site information
      replicationSites.refreshSiteInfo();
      
      // Talk to each of the primary servers (or replication source servers)
      // to find the fastest-responding one.
      int siteCount = 0;
      Iterator iter = replicationSites.iterator();
      ReplicationSiteInfo replInfo = null;
      ArrayList<SiteTiming> timings = new ArrayList<SiteTiming>();
      while(iter.hasNext()) {
        replInfo = (ReplicationSiteInfo)iter.next();
        
        // Don't try replicating from a secondary.  Keep information about it
        // in case it is ever upgraded to a primary.
        if(replInfo.site==null || !replInfo.site.isPrimary) continue;
        
        timings.add(new SiteTiming(replInfo).getTiming());
      }
      
      if(timings.size()<=0) {
        throw new HandleException(HandleException.SERVICE_NOT_FOUND,
                                  "No primary servers found for handle dump");
      }
      
      Collections.sort(timings);
      System.err.println("Dump site timings:");
      for(SiteTiming timing : timings) {
        System.err.println("  "+timing);
      }
      
      // stop doing all replication
      pauseReplication();
      try {
          dumpHandlesFromSite(timings.get(0).replSite, deleteAll);
      }
      finally {
          unpauseReplication();
      }
    }
    
    
    private class SiteTiming implements Comparable {
      ReplicationSiteInfo replSite;
      long responseTime = Integer.MAX_VALUE;
      
      SiteTiming(ReplicationSiteInfo replSite) {
        this.replSite = replSite;
        this.responseTime = -1;
        getTiming();
      }
      
      public String toString() {
        return "time="+responseTime+" ms;  site="+replSite.site;
      }
      
      public SiteTiming getTiming() {
        responseTime = Integer.MAX_VALUE;
        long startTime = System.currentTimeMillis();
        try {
          GenericRequest req = new GenericRequest(Common.BLANK_HANDLE, 
                                                  AbstractMessage.OC_GET_SITE_INFO, 
                                                  null);
          AbstractResponse resp = retrievalResolver.sendRequestToSite(req, replSite.site);
          if(resp.responseCode!=AbstractResponse.RC_SUCCESS) {
            responseTime = Integer.MAX_VALUE - 1;
          } else {
            responseTime = System.currentTimeMillis() - startTime;
          }
        } catch (Throwable t) {
          System.err.println("Error timing connection to site: "+replSite.site);
        }
        return this;
      }
      
      public int compareTo(Object o) {
        if(!(o instanceof SiteTiming)) return Integer.MAX_VALUE;
        return (int)(responseTime - ((SiteTiming)o).responseTime);
      }
    }
    
    public void pauseReplication() {
        readWriteLock.readLock().lock();
    }
    
    public void unpauseReplication() {
        readWriteLock.readLock().unlock();
    }
    
    public synchronized void run() {
        while(keepRunning) {
            readWriteLock.writeLock().lock();
            try {
                ReplicationSiteInfo replInfo = null;
                ArrayList<SiteInfo> redumpSites = null;

                try {
                    // allow hot-update of replication site information
                    replicationSites.refreshSiteInfo();
                    if(!initializedReplicationStatus) {
                        loadInitialReplicationStatus();
                        initializedReplicationStatus = true;
                    }

                    // Talk to each one of the primary servers (or replication source
                    // servers) and retrieve any transactions that we don't have.
                    int siteCount = 0;
                    Iterator iter = replicationSites.iterator();
                    int primarySites = 0;
                    while(iter.hasNext()) {
                        siteCount++;
                        replInfo = (ReplicationSiteInfo)iter.next();
 
                        // Don't try replicating from a secondary.  Keep information about it
                        // in case it is ever upgraded to a primary.
                        if(replInfo.site==null || !replInfo.site.isPrimary) continue;
                        primarySites++;
                        
                        TxnCallback callback = new TxnCallback(replInfo);
                        for(int i=0; i<replInfo.site.servers.length; i++) {

                            // skip any sites that can't possibly have any handles that hash to this server
                            ServerInfo replServer = replInfo.site.servers[i];
                            if(replInfo.site.hashOption==thisSite.hashOption &&
                                    replInfo.site.servers.length==thisSite.servers.length &&
                                    thisServerNum!=i) {
                                continue;
                            }

                            RetrieveTxnRequest req = 
                                new RetrieveTxnRequest(replInfo.lastTxnIds[i],
                                        replInfo.lastTimeStamps[i],
                                        thisSite.hashOption, 
                                        thisSite.servers.length, 
                                        thisServerNum, replicationAuth);
                            req.encrypt = false;
                            req.certify = true;
                            req.setSupportedProtocolVersion(replInfo.site);

                            try {
                                AbstractResponse res = 
                                    retrievalResolver.sendRequestToServer(req,replInfo.site,replInfo.site.servers[i]);

                                if(res.responseCode==AbstractMessage.RC_SUCCESS) {
                                    callback.setServerNum(i);                

                                    // decode the public key to authenticate the stream
                                    PublicKey pubKey = replInfo.site.servers[i].getPublicKey();

                                    long originalTimestamp = replInfo.lastTimeStamps[i];
                                    int status = ((RetrieveTxnResponse)res).processStreamedPart(callback, pubKey);

                                    if(status==RetrieveTxnResponse.NEED_TO_REDUMP) {
                                        System.err.println("------------------------------------------------------------\n" +
                                                "CRITICAL: REDUMP NEEDED response from site: "+replInfo.site.servers[i] + 
                                        "------------------------------------------------------------");
                                        if(redumpSites==null) redumpSites = new ArrayList<SiteInfo>();
                                        redumpSites.add(replInfo.site);
                                        callback.finishProcessing(originalTimestamp);
                                    } else if(status==RetrieveTxnResponse.SENDING_TRANSACTIONS) {
                                        saveReplicationInfo();
                                    } else {
                                        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                                                "Unknown status code from server during replication: "+
                                                status);
                                    }

                                } else {
                                    main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                                            "Unexpected response to replication request: "+res);
                                }

                                // this doesn't handle wrap-around serial numbers - maybe it should.
                                // but the numbers can go so large it shouldn't matter.
                                // The date/time/seconds could be used.

                                // if site info is not stored locally (e.g. it's in a handle), we take no action here.
                                if(res.siteInfoSerial > replInfo.site.serialNumber && replicationSites.siteInfoIsLocal()) {
                                    main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                                            "Updating replication info from version "+
                                            replInfo.site.serialNumber+" to version "+
                                            res.siteInfoSerial);
                                    replInfo.getNewSiteInfoFromServers(retrievalResolver, replicationAuth);
                                    saveReplicationInfo();
                                    replicationSites.saveSiteInfo();
                                    break;
                                }

                            } catch (HandleException e) {
                                main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                                        "Error doing replication at server: "+
                                        replInfo.site.servers[i]+": "+e);
                                if(e.getCode() != HandleException.CANNOT_CONNECT_TO_SERVER) e.printStackTrace(System.err);
                            }

                            updateRedumpIsNeededStatus(redumpSites);
                        }
                    }
                    if(primarySites==0) {
                        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "No primary sites found to replicate!");
                    }
                } catch (Throwable t) {
                    main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "Error in replication daemon: "+t);
                    t.printStackTrace(System.err);
                }
            }      
            finally {
                readWriteLock.writeLock().unlock();
            }
            
            try {
                // sleep for one minute
                Thread.sleep(replicationInterval);
            } catch (Throwable e) {
                main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                        "Error sleeping in replication thread: "+e);
            }
        }
    }
    
    
    private File redumpNeededFile;
    
    private void updateRedumpIsNeededStatus(ArrayList<SiteInfo> redumpSites) {
      if(redumpSites==null || redumpSites.size()==0) { // no redump is needed
        if(redumpNeededFile.exists()) {
          redumpNeededFile.delete();
        }
      } else { // a redump is needed... make sure somebody knows about it
        PrintWriter out = null;
        try {
          out = new PrintWriter(redumpNeededFile);
          out.println("******************************************************************");
          out.println("*                 REPLICATION IS OUT OF SYNC                     *");
          out.println("******************************************************************");
          out.println("The following primary servers report that our replication with");
          out.println("them is out of date: ");
          
          for(SiteInfo site : redumpSites) {
            out.println("Site: "+site);
          }
          out.println("******************************************************************");
          out.close();
        } catch (IOException e) {
          System.err.println("Error updating redump-needed file: "+redumpNeededFile.getPath());
        } finally {
          try { out.close(); } catch (Throwable t) {}
        }
      }
    }
    
    
    public void shutdown() {
        keepRunning = false;
        try {
            if(replicationDb!=null) replicationDb.shutdown();
        }
        catch (Throwable e) {}
    }

    private ReplicationDb replicationDb;
    
    public long adjustAndSetLastCreateOrDeleteDate(byte[] handle, long date, int priority) throws HandleException {
        if(replicationDb!=null) return replicationDb.adjustAndSetLastDate(handle,date,priority,false);
        return date;
    }

    public long adjustAndSetLastHomeOrUnhomeDate(byte[] handle, long date, int priority) throws HandleException {
        if(replicationDb!=null) return replicationDb.adjustAndSetLastDate(handle,date,priority,true);
        return date;
    }
    
    public Iterator/*<byte[]>*/ handleIterator() {
        if(replicationDb!=null) return replicationDb.iterator(false);
        else return Collections.EMPTY_LIST.iterator();
    }
    public Iterator/*<byte[]>*/ naIterator() {
        if(replicationDb!=null) return replicationDb.iterator(true);
        else return Collections.EMPTY_LIST.iterator();
    }
    


    public synchronized void dumpHandlesFromSite(ReplicationSiteInfo replInfo) throws HandleException {
        dumpHandlesFromSite(replInfo,true);
    }
    
    /**
     * Delete all handles in the containing server and perform a redump from a 
     * server using the given replication information.
     * 
     * @param replInfo the replication information for this server
     * @throws HandleException
     */
    public synchronized void dumpHandlesFromSite(ReplicationSiteInfo replInfo, boolean deleteAll) 
      throws HandleException
    {
      
      if(replInfo==null || replInfo.site==null) {
        throw new NullPointerException("attempt to dump handles using a null ReplicationSiteInfo");
      }
      
      try {
        System.err.println("------------------------------\n"+
                           "---- REDUMPING HANDLES!!! ----\n"+
                           "------------------------------");
        
        server.disable();
        
        // indicate that all servers need to be dumped - 
        // in case we get interrupted
        for(int i=0; i<replInfo.lastTimeStamps.length; i++) {
          replInfo.lastTimeStamps[i] = 0;
          replInfo.lastTxnIds[i] = 0;
        }
        
        // delete *all* handles
        // it's ok to delete all handles, because *sites* are
        // replicated, not naming authorities.
        if(deleteAll) {
            server.getStorage().deleteAllRecords();
            if(replicationDb!=null) replicationDb.deleteAll();
        }
        
        // send dump request to *all* primary servers,
        // this could/should be parallelized
        DumpHandlesRequest req = new DumpHandlesRequest(thisSite.hashOption,
                                                        thisSite.servers.length,
                                                        thisServerNum,
                                                        replicationAuth);
        
        req.setSupportedProtocolVersion(replInfo.site);
        // dump the entire handle database from each primary server in that site
        for(int i=0; i<replInfo.site.servers.length; i++) {
          
          // skip any sites that can't possibly have any handles that hash to this server
          ServerInfo replServer = replInfo.site.servers[i];
          if(replInfo.site.hashOption==thisSite.hashOption &&
              replInfo.site.servers.length==thisSite.servers.length &&
              thisServerNum!=i) {
            continue;
          }
          
          try {
              AbstractResponse response =
              retrievalResolver.sendRequestToServer(req, replInfo.site, replServer);
            
            if(response.responseCode==AbstractMessage.RC_SUCCESS) {
              ((DumpHandlesResponse)response).
              processStreamedPart(new DumpHdlCallback(replInfo,i),
                                  replInfo.site.servers[i].getPublicKey());
            } else {
              //System.err.println("Received non-success response to dump-handles message: "+response);
              throw new HandleException(HandleException.REPLICATION_ERROR,
                                        "Response code "+response.responseCode+":  "+AbstractMessage.getResponseCodeMessage(response.responseCode));
            }
          } catch (Exception dumpError) {
            System.err.println("Error dumping server "+i+": ");
            dumpError.printStackTrace();
            System.err.println("trying again...");
          }
        }
        
        // and then save new replication info.
        saveReplicationInfo();
        
        server.enable();
        System.err.println("------------------------------------\n"+
                           "---------- REDUMP FINISHED ---------\n"+
        "------------------------------------");
      } catch (Throwable e) {
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      "Error attempting to reload all handles: "+e);
        e.printStackTrace();
      }
    }
    

    /****************************************************************************
     * Class used to process the results of DumpHandlesRequest messages.  
     * Since that request type is streamable, this class is used as the
     * target for the callback.
     ****************************************************************************/
    class DumpHdlCallback
    implements DumpHandlesCallback
    {
        private int currentServerNum = -1;
        private ReplicationSiteInfo replInfo;

        DumpHdlCallback(ReplicationSiteInfo replInfo, int serverNum) {
            this.replInfo = replInfo;
            this.currentServerNum = serverNum;
            System.err.println("Starting dump of source server #"+serverNum);
        }

        public synchronized void addHandle(byte handle[], HandleValue values[])
        throws Exception
        {
            if(!caseSensitive)
                handle = Util.upperCase(handle);
            System.err.println("---> "+Util.decodeString(handle));
            try {
                server.getStorage().deleteHandle(handle);
            } catch (Exception e) {
                //System.err.println("Error deleting handle before re-add: "+e);
                //e.printStackTrace(System.err);
            }
            server.getStorage().createHandle(handle, values);
        }   

        public synchronized void addNamingAuthority(byte authHandle[])
        throws Exception
        {
            System.err.println("---NA> "+Util.decodeString(authHandle));
            server.getStorage().setHaveNA(authHandle, true);
        }

        public synchronized void processThisServerReplicationInfo(long date, long txnId) {
          System.err.println("----received replication status: server="+currentServerNum+" date="+
                             (new java.util.Date(date))+"; last txnId: "+txnId);
          replInfo.lastTimeStamps[currentServerNum] = date;
          replInfo.lastTxnIds[currentServerNum] = txnId;
        }
        
        public synchronized void processOtherSiteReplicationInfo(StreamTable otherReplicationConfig) throws HandleException {
            System.err.println("----getting replication info for other sites:");
            StreamTable thisReplicationConfig = replicationSites.replicationStatus();
            Enumeration iter = otherReplicationConfig.keys();
            Set/*<String>*/ seenKeys = new HashSet();
            boolean changed = false;
            while(iter.hasMoreElements()) {
                String key = (String)iter.nextElement();
                System.err.println("--------getting replication info for key: " + key);
                StreamVector otherVector = (StreamVector)otherReplicationConfig.get(key);
                StreamVector thisVector = (StreamVector)thisReplicationConfig.get(key);
                int size = otherVector.size();
                if(!seenKeys.contains(key) || thisVector==null || thisVector.size()!=size) {
                    thisReplicationConfig.put(key,otherVector);
                    changed = true;
                    seenKeys.add(key);
                }
                else {
                    for(int i = 0; i < size; i++) {
                        StreamTable otherTable = (StreamTable)otherVector.get(i);
                        StreamTable thisTable = (StreamTable)thisVector.get(i);
                        long otherLastTxnId = 
                            Long.parseLong(String.valueOf(otherTable.get(ReplicationDaemon.LAST_TXN_ID)));
                        long otherLastTimeStamp = 
                            Long.parseLong(String.valueOf(otherTable.get(ReplicationDaemon.LAST_TIMESTAMP)));
                        long thisLastTxnId = 
                            Long.parseLong(String.valueOf(thisTable.get(ReplicationDaemon.LAST_TXN_ID)));
                        long thisLastTimeStamp = 
                            Long.parseLong(String.valueOf(thisTable.get(ReplicationDaemon.LAST_TIMESTAMP)));
                        if(thisLastTimeStamp > otherLastTimeStamp || thisLastTxnId > otherLastTxnId) {
                            thisVector.set(i,otherTable);
                            changed = true;
                        }
                    }
                }
            }
            if(changed) {
                System.err.println("------saving new replication status");
                replicationSites.loadReplicationStatus(thisReplicationConfig);
                saveReplicationInfo();
            }
            System.err.println("------done.");
        }
        
        public synchronized void setLastCreateOrDeleteDate(byte[] handle, long date, int priority) throws HandleException {
            System.err.println("---(date)> "+Util.decodeString(handle));
            if(replicationDb!=null) replicationDb.setLastDate(handle,date,priority,false);
        }
        
        public synchronized void setLastHomeOrUnhomeDate(byte[] handle, long date, int priority) throws HandleException {
            System.err.println("---NA(date)> "+Util.decodeString(handle));
            if(replicationDb!=null) replicationDb.setLastDate(handle,date,priority,true);
        }
    }

    abstract class ReplicationRunnable {
        abstract void run() throws HandleException;
        void runIfMoreRecent(byte[] handle, long date, int priority, boolean isNA, byte action) throws HandleException {
            if(replicationDb==null) run();
            else {
                synchronized(replicationDb.getLock(isNA)) {
                    if(replicationDb.isMoreRecentThanLastDate(handle,date,priority,isNA)) {
                        run();
                        replicationDb.setLastDate(handle,date,priority,isNA);
                    }
                }
                if(replicationCopyTransactions && !server.insertTransaction(handle,action,date)) {
                    System.err.println("Error copying transaction: " + Util.decodeString(handle) + ", " + action  + ", " + FastDateFormat.formatUtc(date));
                }
            }
        }
    }

    /****************************************************************************
     * Class used to process the results of RetrieveTxnRequest messages.  
     * Since that request type is streamable, this class is used as the
     * target for the callback.
     ****************************************************************************/
    class TxnCallback 
    implements TransactionCallback 
    {
        private int currentServerNum = -1;
        private ReplicationSiteInfo replInfo;

        public TxnCallback(ReplicationSiteInfo replInfo) {
            this.replInfo = replInfo;
        }

        public void setServerNum(int newServerNum) {
            this.currentServerNum = newServerNum;
        }

        public void processTransaction(final Transaction txn) 
        throws HandleException
        {
            if(replicationValidator!=null && !replicationValidator.valid(txn)) {
                System.err.println("--Denied! "+txn);
            }
            else {
                final HandleStorage storage = server.getStorage();
                System.err.println("--Processing "+txn);
                final byte[] handle = caseSensitive ? txn.handle : Util.upperCase(txn.handle);
                switch(txn.action) {
                case Transaction.ACTION_CREATE_HANDLE:
                case Transaction.ACTION_UPDATE_HANDLE:
                    new ReplicationRunnable() {
                        void run() throws HandleException {
                            try {
                                storage.deleteHandle(handle);
                            } catch (Exception e) {
                                System.err.println("Error deleting handle before re-creating during replication: "+e);
                                e.printStackTrace(System.err);
                            }
                            storage.createHandle(handle,txn.values);
                        }
                    }.runIfMoreRecent(handle,txn.date,replInfo.priority(),false,txn.action);
                    break;
                case Transaction.ACTION_DELETE_HANDLE:
                    new ReplicationRunnable() {
                        void run() throws HandleException {
                            if(!storage.deleteHandle(handle)) {
                                main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                                        "Warning: got delete-handle transaction for non-existent handle: "+
                                                Util.decodeString(txn.handle));
                            }
                        }
                    }.runIfMoreRecent(handle,txn.date,replInfo.priority(),false,txn.action);
                    break;
                case Transaction.ACTION_HOME_NA:
                    new ReplicationRunnable() {
                        void run() throws HandleException {
                            storage.setHaveNA(handle, true);
                        }
                    }.runIfMoreRecent(handle,txn.date,replInfo.priority(),true,txn.action);
                    break;
                case Transaction.ACTION_UNHOME_NA:
                    new ReplicationRunnable() {
                        void run() throws HandleException {
                            storage.setHaveNA(handle, false);
                        }
                    }.runIfMoreRecent(handle,txn.date,replInfo.priority(),true,txn.action);
                    break;
                default:
                    main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "Encountered unknown transaction type ("+txn.action+
                            ") during replication for handle: "+
                            Util.decodeString(txn.handle));
                }
            }
            replInfo.lastTxnIds[currentServerNum] = txn.txnId;
        }

        public void finishProcessing(long date) {
            replInfo.lastTimeStamps[currentServerNum] = date;
        } 
    }


}
