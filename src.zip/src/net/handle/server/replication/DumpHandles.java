/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server.replication;

import java.io.File;

import net.cnri.util.StreamTable;
import net.handle.hdllib.HSG;
import net.handle.hdllib.Util;
import net.handle.server.Main;
import net.handle.server.ServerLog;
import net.handle.server.Version;

public class DumpHandles {
  
  
  private static void printUsage() {
    System.err.println("Usage: hdl-dumpfromprimary [-no-delete] <server-directory>");
  }
  

  
  
  public static void main(String[] argv) 
    throws Exception
    {
    Main main = null;
    String configDirStr = null;
    boolean deleteAll = true;
    
    if ((argv == null) || (argv.length > 2) || argv.length == 0) {
      printUsage();
      return;
    }
    
    if(argv.length==1) {
        configDirStr = argv[0];            // The only argument is the config-dir name
    } else {
        if("-no-delete".equals(argv[0])) {
            deleteAll = false;
            configDirStr = argv[1];
        } else if("-no-delete".equals(argv[1])) {
            deleteAll = false;
            configDirStr = argv[0];
        } else {
            printUsage();
            return;
        }
    }
        
    if (!Util.checkJavaVersion())
        return;

    StreamTable configTable = new StreamTable();
    // Get, check serverDir
    File serverDir = new File(configDirStr);
    
    if (!((serverDir.exists()) && (serverDir.isDirectory()))) {
      System.err.println("Invalid configuration directory: " + configDirStr + ".");
      return;
    }
    
    // Load configTable from the config file
    try {
      configTable.readFromFile(new File(serverDir, HSG.CONFIG_FILE_NAME));
    } catch (Exception e) {
      System.err.println("Error reading configuration: " + e);
      return;
    }
    
    // Create the Main server object and start it
    try {
      main = new Main(serverDir, configTable);
      main.logError(ServerLog.ERRLOG_LEVEL_INFO,"HANDLE.NET Server Software version " + Version.version);
      //main.initialize();
      main.dumpFromPrimary(deleteAll);
    } catch (Exception e) {
      e.printStackTrace(System.err);
      System.out.println("Error: " + e.getMessage());
      System.out.println("       (see the error log for details.)\n");
      System.out.println("Shutting down...");
      System.err.println("Shutting down...");
      try { main.shutdown(); } catch (Exception e2) { /* Ignore */ }
      System.exit(0);
    }
  }
  
  

  
}
