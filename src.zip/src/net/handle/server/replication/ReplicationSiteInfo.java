/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
 \*************************************************************************/
package net.handle.server.replication;

import java.io.IOException;
import java.util.Arrays;

import net.cnri.util.StreamTable;
import net.cnri.util.StreamVector;
import net.handle.hdllib.AbstractMessage;
import net.handle.hdllib.AbstractResponse;
import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.Common;
import net.handle.hdllib.Encoder;
import net.handle.hdllib.GenericRequest;
import net.handle.hdllib.GetSiteInfoResponse;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.HandleResolver;
import net.handle.hdllib.HandleValue;
import net.handle.hdllib.SiteInfo;

public class ReplicationSiteInfo {
    public SiteInfo site;
    public long[] lastTxnIds;
    public long[] lastTimeStamps;
    
    public ReplicationSiteInfo() {}

    public int priority() { return 0; }
    
    public void loadLastTxnStatus(StreamVector sources) {
      if(sources!=null && sources.size() == lastTxnIds.length) {
        for(int i = 0; i<lastTxnIds.length; i++) {
          StreamTable sourceTable = (StreamTable)sources.elementAt(i);
          lastTxnIds[i] = sourceTable.getLong(ReplicationDaemon.LAST_TXN_ID, 0);
          lastTimeStamps[i] = sourceTable.getLong(ReplicationDaemon.LAST_TIMESTAMP, 0);
        }
      } else {
        for(int i = 0; i<lastTxnIds.length; i++) {
          lastTxnIds[i] = 0;
          lastTimeStamps[i] = 0;
        }
      }
      System.err.println("Loaded replication site info " + this);
    }
    
    public StreamVector lastTxnStatus() {
        StreamVector sources = new StreamVector();
        for(int i=0; i<lastTxnIds.length; i++) {
            StreamTable sourceTable = new StreamTable();
            sourceTable.put(ReplicationDaemon.LAST_TXN_ID, lastTxnIds[i]);
            sourceTable.put(ReplicationDaemon.LAST_TIMESTAMP, lastTimeStamps[i]);
            sources.addElement(sourceTable);
        }
        return sources;
    }
    
    /** 
     * Retrieve updated site information from one of our existing sites.
     * @param resolver  the resolver to use for retrieving the new site info
     * @param replicationAuth the authentication to use to retrieve the new site info
     * */
    public void getNewSiteInfoFromServers(HandleResolver resolver, 
                                          AuthenticationInfo replicationAuth)
    throws IOException, HandleException
    {
      
      GenericRequest req = new GenericRequest(Common.BLANK_HANDLE,
                                              AbstractMessage.OC_GET_SITE_INFO,
                                              replicationAuth);
      req.setSupportedProtocolVersion(this.site);
      SiteInfo newSite = null;
      for(int i=0; newSite==null && i<this.site.servers.length; i++) {
        try {
          AbstractResponse response = 
            resolver.sendRequestToServer(req, this.site, this.site.servers[i]);
          if(response.responseCode==AbstractMessage.RC_SUCCESS) {
            newSite = ((GetSiteInfoResponse)response).siteInfo;
            if(newSite!=null) break;  // we only need to get the siteinfo from one server
          }
        } catch (HandleException e) {
          //                main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
          //                        "Unable to retrieve updated site info from server: "+
          //                        oldSiteInfo.servers[serverNum]);
        }
      }
      
      if(newSite==null) {
        throw new HandleException(HandleException.REPLICATION_ERROR,
                                  "Unable to update outdated site info!");
      }
      
      newSiteInfo(newSite);
    }
    
    
    public void newSiteInfo(SiteInfo newSiteInfo) {
        // adjust our current replication state to account for a potentially different
        // number of source servers.
        if(this.site!=null && sitesUseSameHashing(this.site,newSiteInfo)) {
            this.site = newSiteInfo;
        } else {      
            long minTxnID;
            long minTimeStamp;
            if(lastTxnIds==null) {
                minTxnID = -1;
                minTimeStamp = 0;
            }
            else {
                // if we already have a site, take the minimum transaction and timestamp for
                // each server 
                minTxnID = lastTxnIds[0];
                minTimeStamp = lastTimeStamps[0];
                for(int i=1; i < lastTxnIds.length; i++) {
                    if(lastTxnIds[i] < minTxnID) minTxnID = lastTxnIds[i];
                    if(lastTimeStamps[i] < minTimeStamp) minTimeStamp = lastTimeStamps[i];
                }
            }
            long newLastTxnIds[] = new long[newSiteInfo.servers.length];
            long newLastTS[] = new long[newSiteInfo.servers.length];
            Arrays.fill(newLastTxnIds, minTxnID);
            Arrays.fill(newLastTS, minTimeStamp);

            this.lastTxnIds = newLastTxnIds;
            this.lastTimeStamps = newLastTS;

            this.site = newSiteInfo;
        }
    }

    public boolean hasNoInformation() {
        if(lastTxnIds==null) return true;
        for(long n : lastTxnIds) {
            if(n>0) return false;
        }
        for(long n : lastTimeStamps) {
            if(n>0) return false;
        }
        return true;
    }
    
    private static boolean sitesUseSameHashing(SiteInfo a, SiteInfo b) {
        if(a.servers.length!=b.servers.length) return false;
        if(a.servers.length==1) return true;
        if(a.hashOption==b.hashOption) return true;
        return false;
    }
    
    @Override
    public String toString() {
        return "ReplicationSiteInfo [site=" + site + ", lastTxnIds=" + Arrays.toString(lastTxnIds) + ", lastTimeStamps=" + Arrays.toString(lastTimeStamps)
                + "]";
    }
    
    
}


class HandleValueReplicationSiteInfo extends ReplicationSiteInfo {
    HandleValue value;

    public HandleValueReplicationSiteInfo(HandleValue value) throws HandleException {
      refreshSiteInfo(value);
    }
    
    public int priority() { return value.getIndex(); }

    void refreshSiteInfo(HandleValue value) throws HandleException {
        if(this.value==null || this.value.getTimestamp() < value.getTimestamp()) {
            this.value = value;
            SiteInfo newSite = new SiteInfo();
            Encoder.decodeSiteInfoRecord(value.getData(), 0, newSite);
            newSiteInfo(newSite);
        }
    }

    @Override
    public String toString() {
        return "HandleValueReplicationSiteInfo [value.getIndex()=" + value.getIndex() + ", site=" + site + ", lastTxnIds="
                + Arrays.toString(lastTxnIds) + ", lastTimeStamps=" + Arrays.toString(lastTimeStamps) + "]";
    }
}
