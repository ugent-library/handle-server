/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
 \*************************************************************************/


package net.handle.server.replication;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.cnri.io.AtomicFile;
import net.cnri.util.StreamTable;
import net.cnri.util.StreamVector;
import net.handle.hdllib.Common;
import net.handle.hdllib.Encoder;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.HandleResolver;
import net.handle.hdllib.HandleValue;
import net.handle.hdllib.ServerInfo;
import net.handle.hdllib.SiteInfo;
import net.handle.hdllib.Util;
import net.handle.server.HandleServer;

public abstract class MultiReplicationSiteInfo {
    
    public abstract void refreshSiteInfo() throws IOException, HandleException;
    
    public abstract void saveSiteInfo() throws IOException, HandleException;
    
    public abstract void loadReplicationStatus(StreamTable replicationConfig) throws HandleException;
    
    public abstract StreamTable replicationStatus() throws HandleException;
    
    public abstract Iterator/*<ReplicationSiteInfo>*/ iterator();
    
    public abstract boolean siteInfoIsLocal();
    
    public static MultiReplicationSiteInfo fromFile(File file) throws IOException, HandleException {
        return new FileMultiReplicationSiteInfo(file);
    }
    
    public static MultiReplicationSiteInfo fromHandle(String handle, HandleResolver resolver, 
                                                      ServerInfo serverInfo, HandleServer server)
    throws HandleException {
        return new HandleMultiReplicationSiteInfo(handle, resolver, serverInfo, server);
    }
}

class FileMultiReplicationSiteInfo extends MultiReplicationSiteInfo {
    private File replicationSrvInfoFile;
    private ReplicationSiteInfo replInfo;
    private long timestamp;
    
    public FileMultiReplicationSiteInfo(File file) throws IOException, HandleException {
        replicationSrvInfoFile = file;
        replInfo = new ReplicationSiteInfo();
        refreshSiteInfo();
    }
    
    public Iterator iterator() {
        return new Iterator() {
            private boolean hasNext = true;
            public boolean hasNext() {
                return hasNext;
            }
            public Object next() {
                hasNext = false;
                return replInfo;
            }
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public void refreshSiteInfo() throws IOException, HandleException {
        if(replInfo.site == null || replicationSrvInfoFile.lastModified()>timestamp) {
            this.timestamp = replicationSrvInfoFile.lastModified();
            
            byte siteBuf[] = new AtomicFile(replicationSrvInfoFile).readFully();
            SiteInfo newSite = new SiteInfo();
            Encoder.decodeSiteInfoRecord(siteBuf, 0, newSite);
            replInfo.newSiteInfo(newSite);
        }
    }

    public void saveSiteInfo() throws IOException, HandleException {
        // write the new information to the site info file
        new AtomicFile(replicationSrvInfoFile).writeFully(Encoder.encodeSiteInfoRecord(replInfo.site));
    }

    public void loadReplicationStatus(StreamTable replicationConfig) {
        StreamVector sources = (StreamVector)replicationConfig.get(ReplicationDaemon.REPLICATION_SOURCES);
        replInfo.loadLastTxnStatus(sources);
    }

    public StreamTable replicationStatus() {
        StreamTable replicationConfig = new StreamTable();
        StreamVector sources = replInfo.lastTxnStatus();
        replicationConfig.put(ReplicationDaemon.REPLICATION_SOURCES, sources);
        return replicationConfig;
    }

    public boolean siteInfoIsLocal() { return true; }

    @Override
    public String toString() {
        return "FileMultiReplicationSiteInfo [replicationSrvInfoFile=" + replicationSrvInfoFile + ", replInfo=" + replInfo + ", timestamp=" + timestamp + "]";
    }
}

class HandleMultiReplicationSiteInfo extends MultiReplicationSiteInfo {
    static final String[] SITE_INFO_TYPES = new String[] { Util.decodeString(Common.SITE_INFO_TYPE), Util.decodeString(Common.SITE_INFO_6_TYPE) };
    String handle;
    HandleResolver resolver;
    ServerInfo serverInfo;
    HandleServer server;
    StreamTable loadedConfig;
    
    List/*<HandleValueReplicationSiteInfo>*/ replInfoList = new ArrayList();
    
    public HandleMultiReplicationSiteInfo(String handle, HandleResolver resolver, 
                                          ServerInfo serverInfo, HandleServer server)
    throws HandleException {
        this.handle = handle;
        this.resolver = resolver;
        this.serverInfo = serverInfo;
        this.server = server;
        //refreshSiteInfo(mySite, myServerNum);
    }
    
    public void refreshSiteInfo() throws HandleException {
      //System.err.println("refreshing site info from handle "+handle);
        HandleValue[] values = resolver.resolveHandle(handle,SITE_INFO_TYPES,null);
        List replInfoNotFound = new ArrayList(replInfoList);
        List replInfoNew = new ArrayList();
        for(int i = 0; i < values.length; i++) {
            Iterator iter = replInfoList.iterator();
            HandleValueReplicationSiteInfo replInfo = null;
            while(iter.hasNext()) {
                replInfo = (HandleValueReplicationSiteInfo)iter.next();
                if(replInfo.value.getIndex()==values[i].getIndex()) {
                    replInfo.refreshSiteInfo(values[i]);
                    replInfoNotFound.remove(replInfo);
                    break;
                }
                replInfo = null;
            }
            if(replInfo == null) {
                // New site
                HandleValueReplicationSiteInfo newReplInfo = new HandleValueReplicationSiteInfo(values[i]);
                
                // let's make sure we don't try to replicate ourself
                SiteInfo newSite = newReplInfo.site;
                boolean match = false;
                outerloop: for (int server = 0; server < newSite.servers.length; server++) {
                    ServerInfo serverInfo = newSite.servers[server];
                    if(Util.equals(serverInfo.ipAddress, this.serverInfo.ipAddress)) {
                        for(int a = 0; a < serverInfo.interfaces.length; a++) {
                            for(int b = 0; b < this.serverInfo.interfaces.length; b++) {
                                if(serverInfo.interfaces[a].port==this.serverInfo.interfaces[b].port) {
                                    this.server.setReplicationPriority(values[i].getIndex());
                                    match = true;
                                    break outerloop;
                                }
                            }
                        }
                    }
                    
                }
                if(!match) {
                    replInfoNew.add(newReplInfo);
                }
            }
        }
        // Removed sites
        Iterator iter = replInfoNotFound.iterator();
        while(iter.hasNext()) {
            replInfoList.remove(iter.next());
        }
        // Add new sites
        iter = replInfoNew.iterator();
        while(iter.hasNext()) {
            replInfoList.add(iter.next());
        }
    }

    public Iterator iterator() {
        return replInfoList.iterator();
    }

    public void loadReplicationStatus(StreamTable replicationConfig) throws HandleException {
        loadedConfig = replicationConfig;
        Iterator iter = replInfoList.iterator();
        while(iter.hasNext()) {
            HandleValueReplicationSiteInfo replInfo = (HandleValueReplicationSiteInfo)iter.next();
            String name = replInfo.value.getIndex() + ":" + handle;
            
            StreamVector sources = (StreamVector)replicationConfig.get(name);
            replInfo.loadLastTxnStatus(sources);
        }
    }

    public StreamTable replicationStatus() throws HandleException {
        StreamTable replicationConfig = new StreamTable();

        Iterator iter = replInfoList.iterator();
        while(iter.hasNext()) {
            HandleValueReplicationSiteInfo replInfo = (HandleValueReplicationSiteInfo)iter.next();
            if(replInfo.hasNoInformation()) continue;
            String name = replInfo.value.getIndex() + ":" + handle;
            
            StreamVector sources = replInfo.lastTxnStatus();
            replicationConfig.put(name,sources);
        }
        if(loadedConfig!=null) {
            for(Object name : loadedConfig.keySet()) {
                if(!replicationConfig.containsKey(name)) {
                    replicationConfig.put(name,loadedConfig.get(name));
                }
            }
        }
        loadedConfig = replicationConfig;
        return replicationConfig;
    }
    
    public void saveSiteInfo() {
        throw new UnsupportedOperationException("Replication site info is not stored locally.");
    }
    
    public boolean siteInfoIsLocal() { return false; }

    @Override
    public String toString() {
        return "HandleMultiReplicationSiteInfo [handle=" + handle + ", serverInfo=" + serverInfo + ", replInfoList=" + replInfoList + "]";
    }
}
