/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;

import java.net.*;
import java.util.*;

/***********************************************************************
 * base class describing an object that listens to a network
 * interface/port and handles incoming requests.  Most subclasses
 * will actually dispatch incoming requests to RequestHandlers in
 * separate threads.
 ***********************************************************************/

public class HdlTcpInterface
  extends NetworkInterface
{
  private InetAddress bindAddress;
  private int threadLife = 200;
  private int maxHandlers = 200;
  private int bindPort = 2641;
  private int backlog;
  private int numThreads=10;
  private boolean logAccesses=false;
  private boolean trackThreads=false;
  private ServerSocket socket = null;
  private boolean keepServing = true;
  
  public HdlTcpInterface(Main main, Hashtable config)
    throws Exception
  {
    super(main);

    init(config);
  }

  public byte getProtocol() { return Interface.SP_HDL_TCP; }
  public int getPort() { return bindPort; }
  
  private void init(Hashtable config)
    throws Exception
  {

    // get the specific IP address to bind to, if any.
    Object bindAddressStr = config.get("bind_address");
    if(bindAddressStr==null)
      bindAddress = null;
    else
      bindAddress = InetAddress.getByName(String.valueOf(bindAddressStr));
    
    // get the port to listen on...
    bindPort = Integer.parseInt((String)config.get("bind_port"));

    // get the max backlog size...
    backlog = Integer.parseInt((String)config.get("backlog"));

    // get the max backlog size...
    try {
      maxHandlers = Integer.parseInt((String)config.get("max_handlers"));
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    "unspecified max_handlers count, using default: "+maxHandlers);
    }

    // get the number of thread (default is 10);
    try {
      numThreads = Integer.parseInt((String)config.get("num_threads"));
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    "unspecified thread count, using default: "+numThreads);
    }

    // get the maximum thread life (default is 200)
    try {
      if(config.containsKey("thread_life")) {
        threadLife = Integer.parseInt((String)config.get("thread_life"));
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    "Invalid thread life, using default: "+threadLife);
    }

    trackThreads = (config.containsKey("track_threads") &&
                    ("yes").equals(config.get("track_threads")));

    // check if we should log accesses or not...
    logAccesses = (config.containsKey("log_accesses") &&
                   ("yes").equals(config.get("log_accesses")));
    
    super.initialize();
  }
  

  /****************************************************************
   * Tells the interface to finish up the current operation and
   * stop listening for new connections.
   ***************************************************************/
  protected void stopService() {
    keepServing = false;
    try {
      socket.close();
    } catch (Exception e) {}
  }


  /****************************************************************
   * Tells the interface to listen for incoming requests until
   * stopService() is called.
   ***************************************************************/
  public void serveRequests() {
    keepServing = true;
    try {
      if(bindAddress==null) {
        socket = new ServerSocket(bindPort, backlog);
      } else {
        socket = new ServerSocket(bindPort, backlog, bindAddress);
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_FATAL,
                    String.valueOf(this.getClass())+
                    ": Error setting up server socket: "+e);
      return;
    }
    
    System.out.println("TCP handle Request Listener:");
    System.out.println("   address: "+(bindAddress==null?"ANY":""+Util.rfcIpRepr(bindAddress)));
    System.out.println("      port: "+bindPort);
    
    handlerPool = new RequestHandlerPool(trackThreads?"TCP":null);
    handlerPool.setHandlerLife(threadLife);
    handlerPool.setMaxPossibleHandlers(maxHandlers);
    
    System.out.print("Starting TCP request handlers: ");
    for(int threadNum=0; threadNum<numThreads; threadNum++) {
      System.out.print(".");
      handlerPool.addHandler(new HdlTcpRequestHandler(main, this, handlerPool, logAccesses));
    }
    System.out.println("DONE");
    try { System.out.flush(); } catch (Exception e) {}
    
    
    long reqCount = 0;
    Socket newsock = null;
    long recvTime = 0;
    while(keepServing) {
      try {
        newsock = socket.accept();
        recvTime = System.currentTimeMillis();

        ((HdlTcpRequestHandler)handlerPool.getHandler()).serviceRequest(newsock, recvTime);
        
//        if(++reqCount > 1000) {
//          needsGC = true;
//          reqCount = 0;
//        }
                
      } catch (Throwable e) {
          if(keepServing) {
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      String.valueOf(this.getClass())+": Error handling request: "+e);
              e.printStackTrace(System.err);
          }
      }
    }

    try {
      socket.close();
    } catch (Exception e) { }
    
  }


}
