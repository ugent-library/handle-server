/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/
package net.handle.server;

import java.util.Hashtable;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.atomic.AtomicLong;
import java.lang.InterruptedException;
import java.lang.Thread;

import com.google.gson.Gson;

public class MonitorDaemon extends Thread{

    private ReentrantLock monitorLock = new ReentrantLock();
    private Hashtable monitorData = new Hashtable();
    private volatile String monitorDataString;
    private int sleepSeconds;
    private long startTime;
    private Gson gson = new Gson();
    private Object sigarWrapper;
    
    private AtomicLong numRequests;
    private AtomicLong numResolutionRequests;
    private AtomicLong numAdminRequests;
    private AtomicLong numTxnRequests;

    public MonitorDaemon(int sleepSeconds, long startTime,
            AtomicLong numRequests,
            AtomicLong numResolutionRequests,
            AtomicLong numAdminRequests,
            AtomicLong numTxnRequests) {
        this.sleepSeconds = sleepSeconds;
        this.startTime = startTime;

        this.numRequests = numRequests;
        this.numResolutionRequests = numResolutionRequests;
        this.numAdminRequests = numAdminRequests;
        this.numTxnRequests = numTxnRequests;

        initializeSigarWrapper();
    }
    
    private void initializeSigarWrapper() {
        try {
            Class.forName("org.hyperic.sigar.Sigar");
            sigarWrapper = Class.forName("net.handle.server.SigarWrapper").newInstance();
        } catch(Exception e) {
//            e.printStackTrace(System.out);
            // ignore
        }
    }

    public void run() {

        while (true) {
            try {

                monitorData = getServerInfo();
                monitorDataString = gson.toJson(monitorData);
                Thread.sleep(1000 * sleepSeconds);
            }
            catch (InterruptedException e) {
//                System.err.println("Monitor daemon interrupted: " + e);
            }
        }
    }

    public String getStatusString() {
        return monitorDataString;
    }

    private Hashtable getServerInfo() {
        Hashtable systemInfo = new Hashtable();

        try {
            if(sigarWrapper!=null) {
                systemInfo.put("loadAvg", getLoadAverageInfo());
                systemInfo.put("domainName", getFQDN());
                systemInfo.put("diskInfo", getDiskInfo());
                systemInfo.put("mem", getMemInfo());
            }
        }
        catch (Exception e) {
            System.err.println("Sigar Exception: " + e);
        }
        systemInfo.put("startTime", startTime);
        systemInfo.put("requests", getReqInfo());
        systemInfo.put("lastUpdate", System.currentTimeMillis());

        return systemInfo;
    }

    private Hashtable getReqInfo() {
        Hashtable reqTable = new Hashtable();

        reqTable.put("resolution", numResolutionRequests);
        reqTable.put("admin", numAdminRequests);
        reqTable.put("txn", numTxnRequests);
        reqTable.put("total", numRequests);

        return reqTable;
    }

    private Object getFQDN() throws Exception {
        return sigarWrapper.getClass().getMethod("getFQDN").invoke(sigarWrapper);
    }
    
    private Object getLoadAverageInfo() throws Exception {
        return sigarWrapper.getClass().getMethod("getLoadAverageInfo").invoke(sigarWrapper);
    }

    private Object getDiskInfo() throws Exception {
        return sigarWrapper.getClass().getMethod("getDiskInfo").invoke(sigarWrapper);
    }

    private Object getMemInfo() throws Exception {
        return sigarWrapper.getClass().getMethod("getMemInfo").invoke(sigarWrapper);
    }

}