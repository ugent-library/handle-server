/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server.dns;

import net.handle.dnslib.*;
import net.handle.server.Main;
import net.handle.server.RequestHandler;
import net.handle.server.RequestHandlerPool;
import net.handle.server.ServerLog;

import java.io.IOException;

import java.net.*;

/**
 *    Description:  A DnsUdpRequestHandler object will handle requests submitted using
 *                  the BIND protocol.  The requests for DNS names will be translated
 *                  into handle names and resolved using the specified handle source
 *                  object.  After the resolution is made, a response is returned
 *                  using the DNS BIND protocol.
 */

public class DnsUdpRequestHandler
implements Runnable, RequestHandler
{
    public static final String ACCESS_TYPE = "UDP:DNS";

    private final Main main;
    public final DnsConfiguration dnsConfig;
    private final NameServer nameServer;
    private final RequestHandlerPool handlerPool;
    private final boolean logAccesses;
    private final DatagramSocket dsocket;

    private boolean isActive=true;
    private boolean isRunning=false;
    private int invocations = 0;

    private DatagramPacket packet;
    private long recvTime;

    private Thread handlerThread;
    
    public DnsUdpRequestHandler(Main main, DatagramSocket dsock, 
            RequestHandlerPool handlerPool,
            DnsConfiguration dnsConfig,
            boolean logAccesses)
    {
        this.main = main;
        this.dsocket = dsock;
        this.handlerPool = handlerPool;
        this.logAccesses = logAccesses;
        this.dnsConfig = dnsConfig;
        this.nameServer = dnsConfig.getNameServer();
        handlerThread = new Thread(this);
        handlerThread.start();
    }

    public synchronized void deactivate() {
        isActive = false;
        resetState();
        handlerThread.interrupt();
    }

    public int getInvocationCount() {
        return invocations;
    }

    public void resetState() {
        isRunning = false;
    }

    public RequestHandler newHandler() {
        return new DnsUdpRequestHandler(main, dsocket, handlerPool, dnsConfig, logAccesses);
    }     

    public synchronized void serviceRequest(DatagramPacket packet, long recvTime) {
        this.packet = packet;
        this.recvTime = recvTime;
        isRunning = true;
        notify();
    }

    public void run() {
        while(isActive) {
            synchronized(this) {
                while(!isRunning && isActive) {
                    try {
                        wait();
                    } catch(InterruptedException e) {
                        // ignore
                    } catch (Exception e) {
                        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                                String.valueOf(getClass())+": Got exception: "+e);
                    }
                }
            }
            if(!isActive) continue;
            try {
                handleRequest();

            } catch (Exception e) {
                main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                        String.valueOf(this.getClass())+": Exception processing request: "+e);
                e.printStackTrace();
            } finally {
                handlerPool.returnHandler(this);
            }
        }
    }

    /**
     * Description: Sends a response
     * @param dnsMessage
     */

    private void sendResponse(Message dnsMessage,int udpPayloadSize) {
        InetAddress addr = packet.getAddress();
        int port = packet.getPort();

        try {
            byte buf[] = dnsMessage.getDatagram(udpPayloadSize);
            dsocket.send(new DatagramPacket(buf,buf.length,addr,port));
            
            if(logAccesses){
                long time = System.currentTimeMillis() - recvTime;
                String logName = dnsMessage.getQuestionNameAsString();
                main.logAccess(ACCESS_TYPE, packet.getAddress(),
                        dnsMessage.getOpcode(),
                        dnsMessage.getExtendedResponseCode(),
                        logName, time);
            }

        } catch (IOException e) {
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                    String.valueOf(this.getClass())+": unable to send response packet to "+addr+":"+port);
        }
    }


    /**
     * Parse the DNS request from the UDP and convert it to a handle request
     * that is sent to the back-end for processing.
     * @throws IOException 
     */
    private void handleRequest() throws IOException {
        // packet and recvTime will have been set      

        invocations++;
        boolean allowed = dnsConfig.getAllowQuery(packet.getAddress());
        boolean recursionAvailable = dnsConfig.getRecursive(packet.getAddress());
        
        Message response;
        byte[] queryBytes = packet.getData();
        int[] udpPayloadArr = new int[] { 512 };
        if(!allowed) response = nameServer.refusalResponse(queryBytes);
        else {
            response = nameServer.respondToBytes(queryBytes,recursionAvailable,udpPayloadArr);
        }
        
        if(response==null) return;
        
        sendResponse(response,udpPayloadArr[0]);
    }
}
