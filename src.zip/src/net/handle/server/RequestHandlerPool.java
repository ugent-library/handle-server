/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

/************************************************************************
 * Class that maintains a pool of available request handlers.
 * When a request handler is needed, then getHandler() method
 * should be called and a handler is selected from the pool.
 * after the request has been completed, the returnHandler
 * method should be called to put the handler back in the pool
 * at which time the resetState method will be called on the
 * handler.
 ************************************************************************/

public class RequestHandlerPool
  implements Runnable
{
  private static final int DEFAULT_POOL_SIZE = 100;
  private static final int SIZE_INCREMENT = 50;
  
  private int maxPossibleHandlers = 300;
  private int maxHandlerInvocations = 200;
  private RequestHandler pool[];
  private int start = 0;  // the index of the first ready handler
  private int end = 0;    // the index of the last handler (could be < start)
  private String statusID = null;
  
  public RequestHandlerPool() {
    // initialize to a default size...
    pool = new RequestHandler[DEFAULT_POOL_SIZE];
    for(int i=0; i<DEFAULT_POOL_SIZE; i++) {
      pool[i] = null;
    }
  }

  public RequestHandlerPool(String statusID) {
    this();
    this.statusID = statusID;
    if(statusID!=null) {
      Thread analyzer = new Thread(this);
      analyzer.setDaemon(true);
      analyzer.start();
    }
  }

  /** Sets the maximum number of handlers that should be instantiated.
      This applies when a handler is requested and none are available in the
      pool.  If the size of the pool has not hit the  maxHandlerCount then
      another handler is spawned to process the immediate request. */
  public void setMaxPossibleHandlers(int maxHandlerCount) {
    this.maxPossibleHandlers = maxHandlerCount;
  }
  
  public void setHandlerLife(int handlerLife) {
    this.maxHandlerInvocations = handlerLife;
  }

  public void run() {
    while(true) {
      try { 
        System.err.println("<"+statusID+':'+getAvailableCount()+">");
        Thread.sleep(60000);
      } catch (Exception e) {}
    }
  }

  int getAvailableCount() {
    int size = end - start;
    if(size<0)
      size = pool.length + size;
    return size;
  }
  
  public void addHandler(RequestHandler handler) {
    returnHandler(handler);
  }

  /**********************************************************************
   * Get a handler from the pool.  If none are available, wait until one
   * is available and return it.  This does not necessarily hand out
   * RequestHandlers on a first-come first-serve basis.
   **********************************************************************/
  public synchronized RequestHandler getHandler() {
    while(true) {
      // if there are handlers available, return the first one.
      if(start!=end) {
        int idx = start++;

        if(start>=pool.length) // loop around to the beginning
          start = 0;
        
        return pool[idx];
      }

      // If we get to this point, then no handlers are immediately available

      if(pool.length < maxPossibleHandlers && pool.length>0) {
        // If there is room under the MAX_POSSIBLE_HANDLERS threshold, then spawn a new
        // handler and return it.  We could add it to the pool here, but it should add
        // itself to the pool after it is finished executing

        return pool[0].newHandler();
        
      } else {
        // if there is no more room for another handler, wait (one second at a time)
        // until one is available.  If one becomes available, we will wake
        // up immediately and return it
        try {
          this.wait(1000);
        } catch (Exception e) {
          System.err.println("Got exception waiting for handler: "+e);
        }
      }
    }
  }

  public void shutdown() {
    synchronized(this) {
      if(pool==null) return;
      for(int i=pool.length-1; i>=0; i--) {
        RequestHandler h = pool[i];
        if(h!=null) h.deactivate();
      }
      pool = null;
    }
  }
  
  /*********************************************************************
   * Return the specified handler to the pool.  This object calls the
   * resetState() method on the object before returning it to the set
   * of available handlers.
   *********************************************************************/
  public void returnHandler(RequestHandler handler) {
    try {
      handler.resetState();
    } catch (Throwable t) {
      System.err.println("Exception resetting handler state: "+t);
    }

    try {
      synchronized (this) {
        // put the handler into the pool at the end of the queue

        if(getAvailableCount()>=(pool.length-1)) {
          System.err.println("Growing handler pool... end="+end+" pool.length="+
                             pool.length+" start="+start);
          // need to increase the pool size by SIZE_INCREMENT
          RequestHandler newPool[] = new RequestHandler[pool.length + SIZE_INCREMENT];
          int i = 0;

          // copy the old handlers into the new pool array...
          while(start!=end) {
            newPool[i++] = pool[start++];
            if(start>=pool.length)
              start = 0;
          }
          start = 0;
          end = i;
          pool = newPool;
        }

        int thisHandlerIdx = end++;
        if(end>=pool.length)
          end = 0;

        pool[thisHandlerIdx] = handler;
        if(pool[thisHandlerIdx].getInvocationCount() > maxHandlerInvocations) {
          pool[thisHandlerIdx] = handler.newHandler();
          handler.deactivate();
        }

        this.notify();
      }
      
    } catch(Exception e) {
      System.err.println("Error resetting handler: "+e);
    }
  }

}
