/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;

import java.net.*;
import java.io.*;

/**********************************************************************
 * An HdlTcpRequestHandler object will handle requests submitted using
 * the TCP handle protocol.  The request will be processed using the
 * server object and a response will be returned using the TCP handle
 * protocol.
 **********************************************************************/

public class HdlTcpRequestHandler
  implements Runnable, RequestHandler, ResponseMessageCallback
{
  private static final int DEFAULT_MAX_MESSAGE_LENGTH = 1024;

  private Socket socket = null;
  private AbstractServer server;
  private Main main;

  private boolean isActive = true;
  private int invocations = 0;
  private Thread handlerThread;
  private boolean isRunning = false;
  private boolean logAccesses = false;
  private RequestHandlerPool handlerPool = null;
  private MessageEnvelope envelope = new MessageEnvelope();
  private byte envelopeBuf[] = new byte[Common.MESSAGE_ENVELOPE_SIZE];
  private byte messageBuf[] = new byte[DEFAULT_MAX_MESSAGE_LENGTH];
  
  public static final String ACCESS_TYPE = "TCP:HDL";
  public static final byte MSG_INVALID_MSG_SIZE[] = Util.encodeString("Invalid message length");

  private long recvTime = 0; // time current request was recieved
  private AbstractRequest currentRequest;
  private HdlTcpInterface interfc;

  public HdlTcpRequestHandler(Main main,
                              HdlTcpInterface ifc, 
                              RequestHandlerPool handlerPool,
                              boolean logAccesses)
  {
    this.main = main;
    this.interfc = ifc;
    this.server = main.getServer();
    this.handlerPool = handlerPool;
    this.logAccesses = logAccesses;
    
    handlerThread = new Thread(this);
    handlerThread.start();
  }

  public RequestHandler newHandler() {
    return new HdlTcpRequestHandler(main, interfc, handlerPool, logAccesses);
  }

  public void resetState()
  {
    isRunning = false;
    if(socket!=null) {
      try { socket.close(); } catch (Exception e){}
    }
  }


  public synchronized void deactivate() {
    isActive = false;
    resetState();
  }
  
  public int getInvocationCount() {
    return invocations;
  }

  public synchronized void serviceRequest(Socket socket, long recvTime) {
    this.recvTime = recvTime;
    this.socket = socket;
    isRunning = true;
    invocations++;
    notify();
  }

  public void run() {
    while(isActive) {
      synchronized(this) {
        while(!isRunning && isActive) {
          try {
            wait();
          } catch (Exception e) {
        	e.printStackTrace();
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                          String.valueOf(getClass())+"Got exception: "+e);
          }
        }
      }

      if(!isActive) continue;
      
      InputStream in = null;
      try {
        in = socket.getInputStream();
        int r, n=0;
 
        // receive and parse the message envelope
        while(n<Common.MESSAGE_ENVELOPE_SIZE &&
              (r=in.read(envelopeBuf, n, Common.MESSAGE_ENVELOPE_SIZE-n))>=0)
          n += r;
        Encoder.decodeEnvelope(envelopeBuf, envelope);

        if(envelope.messageLength > Common.MAX_MESSAGE_LENGTH ||
           envelope.messageLength < 0) {
          handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_PROTOCOL_ERROR,
                                           MSG_INVALID_MSG_SIZE));
          close(in);
          return;
        }
        
        // increase the messageBuf size if necessary
        if(messageBuf.length < envelope.messageLength)
          messageBuf = new byte[envelope.messageLength];

        // receive the rest of the message
        r=n=0;
        while(n<envelope.messageLength &&
              (r=in.read(messageBuf, n, envelope.messageLength-n))>=0)
          n += r;
        

        if(n<envelope.messageLength) {
          // we didn't receive the whole message...
          throw new Exception("Expecting "+envelope.messageLength
                              +" bytes, "+ "only received "+n);
        }

        //decrypt incoming request if it says so ..
        if (envelope.encrypted) {
          if (envelope.sessionId > 0) {
            ServerSideSessionInfo sssinfo = null;
            if (server instanceof HandleServer) {
          
              sssinfo = ((HandleServer)server).getSession(envelope.sessionId);
              if (sssinfo != null) {
        
                try { 
                  messageBuf = sssinfo.decryptBuffer(messageBuf,0,envelope.messageLength);
                  envelope.encrypted = false;
                  envelope.messageLength = messageBuf.length;
                }
                catch (Exception e) {
                  main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                                "Exception decrypting request: "+e);
                  e.printStackTrace();
                  System.err.println("Exception decrypting request with session key: " + e.getMessage());
                  handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_FAILED,
                                           Util.encodeString("Exception decrypting request with session key " + e)));
                  close(in);
                  return;
                }        
              } else {
                // sssinfo == null, maybe time out!
                main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                              "Session information not available or time out. Unable to decrypt request message");
                System.err.println("Session information not available or time out. Unable to decrypt request message.");
                handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_TIMEOUT,
                                           Util.encodeString("Session information not available or time out. Unable to decrypt request message.")));
                close(in);
                return;
              }
            } else {   
              // serverSessionMan == null 
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                                "Session manager not available. Unable to decrypt request message.");
              System.err.println("Session manager not available. Request message not decrypted.");
              handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_FAILED,
                                           Util.encodeString("Session manager not available. Unable to decrypt request message.")));
              close(in);
              return;
            }
          } else {
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                          "Invalid session id. Request message not decrypted.");
            System.err.println("Invalid session id. Request message not decrypted.");
            handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                             AbstractMessage.RC_SESSION_FAILED,
                                             Util.encodeString("Invalid session id. Unable to decrypt request message.")));
            close(in);
            return;
          }
        }
       
        currentRequest =
          (AbstractRequest)Encoder.decodeMessage(messageBuf, 0, envelope);
        
        String errMsg = interfc.canProcessMsg(currentRequest);
        if(errMsg!=null) {
          main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, errMsg);
          handleResponse(new ErrorResponse(currentRequest.opCode,
                                           AbstractMessage.RC_PROTOCOL_ERROR,
                                           Util.encodeString(errMsg)));
          return;
          
        }
        
        server.processRequest(currentRequest, this);
      } catch (Throwable e) {
        handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,AbstractMessage.RC_ERROR,Util.encodeString("Server error processing request, see server logs")));
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      String.valueOf(this.getClass())+": Exception processing request: "+e);
        e.printStackTrace();
      } finally {
        close(in);
      }
    }
  }

  private void close(java.io.InputStream in){
    if(in!=null) {
      try { in.close(); } catch (Throwable e) { }
    }

    if(socket!=null) {
      try { socket.close(); } catch (Exception e){ }
      socket = null;
    }
    // return the handler to the pool.
    handlerPool.returnHandler(this);
  }

  /****************************************************************************
   * Handle (log) any messages that are reported by the upstream message
   * provider.
   ****************************************************************************/
  public void handleResponseError(String error) {
    main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                  String.valueOf(this.getClass())+": Server error: "+error);
  }

  /****************************************************************************
   * Encode and send the response
   ****************************************************************************/
  public void handleResponse(AbstractResponse response) {
    OutputStream out = null;
    boolean keepSocketOpen = response.continuous;
    try {
      byte msg[] = response.getEncodedMessage();

      // when to encrypt? right before sending it out! after the credential portion is formed!
      // encrypt response here if the request asks for encryption
      // and set the flag in envelop if successfull
      boolean encrypted = false;
      if (response.encrypt && response.sessionId > 0){
        ServerSideSessionInfo sssinfo = null;
        if (server instanceof HandleServer) {
          
          sssinfo = ((HandleServer)server).getSession(response.sessionId);
          if (sssinfo != null) {
            try { 
              msg = sssinfo.encryptBuffer(msg, 0, msg.length);
              encrypted = true;
            } catch (Exception e) {
              main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Exception encrypting response: "+e);
              System.err.println("Exception encrypting message with session key: " + e.getMessage());
              encrypted = false;
            }        
          } // sssinfo != null
        } else {   
          // serverSessionMan == null 
          main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Session manager not available. Message not encrypted.");
          System.err.println("Session manager not available. Message not encrypted.");
          encrypted = false;
        }
      }
      
      // set the envelop flag for encryption
      envelope.encrypted = encrypted;
      envelope.messageLength = msg.length;  //get the length after encryption
      envelope.messageId = 0;
      envelope.sessionId = response.sessionId;
      envelope.protocolMajorVersion = response.majorProtocolVersion;
      envelope.protocolMinorVersion = response.minorProtocolVersion;
      Encoder.encodeEnvelope(envelope, envelopeBuf);
      
      out = socket.getOutputStream();
      out.write(Util.concat(envelopeBuf,msg));
      out.flush();
      
      long respTime = System.currentTimeMillis() - recvTime;
      if (logAccesses) {
        if (currentRequest != null) {
          main.logAccess(ACCESS_TYPE, socket.getInetAddress(),
                         currentRequest.opCode, 
                         (response != null ? response.responseCode : AbstractMessage.RC_ERROR),
                         Util.decodeString(currentRequest.handle), respTime);
        }
      }

      // if the response is "streamable," send the streamed part...
      if(response.streaming) {
        out = new BufferedOutputStream(out);
        response.streamResponse(out);
        out.flush();
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    String.valueOf(this.getClass())+": Exception sending response: "+e);
      e.printStackTrace(System.err);
    } finally {
      if(out!=null && !keepSocketOpen) {
        try { out.flush(); } catch (Exception e) {}
        try { out.close(); } catch (Exception e) {}
      }
    }
  }

}

