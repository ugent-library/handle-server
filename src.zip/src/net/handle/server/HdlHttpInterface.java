/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import java.net.*;
import java.util.*;

/***********************************************************************
 * base class describing an object that listens to a network
 * interface/port and handles incoming requests.  Most subclasses
 * will actually dispatch incoming requests to RequestHandlers in
 * separate threads.
 ***********************************************************************/

public class HdlHttpInterface
  extends NetworkInterface
{
  private InetAddress bindAddress;
  private int bindPort = 8000;
  private int backlog;
  private int numThreads=10;
  private int threadLife = 200;
  private int maxHandlers = 200;
  private boolean logAccesses=false;
  private boolean trackThreads=false;
  private ServerSocket socket = null;
  private boolean keepServing = true;
  private String sfxCookieName = null;
  private String responsePage = null;
  private String queryPage = null;
  private String errorPage = null;
  
  //define a vector of virtual hosts.
  //in config.dct, the section looks like this:
  //"hdl_http_config" = {
  //    ...
  //    "virtual_hosts" =
  //    {
  //        "hostname" = "dx.doi.org"
  //        "query_page" = "/certain path/certain_query.html"
  //        "response_page" = "/certain path/certain_response.html"
  //        "error_page" = "/certain path"/certain_error.html"
  //    }
  //}

  //OR for more than one host, uses the following:
  //"hdl_http_config" = {
  //    ...
  //    "virtual_hosts" =
  //    ({
  //        "hostname" = "dx.abc.org"
  //        "query_page" = "/certain path/certain_query.html"
  //        "response_page" = "/certain path/certain_response.html"
  //        "error_page" = "/certain path"/certain_error.html"
  //    },
  //    {
  //        "hostname" = "zx.xyz.org"
  //        "query_page" = "/other path/other_query.html"
  //        "response_page" = "/other path/other_response.html"
  //        "error_page" = "/other/other_error.html"
  //    })
  //}

  public byte getProtocol() { return Interface.SP_HDL_HTTP; }
  public int getPort() { return bindPort; }
  

  private Vector virtualHosts = new Vector();
  //each element in the virtualHosts is a hashTable which contains "hostname", "query_page",
  //"response_page", "error_page" key/value.

  public HdlHttpInterface(Main main, Hashtable config)
    throws Exception
  {
    super(main);

    init(config);
 }


  private void init(Hashtable config)
    throws Exception
  {

    // get the specific IP address to bind to, if any.
    Object bindAddressStr = config.get("bind_address");
    if(bindAddressStr==null)
      bindAddress = null;
    else
      bindAddress = InetAddress.getByName(String.valueOf(bindAddressStr));

    // get the port to listen on...
    bindPort = Integer.parseInt((String)config.get("bind_port"));

    // get the max backlog size...
    backlog = Integer.parseInt((String)config.get("backlog"));

    // get the number of thread (default is 10);
    try {
      numThreads = Integer.parseInt((String)config.get("num_threads"));
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    "unspecified thread count, using default: "+numThreads);
    }

    // get the max backlog size...
    try {
      maxHandlers = Integer.parseInt((String)config.get("max_handlers"));
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    "unspecified max_handlers count, using default: "+maxHandlers);
    }

    // get the maximum thread life (default is 200)
    try {
      if(config.containsKey("thread_life")) {
        threadLife = Integer.parseInt((String)config.get("thread_life"));
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    "Invalid thread life, using default: "+threadLife);
    }

    trackThreads = (config.containsKey("track_threads") &&
                    ("yes").equals(config.get("track_threads")));

    // check if we should log accesses or not...
    logAccesses = (config.containsKey("log_accesses") &&
                   ("yes").equals(config.get("log_accesses")));
    sfxCookieName = (String)config.get("sfx_cookie");

    // check for specified html templates from config.dct
    queryPage = (String)config.get("query_page");
    responsePage = (String)config.get("response_page");
    errorPage = (String)config.get("error_page");

    //check to see the virtual hosts
    //if there is only one virtual host, the entry is a hashtable in config.dct;
    //if there are more than one, it will be a vector. or null if none
    Object ob = config.get("virtual_hosts");
    if (ob instanceof Vector) {
       Vector v = (Vector)ob;
       virtualHosts = v;

    } else if (ob instanceof Hashtable) {
       Hashtable virtualHt = (Hashtable)ob;
       virtualHosts.addElement(virtualHt);
    }
    super.initialize();
  }


  /****************************************************************
   * Tells the interface to finish up the current operation and
   * stop listening for new connections.
   ***************************************************************/
  protected void stopService()
  {
    keepServing = false;
    try {
      socket.close();
    } catch (Exception e) {}
  }
  
  
  /****************************************************************
   * Tells the interface to listen for incoming requests until
   * stopService() is called.
   ***************************************************************/
  public void serveRequests() {
    keepServing = true;
    try {
      if(bindAddress==null) {
        socket = new ServerSocket(bindPort, backlog);
      } else {
        socket = new ServerSocket(bindPort, backlog, bindAddress);
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_FATAL,
                    String.valueOf(this.getClass())+
                    ": Error setting up server socket: "+e);
      return;
    }

    System.out.println("HTTP handle Request Listener:");
    System.out.println("   address: "+(bindAddress==null?"ANY":""+Util.rfcIpRepr(bindAddress)));
    System.out.println("      port: "+bindPort);

    handlerPool = new RequestHandlerPool(trackThreads?"HTTP":null);
    handlerPool.setHandlerLife(threadLife);
    handlerPool.setMaxPossibleHandlers(maxHandlers);
    System.out.print("Starting HTTP request handlers: ");
    for(int threadNum=0; threadNum<numThreads; threadNum++) {
      System.out.print('.');
      handlerPool.addHandler(new HdlHttpRequestHandler(main, this, handlerPool,
                                                       logAccesses, sfxCookieName,
                                                       queryPage, responsePage,
                                                       errorPage, virtualHosts));
    }
    System.out.println("");
    try { System.out.flush(); } catch (Exception e) {}


    long reqCount = 0;
    long recvTime = 0;
    Socket newsock = null;
    while(keepServing) {
      try {
        newsock = socket.accept();
        recvTime = System.currentTimeMillis();

        ((HdlHttpRequestHandler)handlerPool.getHandler()).serviceRequest(newsock, recvTime);

//        if(++reqCount > 1000) {
//          needsGC = true;
//          reqCount = 0;
//        }

      } catch (Throwable e) {
          if(keepServing) {
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      String.valueOf(this.getClass())+": Error handling request: "+e);
              e.printStackTrace(System.err);
          }
      }
    }

    try {
      socket.close();
    } catch (Exception e) { }

  }


}
