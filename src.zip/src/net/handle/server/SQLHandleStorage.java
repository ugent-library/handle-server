/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.cnri.util.StreamTable;
import net.cnri.util.StringUtils;
import net.handle.hdllib.*;
import java.sql.*;
import java.util.*;

/*************************************************************
 * Class that provides a storage mechanism for handle records
 * using an SQL database that is accessed via JDBC
 *************************************************************/
public class SQLHandleStorage
  implements HandleStorage
{
  private static final String SQL_URL = "sql_url";
  private static final String SQL_LOGIN = "sql_login";
  private static final String SQL_PASSWD = "sql_passwd";
  private static final String SQL_DRIVER_CLASS = "sql_driver";
  private static final String SQL_READ_ONLY = "sql_read_only";

  private static final long CONN_LIFE_TIME = 6*60*60*1000; // 6 hours
  private static final long MAX_OPS_PER_CONN = 50000; // max # of queries before reconnect
  
  private Connection sqlConnection = null;
  private String databaseURL;
  private String username;
  private String passwd;
  private boolean readOnly = true;
  private boolean compensateForOracleJDBCBug = false;
  private boolean storeHandleAsString = false;
  private boolean storeNaAsString = false;
  private boolean storeHandleValueTypeAsString = false;

  private long lastConnectTime = 0;
  private long numOperations = 0;
  
  private PreparedStatement haveNAStatement = null;
  private PreparedStatement addNAStatement = null;
  private PreparedStatement delNAStatement = null;
  private PreparedStatement addHasNAStatement = null;
  private PreparedStatement createHandleStatement = null;
  private PreparedStatement getHandleStatement = null;
  private PreparedStatement handleExistsStatement = null;
  private PreparedStatement deleteHandleStatement = null;
  private PreparedStatement modifyValueStatement = null;
  
  private String HAVE_NA_STMT =
    "select count(*) from nas where na = ?";
  private String DEL_NA_STMT =
    "delete from nas where na = ?";
  private String ADD_NA_STMT =
    "insert into nas ( na ) values ( ? )";
  private String SCAN_HANDLES_STMT =
    "select distinct handle from handles";
  private String SCAN_BYPREFIX_STMT =
    "select distinct handle from handles where handle like ?";
  private String SCAN_NAS_STMT =
    "select distinct na from nas";
  private String DELETE_ALL_HDLS_STMT =
    "delete from handles";
  private String DELETE_ALL_NAS_STMT =
    "delete from nas";
  private String CREATE_HDL_STMT =
    "insert into handles ( handle, idx, type, data, ttl_type, ttl, "+
    "timestamp, refs, admin_read, admin_write, pub_read, pub_write) values "+
    "( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  private String GET_HDL_STMT =
    "select idx, type, data, ttl_type, ttl, timestamp, refs, admin_read, "+
    "admin_write, pub_read, pub_write from handles where handle = ?";
  private String HDL_EXISTS_STMT =
    "select count(*) from handles where handle = ?";
  private String DELETE_HDL_STMT =
    "delete from handles where handle = ?";
  private String MOD_VALUE_STMT =
    "update handles set type = ?, data = ?, ttl_type = ?, ttl = ?, "+
    "timestamp = ?, refs = ?, admin_read = ?, admin_write = ?, pub_read = ?, "+
    "pub_write = ? where handle = ? and idx = ?";

  private static final String CFG_HAVE_NA_STMT = "have_na_stmt";
  private static final String CFG_DEL_NA_STMT = "del_na_stmt";
  private static final String CFG_ADD_NA_STMT = "add_na_stmt";
  private static final String CFG_SCAN_HANDLES_STMT = "scan_handles_stmt";
  private static final String CFG_SCAN_BYPREFIX_STMT = "scan_by_prefix_stmt";
  private static final String CFG_SCAN_NAS_STMT = "scan_nas_stmt";
  private static final String CFG_DELETE_ALL_HDLS_STMT = "delete_all_handles_stmt";
  private static final String CFG_DELETE_ALL_NAS_STMT = "delete_all_nas_stmt";
  private static final String CFG_CREATE_HDL_STMT = "create_handle_stmt";
  private static final String CFG_GET_HDL_STMT = "get_handle_stmt";
  private static final String CFG_HDL_EXISTS_STMT = "handle_exists_stmt";
  private static final String CFG_DELETE_HDL_STMT = "delete_handle_stmt";
  private static final String CFG_MOD_VALUE_STMT = "modify_value_stmt";
  private static final String CFG_FIX_ORACLE_BUG = "compensate_for_oracle_jdbc_bug";
  private static final String CFG_STORE_HANDLE_AS_STRING = "store_handle_as_string";
  private static final String CFG_STORE_NA_AS_STRING = "store_na_as_string";
  private static final String CFG_STORE_HANDLE_VALUE_TYPE_AS_STRING = "store_handle_value_type_as_string";
  
  public SQLHandleStorage()
    throws Exception
  {
  }

  /** Initialize the SQL storage object with the given settings. */
  public void init(StreamTable config)
    throws Exception
  {
    // load the SQL driver, if configured...
    if(config.containsKey(SQL_DRIVER_CLASS)) {
      Class.forName(String.valueOf(config.get(SQL_DRIVER_CLASS)));
    }
  
    // get the database URL and other connection parameters
    this.databaseURL = (String)config.get(SQL_URL);
    this.username = (String)config.get(SQL_LOGIN);
    this.passwd = (String)config.get(SQL_PASSWD);

    // is this back-end operating in read-only mode
    this.readOnly = config.getBoolean(SQL_READ_ONLY, false);
    
    // compensate for inconsistent behavior in Oracle JDBC driver that returns
    // a different value for getBytes() than was inserted using setBytes()
    this.compensateForOracleJDBCBug = config.getBoolean(CFG_FIX_ORACLE_BUG, false);
    
    this.storeHandleAsString = config.getBoolean(CFG_STORE_HANDLE_AS_STRING, false);
    this.storeNaAsString = config.getBoolean(CFG_STORE_NA_AS_STRING, false);
    this.storeHandleValueTypeAsString = config.getBoolean(CFG_STORE_HANDLE_VALUE_TYPE_AS_STRING, false);
    
    // allow the config file to override any of the SQL statements
    HAVE_NA_STMT = config.getStr(CFG_HAVE_NA_STMT, HAVE_NA_STMT);
    DEL_NA_STMT = config.getStr(CFG_DEL_NA_STMT, DEL_NA_STMT);
    ADD_NA_STMT = config.getStr(CFG_ADD_NA_STMT, ADD_NA_STMT);
    SCAN_HANDLES_STMT = config.getStr(CFG_SCAN_HANDLES_STMT, SCAN_HANDLES_STMT);
    SCAN_BYPREFIX_STMT = config.getStr(CFG_SCAN_BYPREFIX_STMT, SCAN_BYPREFIX_STMT);
    SCAN_NAS_STMT = config.getStr(CFG_SCAN_NAS_STMT, SCAN_NAS_STMT);
    DELETE_ALL_HDLS_STMT = config.getStr(CFG_DELETE_ALL_HDLS_STMT, DELETE_ALL_HDLS_STMT);
    DELETE_ALL_NAS_STMT = config.getStr(CFG_DELETE_ALL_NAS_STMT, DELETE_ALL_NAS_STMT);
    CREATE_HDL_STMT = config.getStr(CFG_CREATE_HDL_STMT, CREATE_HDL_STMT);
    GET_HDL_STMT = config.getStr(CFG_GET_HDL_STMT, GET_HDL_STMT);
    HDL_EXISTS_STMT = config.getStr(CFG_HDL_EXISTS_STMT, HDL_EXISTS_STMT);
    DELETE_HDL_STMT = config.getStr(CFG_DELETE_HDL_STMT, DELETE_HDL_STMT);
    MOD_VALUE_STMT = config.getStr(CFG_MOD_VALUE_STMT, MOD_VALUE_STMT);
    
    getConnection();
  }

  // return value is always sqlConnection
  private synchronized void getConnection()
    throws HandleException
  {
    long now = System.currentTimeMillis();
    
    // if the current connection has seen enough action, close it and start a new one
    if(sqlConnection!=null &&
       (lastConnectTime < now - CONN_LIFE_TIME || numOperations > MAX_OPS_PER_CONN)) {
      Connection oldConnection = sqlConnection;
      try {
        sqlConnection = null;

        ///// leave the connection open,
        ///// in case there is some pending operation still using the connection;
        ///// garbage collection will close it
        // oldConnection.close();
      } catch (Exception e) {
        System.err.println("Error resetting old connection: "+e);
        e.printStackTrace(System.err);
      }
    }

    
    // if we already have an open connection, use it
    try {
      if(sqlConnection!=null && !sqlConnection.isClosed())
        return; // sqlConnection;
    } catch (SQLException e) {
      System.err.println(e);
      e.printStackTrace(System.err);
    }

    // at this point, there is no valid open connection

    // if there is a connection, try to clean it up a little
    if(sqlConnection!=null) {
      try {
        sqlConnection.close();
      } catch (Throwable t) {
        System.err.println("Error cleaning up SQL connection: "+t);
        t.printStackTrace(System.err);
      }
      sqlConnection = null;
    }

    try {
      // get a new connection and prepare the statements..
      sqlConnection = DriverManager.getConnection(databaseURL, username, passwd);
      
      lastConnectTime = now;
      numOperations = 0;
      
      haveNAStatement = sqlConnection.prepareStatement(HAVE_NA_STMT);
      delNAStatement = sqlConnection.prepareStatement(DEL_NA_STMT);
      addNAStatement = sqlConnection.prepareStatement(ADD_NA_STMT);
      createHandleStatement = sqlConnection.prepareStatement(CREATE_HDL_STMT);
      getHandleStatement = sqlConnection.prepareStatement(GET_HDL_STMT);
      handleExistsStatement = sqlConnection.prepareStatement(HDL_EXISTS_STMT);
      deleteHandleStatement = sqlConnection.prepareStatement(DELETE_HDL_STMT);
      modifyValueStatement = sqlConnection.prepareStatement(MOD_VALUE_STMT);

    } catch (SQLException e) {
      SQLException origE = e;
      while(e!=null) {
        System.err.println("Got SQL Exception "+e);
        e = e.getNextException();
      }
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error connecting",origE);
    } catch (Exception e) {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Unable to setup sql connection",e);
    }
    return; // sqlConnection;
  }
  

  /*********************************************************************
   * Returns true if this server is responsible for the given naming
   * authority.
   *********************************************************************/
  public synchronized boolean haveNA(byte authHandle[])
    throws HandleException
  {
    getConnection();
    ResultSet results = null;
    try {
      if (Util.startsWithCI(authHandle,Common.NA_HANDLE_PREFIX)) authHandle = Util.getSuffixPart(authHandle);
      authHandle = Util.upperCase(authHandle);
      setNa(haveNAStatement, 1, authHandle);
      results = haveNAStatement.executeQuery();
      numOperations++;
      if(results.next() && results.getInt(1)>0) return true;
      if(Util.hasSlash(authHandle)) return false;
      authHandle = Util.getZeroNAHandle(authHandle);
      setNa(haveNAStatement, 1, authHandle);
      results = haveNAStatement.executeQuery();
      numOperations++;
      if(results.next() && results.getInt(1)>0) return true;      
      return false;
    } catch (Exception e) {
      // force a reconnect because something is likely wrong with
      // the SQL connection
      sqlConnection = null;
      
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error accessing NA data",e);
    } finally {
      if(results!=null)
        try { results.close(); } catch (Throwable t) {}
    }
  }

  /*********************************************************************
   * Sets a flag indicating whether or not this server is responsible
   * for the given naming authority.  
   *********************************************************************/
  public synchronized void setHaveNA(byte authHandle[], boolean flag)
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    getConnection();
    
    boolean currentlyHaveIt = haveNA(authHandle);
    if(currentlyHaveIt==flag)
      return;

    try {
      authHandle = Util.upperCase(authHandle);
      if(currentlyHaveIt) { // we already have it but need to remove it
        setNa(delNAStatement, 1, authHandle);
        int result =  delNAStatement.executeUpdate();
      } else { // we need to add the NA to the database
        setNa(addNAStatement, 1, authHandle);
        int result = addNAStatement.executeUpdate();
      }
      numOperations++;
    } catch (Exception e) {
      // force a reconnect because something is likely wrong with
      // the SQL connection
      sqlConnection = null;
      
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error accessing NA data",e);
    }
  }
  

  private synchronized boolean handleExists(byte handle[])
    throws HandleException
  {
    ResultSet results = null;
    try {
      setHandle(handleExistsStatement, 1, handle);
      results = handleExistsStatement.executeQuery();
      if(results.next() && results.getInt(1)>0) {
        return true;
      }
      return false;
    } catch (Exception e) {
      // force a reconnect because something is likely wrong with
      // the SQL connection
      sqlConnection = null;
      
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error checking for existing handle",e);
    } finally {
      if(results!=null)
        try { results.close(); } catch (Throwable t) {}
    }
  }

  public static final String encodeString(String str) {
    int len = str.length();
    StringBuffer sb = new StringBuffer(len+4);
    for(int i=0; i<len; i++) {
      char ch = str.charAt(i);
      if(ch >= 0x7f || ch < 0x20 || ch=='%') {
        sb.append('%');
        sb.append(HEX_VALUES[(ch >> 12)&0xf]);
        sb.append(HEX_VALUES[(ch >> 8)&0xf]);
        sb.append(HEX_VALUES[(ch >> 4)&0xf]);
        sb.append(HEX_VALUES[ch & 0xf]);
      } else {
        sb.append(ch);
      }
    }
    return sb.toString();
  }

  private static final char HEX_VALUES[] = {'0','1','2','3','4','5','6','7',
                                            '8','9','A','B','C','D','E','F'};

  private static final char decodeChar(char ch1, char ch2, char ch3, char ch4) {
    int ich1 = (ch1>='a') ? (ch1-'a')+10 : ((ch1>='A') ? (ch1-'A')+10 : (ch1-'0'));
    int ich2 = (ch2>='a') ? (ch2-'a')+10 : ((ch2>='A') ? (ch2-'A')+10 : (ch2-'0'));
    int ich3 = (ch3>='a') ? (ch3-'a')+10 : ((ch3>='A') ? (ch3-'A')+10 : (ch3-'0'));
    int ich4 = (ch4>='a') ? (ch4-'a')+10 : ((ch4>='A') ? (ch4-'A')+10 : (ch4-'0'));
    return (char)((ich1<<12) | (ich2<<8) | (ich3<<4) | (ich4));
  }
  
  public static final String decodeString(String str) {
    int len = str.length();
    StringBuffer sb = new StringBuffer(len);
    for(int i=0; i<len; i++) {
      char ch = str.charAt(i);
      if(ch=='%' && i<len-4) {
        char encCh1 = str.charAt(++i);
        char encCh2 = str.charAt(++i);
        char encCh3 = str.charAt(++i);
        char encCh4 = str.charAt(++i);
        sb.append(decodeChar(encCh1, encCh2, encCh3, encCh4));
      } else {
        sb.append(ch);
      }
    }
    return sb.toString();
  }

  /*********************************************************************
   * Creates the specified handle in the "database" with the specified
   * initial values
   *********************************************************************/
  public synchronized void createHandle(byte handle[], HandleValue values[])
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    getConnection();
    
    String handleStr = Util.decodeString(handle);

    // if the handle already exists, throw an exception
    if(handleExists(handle))
      throw new HandleException(HandleException.HANDLE_ALREADY_EXISTS,
                                handleStr);

    if(values==null)
      throw new HandleException(HandleException.INVALID_VALUE);

    boolean success = false;
    Throwable e = null;
    try {
      sqlConnection.setAutoCommit(false);
      
      for(int i=0; i<values.length; i++) {
        // handle, index, type, data, ttl_type, ttl, timestamp, references,
        // admin_read, admin_write, pub_read, pub_write

        HandleValue val = values[i];
        setHandle(createHandleStatement, 1, handle);
        createHandleStatement.setInt(2, val.getIndex());
        if(storeHandleValueTypeAsString) {
            createHandleStatement.setString(3, val.getTypeAsString());
        } else {
        createHandleStatement.setBytes(3, val.getType());
        }
        createHandleStatement.setBytes(4, val.getData());
        createHandleStatement.setByte(5, val.getTTLType());
        createHandleStatement.setInt(6, val.getTTL());
        createHandleStatement.setInt(7, val.getTimestamp());
        StringBuffer sb = new StringBuffer();
        ValueReference refs[] = val.getReferences();
        for(int rv=0; refs!=null && rv < refs.length; rv++) {
          if(rv!=0)
            sb.append('\t');
          sb.append(refs[rv].index);
          sb.append(':');
          sb.append(StringUtils.encode(Util.decodeString(refs[rv].handle)));
        }
        createHandleStatement.setString(8, encodeString(sb.toString()));

        createHandleStatement.setBoolean(9, val.getAdminCanRead());
        createHandleStatement.setBoolean(10, val.getAdminCanWrite());
        createHandleStatement.setBoolean(11, val.getAnyoneCanRead());
        createHandleStatement.setBoolean(12, val.getAnyoneCanWrite());
        
        createHandleStatement.executeUpdate();
      }
      success = true;
    } catch (Exception sqlExc) {
      e = sqlExc;
    } finally {
      try {
        if(success) {
          sqlConnection.commit();
        } else {
          sqlConnection.rollback();
        }
      } catch (Throwable t) {
        e = t;
      } finally {
        try {
          sqlConnection.setAutoCommit(true);
        } catch (Throwable t2){
          if(e!=null)
            e = t2;
        }
      }
    }
    
    numOperations++;
    
    if(e!=null) {
      // force a reconnect because something is likely wrong with
      // the SQL connection
      sqlConnection = null;
      
      e.printStackTrace(System.err);
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error creating handle",e);
    }
  }

  
  /*********************************************************************
   * Delete the specified handle in the database.
   *********************************************************************/
  public synchronized boolean deleteHandle(byte handle[])
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    getConnection();
    
    boolean deleted;
    try {
      setHandle(deleteHandleStatement, 1, handle);
      deleted = deleteHandleStatement.executeUpdate() > 0;
      numOperations++;
    } catch (Exception e) {
      // force a reconnect because something is likely wrong with
      // the SQL connection
      sqlConnection = null;
      
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error deleting handle");
    }
    return deleted;
  }

  
  /*********************************************************************
   * Return the pre-packaged values of the given handle that are either
   * in the indexList or the typeList.  This method should return any
   * values of type ALIAS or REDIRECT, even if they were not requested.
   *********************************************************************/
  public synchronized byte[][] getRawHandleValues(byte handle[], int indexList[],
                                                  byte typeList[][])
    throws HandleException
  {
    getConnection();
    
    ResultSet results = null;
    try {
      setHandle(getHandleStatement, 1, handle);
      results = getHandleStatement.executeQuery();

      boolean allValues = ((typeList==null || typeList.length==0) &&
                           (indexList==null || indexList.length==0));
      
      Vector values = new Vector();

      boolean handleExists = false;
      while(results.next()) {
        handleExists = true;
        HandleValue value = new HandleValue();

        value.setIndex(results.getInt(1));
        if(storeHandleValueTypeAsString) {
            value.setType(Util.encodeString(results.getString(2)));
        } else {
        value.setType(getBytesFromResults(results, 2));
        }

        if(allValues){}
        else if(!Util.isParentTypeInArray( typeList, value.getType()) &&
                !Util.isInArray( indexList, value.getIndex())) // ignore non-requested types
          continue;

        value.setData(getBytesFromResults(results, 3));
        value.setTTLType(results.getByte(4));
        value.setTTL(results.getInt(5));
        value.setTimestamp(results.getInt(6));
        String referencesStr = getStringFromResults(results, 7);

        // parse references...
        String references[] = StringUtils.split(referencesStr,'\t');
        if(references!=null && referencesStr.length()>0 && references.length>0){
          ValueReference valReferences[] = new ValueReference[references.length];
          for(int i=0; i<references.length; i++) {
            valReferences[i] = new ValueReference();
            int colIdx = references[i].indexOf(':');
            try {
              valReferences[i].index = Integer.parseInt(references[i].substring(0,colIdx));
            } catch (Exception t) {}
            valReferences[i].handle =
              Util.encodeString(StringUtils.decode(references[i].substring(colIdx+1)));
          }
          value.setReferences(valReferences);
        }
        
        value.setAdminCanRead(results.getBoolean(8));
        value.setAdminCanWrite(results.getBoolean(9));
        value.setAnyoneCanRead(results.getBoolean(10));
        value.setAnyoneCanWrite(results.getBoolean(11));
        values.addElement(value);
      }

      numOperations++;
      
      if(!handleExists)
        return null;

      byte rawValues[][] = new byte[values.size()][];
      for(int i=0; i<rawValues.length; i++) {
        HandleValue value = (HandleValue)values.elementAt(i);
        rawValues[i] = new byte[Encoder.calcStorageSize(value)];
        Encoder.encodeHandleValue(rawValues[i], 0, value);
      }
      
      return rawValues;
      
    } catch (Exception e) {
      // force a reconnect because something is likely wrong with
      // the SQL connection
      sqlConnection = null;
      
      e.printStackTrace();
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error retrieving handle");
    }
  }

  /*********************************************************************
   * Replace the current values for the given handle with new values.
   *********************************************************************/
  public synchronized void updateValue(byte handle[], HandleValue values[])
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    if(!handleExists(handle))
      throw new HandleException(HandleException.HANDLE_DOES_NOT_EXIST);

    boolean success = false;
    Throwable e = null;
    try {
      deleteHandle(handle);
      createHandle(handle, values);
    } catch (Exception sqlExc) {
      e = sqlExc;
    } 
    if(e!=null) {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Error updating values",e);
    }
  }

  /*********************************************************************
   * Add the specified value records for the given handle.
   *********************************************************************/
  public void addValues(byte handle[], HandleValue values[])
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    throw new HandleException(HandleException.INTERNAL_ERROR,
                              "Not implemented yet!!");
  }

  /*********************************************************************
   * Remove the values that are included in the specified type list
   * or index list.
   *********************************************************************/
  public void removeValues(byte handle[], byte typeList[][], int indexList[])
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    throw new HandleException(HandleException.INTERNAL_ERROR,
                              "Not implemented yet!!");
  }

  /*********************************************************************
   * Scan the database, calling a method in the specified callback for 
   * every handle in the database.
   *********************************************************************/
  public void scanHandles(ScanCallback callback)
    throws HandleException
  {
    getConnection();

    PreparedStatement scanStatement = null;
    ResultSet results = null;
    boolean isMySql = false;
    Connection connection;
    try {
        isMySql = sqlConnection.getMetaData().getDatabaseProductName().toLowerCase().contains("mysql");
        if(isMySql) {
            Connection savedConnection = sqlConnection; 
            // can't reuse connection
            clearConnection();
            connection = savedConnection;
        }
        else connection = sqlConnection;
        scanStatement = connection.prepareStatement(SCAN_HANDLES_STMT,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
        if(isMySql) {
            // set to streaming
            scanStatement.setFetchSize(Integer.MIN_VALUE);
        }
        results = scanStatement.executeQuery();

        while(results.next()) {
            byte b[] = getHandleBytesFromResults(results, 1);
            callback.scanHandle(b);
        }
        numOperations++;
    } catch (SQLException e) {
      e.printStackTrace();
      // force a reconnect because something is likely wrong with
      // the SQL connection
      if(!isMySql) clearConnection();
      
      throw new HandleException(HandleException.INTERNAL_ERROR,"SQL Error",e);
    } catch(Exception e) {
        e.printStackTrace();
    } finally {
      if(scanStatement!=null)
        try { scanStatement.close(); } catch (Throwable e) {}
      if(results!=null)
        try { results.close(); } catch (Throwable e) {}
    }
  }

  /*********************************************************************
   * Scan the NA database, calling a method in the specified callback for 
   * every naming authority handle in the database.
   *********************************************************************/
  public void scanNAs(ScanCallback callback)
    throws HandleException
  {

      PreparedStatement scanStatement = null;
      ResultSet results = null;
      boolean isMySql = false;
      Connection connection;
      try {
          if(isMySql) {
              Connection savedConnection = sqlConnection; 
              // can't reuse connection
              clearConnection();
              connection = savedConnection;
          }
          else connection = sqlConnection;
          scanStatement = connection.prepareStatement(SCAN_NAS_STMT,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
          if(isMySql) {
              // set to streaming
              scanStatement.setFetchSize(Integer.MIN_VALUE);
          }
          results = scanStatement.executeQuery();

          while(results.next()) {
              byte b[] = getNaBytesFromResults(results, 1);
              callback.scanHandle(b);
          }
          numOperations++;
      } catch (SQLException e) {
        // force a reconnect because something is likely wrong with
        // the SQL connection
        if(!isMySql) clearConnection();
      
      throw new HandleException(HandleException.INTERNAL_ERROR,"SQL Error",e);
    } finally {
      if(scanStatement!=null)
        try { scanStatement.close(); } catch (Throwable e) {}
      if(results!=null)
        try { results.close(); } catch (Throwable e) {}
    }
  }


  
  /*********************************************************************
   * Scan the database for handles with the given naming authority
   * and return an Enumeration of byte arrays with each byte array
   * being a handle.  <i>naHdl</i> is the naming authority handle
   * for the naming authority that you want to list the handles for.
   *********************************************************************/
  public final Enumeration getHandlesForNA(byte naHdl[])
    throws HandleException
  {
    if(!haveNA(naHdl)) {
      throw new HandleException(HandleException.INVALID_VALUE,
                                "The requested naming authority doesn't live here");
    }
    
    boolean isZeroNA = Util.startsWithCI(naHdl,Common.NA_HANDLE_PREFIX);
    if(isZeroNA) naHdl = Util.getSuffixPart(naHdl);
    return new ListHdlsEnum(naHdl);
  }


  /*********************************************************************
   * Remove all of the records from the database.
   ********************************************************************/
  public synchronized void deleteAllRecords()
    throws HandleException
  {
    if(readOnly) throw new HandleException(HandleException.STORAGE_RDONLY,
                                           "Server is read-only");

    //getConnection();
    //try {
      //sqlConnection.createStatement().executeUpdate(DELETE_ALL_HDLS_STMT);
      //sqlConnection.createStatement().executeUpdate(DELETE_ALL_NAS_STMT);
    //} catch (SQLException e) {
    //  throw new HandleException(HandleException.INTERNAL_ERROR, "SQL Error: "+e);
    //}
  }


  public void checkpointDatabase()
    throws HandleException
  {
    throw new HandleException(HandleException.SERVER_ERROR,
                              "Checkpoint not supported in this storage type");
  }
  
  /*********************************************************************
   * Close the database and clean up
   *********************************************************************/
  public synchronized void shutdown() {
    if(sqlConnection!=null) {
      try {
        sqlConnection.close();
        sqlConnection = null;
      } catch (Throwable t) {}
    }
  }

  public synchronized void clearConnection() {
      sqlConnection = null;
  }

  /**
   * Helpers to compensate for some SQL providers' tendency to return null for empty strings
   **/
  private final String getStringFromResults(ResultSet results, int i)
  throws SQLException 
  {
    String s = results.getString(i);
    return s == null ? "" : decodeString(s);
  }

  private void setHandle(PreparedStatement statement, int i, byte[] x) throws SQLException {
      if(storeHandleAsString) {
          statement.setString(i, Util.decodeString(x));
      } else {
          statement.setBytes(i, x);
      }
  }

  private void setNa(PreparedStatement statement, int i, byte[] x) throws SQLException {
      if(storeNaAsString) {
          statement.setString(i, Util.decodeString(x));
      } else {
          statement.setBytes(i, x);
      }
  }

  private final byte[] getBytesFromResults(ResultSet results, int i)
  throws SQLException 
  {
    if(compensateForOracleJDBCBug) {
      String s = results.getString(i);
      if(s==null) return new byte[0];
      return Util.encodeHexString(s);
    }
    byte b[] = results.getBytes(i);
    return (b==null) ? new byte[0] : b;
  }

  private final byte[] getHandleBytesFromResults(ResultSet results, int i)
  throws SQLException 
  {
    if(storeHandleAsString) {
        String s = results.getString(i);
        if(s==null) return new byte[0];
        return Util.encodeString(s);
    } else {
        return getBytesFromResults(results,i);
    }
  }

  private final byte[] getNaBytesFromResults(ResultSet results, int i)
  throws SQLException 
  {
    if(storeNaAsString) {
        String s = results.getString(i);
        if(s==null) return new byte[0];
        return Util.encodeString(s);
    } else {
        return getBytesFromResults(results,i);
    }
  }

  private class ListHdlsEnum
    implements Enumeration
  {
    private ResultSet results = null;
    private PreparedStatement scanStatement = null;
    private byte nextVal[] = null;
    private byte[] prefix;
    
    ListHdlsEnum(byte prefix[])
      throws HandleException
    {
      this.prefix = prefix;
      try {
        getConnection();
        scanStatement = sqlConnection.prepareStatement(SCAN_BYPREFIX_STMT);
        setHandle(scanStatement, 1, Util.encodeString(Util.decodeString(prefix)+"_%"));
        results = scanStatement.executeQuery();
      } catch (SQLException e) {
        throw new HandleException(HandleException.INTERNAL_ERROR,"SQL Error",e);
      }
      getNextValue();
    }

    public boolean hasMoreElements() {
      return nextVal!=null;
    }

    public Object nextElement() {
      byte returnVal[] = nextVal;
      if(returnVal!=null) getNextValue();
      return returnVal;
    }

    private void getNextValue() {
      nextVal = null;
      if(results==null)
        return;
      try {
        if(results.next()) {
            byte[] candNextVal = getHandleBytesFromResults(results, 1);
            if(candNextVal[prefix.length]==(byte)'/' || 
                    (candNextVal[prefix.length]==(byte)'.' && Util.indexOf(candNextVal,(byte)'/')==-1)) { 
                nextVal = candNextVal;
            }
            else {
                getNextValue();
            }
        } else {
          // no more values... close it up..
          if(scanStatement!=null) {
            try {
              scanStatement.close();
              scanStatement = null;
            } catch (Throwable t) {
              System.err.println("Error closing SQL statement: "+t);
            } finally {
              scanStatement = null;
            }
          }
          if(results!=null) {
            try {
              results.close();
            } catch (Throwable t) {
              System.err.println("Error closing SQL result set: "+t);
            } finally {
              results = null;
            }
          }
        }
      } catch (Exception e) {
        System.err.println("Error retrieving handles: "+e);
        e.printStackTrace(System.err);
      }
    }
  }
  
}


