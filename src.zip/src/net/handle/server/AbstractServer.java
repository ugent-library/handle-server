/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.cnri.util.StreamTable;
import net.handle.hdllib.*;

public abstract class AbstractServer {
  public static final String SERVER_TYPE = "server_type";
  public static final String HDLSVR_ID = "server";
  public static final String HDLSVR_CONFIG = "server_config";
  public static final String CACHESVR_ID = "cache";
  public static final String CACHESVR_CONFIG = "cache_config";
  public static final String PROXYSVR_ID = "proxy";
  public static final String PROXYSVR_CONFIG = "proxy_config";
  public static final String TRACE_MESSAGES = "trace_outgoing_messages";

  protected volatile boolean keepRunning = true;

  protected HandleResolver resolver;
  protected Main main;

  private RootInfoUpdater riu;
  
  // refresh the root site info once a day
  private static final long ROOT_REFRESH_INTERVAL = 86400000;

  protected AbstractServer() {
      // for testing
  }
  
  protected AbstractServer(Main main, StreamTable config) {
    this.main = main;
    this.resolver = main.getResolver();

    if(config!=null && config.containsKey(TRACE_MESSAGES)) {
      String traceMessagesStr = String.valueOf(config.get(TRACE_MESSAGES));
      traceMessagesStr = traceMessagesStr.toUpperCase();
      if(traceMessagesStr.startsWith("Y")) {
        resolver.traceMessages = true;
      }
    }
    

    riu = new RootInfoUpdater();
    riu.setDaemon(true);
    riu.start();
  }
  
  /**********************************************************************
   * Given a request object, should handle the request and return a response
   **********************************************************************/
  public abstract void processRequest(AbstractRequest req,
                                      ResponseMessageCallback callback)
    throws HandleException;


  /**********************************************************************
   * Tell the server to shutdown (save open files and clean up resources)
   **********************************************************************/
  public void shutdown() {
      keepRunning = false;
      riu.interrupt();
  }


  /**
   * Tell the server to re-dump all handles from a primary handle server
   */
  public abstract void dumpHandles()
  throws HandleException, java.io.IOException;


  /**********************************************************************
   * Create a server instance based on the configuration.
   **********************************************************************/
  public static AbstractServer getInstance(Main main, StreamTable configTable)
    throws Exception
  {
    String serverType = String.valueOf(configTable.get(SERVER_TYPE));
    if(serverType.equals(HDLSVR_ID)) {
      StreamTable config = (StreamTable)configTable.get(HDLSVR_CONFIG);
      if(config==null) throw new Exception("Configuration setting \""+HDLSVR_CONFIG+"\" is required.");
      return new HandleServer(main, config);

    } else if(serverType.equals(CACHESVR_ID)) {
        StreamTable config = (StreamTable)configTable.get(CACHESVR_CONFIG);
        if(config==null) throw new Exception("Configuration setting \""+CACHESVR_CONFIG+"\" is required.");
      return new CacheServer(main, config);

    } else {
      throw new Exception("Configuration setting \""+SERVER_TYPE+"\" must be "+
                          "\""+HDLSVR_ID+"\", or \""+CACHESVR_ID+"\"");
    }
    
  }



  private class RootInfoUpdater
    extends Thread
  {

    public void run() {
      while(keepRunning) {
        try {
          resolver.getConfiguration().refreshRootInfoFromNet();
        } catch (Throwable t) {
          main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,"Error refreshing root info: "+t);
          t.printStackTrace(System.err);
        }
        
        long startSleep = System.currentTimeMillis();
        long currTime = startSleep;
        long endSleep = startSleep + ROOT_REFRESH_INTERVAL;
        do {
          if(currTime<endSleep) {
            try {
              sleep(endSleep-currTime);
            } 
            catch (InterruptedException e) {
              Thread.currentThread().interrupt();
            }
            catch (Throwable t) {
              main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Error: Root info updater can't sleep: "+t);
            }
          }
          currTime = System.currentTimeMillis();
        } while(keepRunning && currTime<endSleep);
        
      }
    }
  }

}
