/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security;

import java.math.*;
import java.security.interfaces.*;
import net.handle.hdllib.Util;

public class DSAPublicKeyImpl 
  implements DSAPublicKey
{
  private BigInteger y;
  private DSAParams params;
  
  public DSAPublicKeyImpl(BigInteger y, DSAParams params) 
    throws NumberFormatException
  {
    this.y = y;
    this.params = params;
  }
  
  public BigInteger getY() { return y; }

  public DSAParams getParams() { return params; }

  public String getAlgorithm() { return "DSA"; }

  public String getFormat() { return "HDL_DSA_PUB"; }
  
  public byte[] getEncoded() {
    try {
      return Util.getBytesFromPublicKey(this);
    } catch (Exception e) {
      System.err.println("Error encoding public key: "+e);
      return null;
    }
  }
}

