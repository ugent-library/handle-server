/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import net.cnri.simplexml.XParser;
import net.cnri.simplexml.XTag;
import net.cnri.util.StringUtils;
import net.handle.apps.servlet_proxy.handlers.Location;
import net.handle.hdllib.*;
import net.handle.util.LRUCacheTable;

import java.io.StringReader;
import java.text.ParseException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.http.*;

import com.ibm.icu.text.IDNA;


/** HDLServletRequest contains the handle, parameters, and other information
  * associated with a single handle resolution request. */
public class HDLServletRequest {
  
  private static LRUCacheTable locationsCache = new LRUCacheTable(4096);

  private static HashMap<String,String> SPECIFIC_BROWSER_CONTENT_TYPES = new HashMap<String,String>();
  static {
    SPECIFIC_BROWSER_CONTENT_TYPES.put("text/html", "");
    SPECIFIC_BROWSER_CONTENT_TYPES.put("text/xhtml", "");
    SPECIFIC_BROWSER_CONTENT_TYPES.put("application/xhtml+xml", "");
    SPECIFIC_BROWSER_CONTENT_TYPES.put("application/pdf", "");
    SPECIFIC_BROWSER_CONTENT_TYPES.put("application/vnd.wap.xhtml+xml", "");
    SPECIFIC_BROWSER_CONTENT_TYPES.put("text/vnd.wap.wml", "");
  }
  
  
  // comparator used to sort the Accept header entries by quality
  private static Comparator<AcceptEntry> acceptEntrySorter = new Comparator<AcceptEntry>() {
    public int compare(AcceptEntry o1, AcceptEntry o2) {
      float result = o1.quality - o2.quality;
      if(result<0f) return 1;
      if(result>0f) return -1;
      return 0;
    }
  };
  
  public HDLProxy servlet;
  public HttpServletRequest req;
  public HttpServletResponse response;
  public String hdl = null;
  public HttpParams params = new HttpParams();
  public AuthenticationInfo authenticationInfo;
  
  public static boolean GENERIC_RDF_ENABLED = false;
  public boolean userWantsRDF = false;
  public boolean api = false;
  
  public ResolutionRequest resRequest = null;
  public AbstractResponse resResponse = null;
  public long resolutionTime;
  public HandleException exception;
  
  private long expiration = Long.MAX_VALUE;
  
  private HandleResolver resolver = null;

  private long intime;
  
  public enum ResponseType {
    SEE_OTHER(303, "See Other"),
    MOVED_TEMPORARILY(307, "Moved Temporarily"),
    OLD_MOVED_TEMPORARILY(302, "Moved Temporarily"),
    MOVED_PERMANENTLY(301, "Moved Permanently");
    
    public static final ResponseType DEFAULT_RESPONSE_TYPE = ResponseType.SEE_OTHER;
    
    int responseCode;
    String message;
    
    ResponseType(int responseCode, String message) {
      this.responseCode = responseCode;
      this.message = message;
    }
    
    /**
     * Return the appropriate response type for the given string, which is expected
     * to appear with attribute "http" in the list of 10320/loc locations.
     */
    public static ResponseType typeForString(String typeStr) {
      if(typeStr==null) return DEFAULT_RESPONSE_TYPE;
      if(typeStr.equals("")) return DEFAULT_RESPONSE_TYPE;
      if(typeStr.equals("303")) return SEE_OTHER;
      if(typeStr.equals("307")) return MOVED_TEMPORARILY;
      if(typeStr.equals("302")) return OLD_MOVED_TEMPORARILY;
      if(typeStr.equals("301")) return MOVED_PERMANENTLY;
      return DEFAULT_RESPONSE_TYPE; 
    }
    
  }
  
  
  public HDLServletRequest(HDLProxy proxy, HttpServletRequest req, HttpServletResponse response, HandleResolver resolver) {
    //this(servlet, req, response, req.getRequestURI(), resolver);
    intime = System.currentTimeMillis();
    this.resolver = resolver;
    this.servlet = proxy;
    this.req = req;
    this.response = response;
    String requestURI = req.getRequestURI(); 
    if(req.getQueryString()==null || req.getQueryString().length()==0) {
        int n = requestURI.indexOf('#');
        if(n >= 0) requestURI = requestURI.substring(0,n);
    }
    requestURI = StringUtils.decodeURLIgnorePlus(requestURI);
    String contextPath = StringUtils.decodeURLIgnorePlus(req.getContextPath());
    int indexOfContextPath = requestURI.indexOf(contextPath);
    String pathInfo = indexOfContextPath < 0 ? requestURI : requestURI.substring(indexOfContextPath + contextPath.length());
    this.hdl = pathInfo;
    if(this.hdl==null) this.hdl = "";
    while(this.hdl.startsWith("/")) this.hdl = this.hdl.substring(1).trim();
    
    if(req.getMethod().equalsIgnoreCase("POST")) {
      for (Enumeration e=req.getParameterNames(); e.hasMoreElements();){
        String key = (String)e.nextElement();
        params.addParameters(key, (String[])req.getParameterValues(key));
      }
      String hdlStr = req.getParameter("hdl");
      if(hdlStr!=null) this.hdl = hdlStr.trim();
    } else if(req.getMethod().equalsIgnoreCase("GET")) {
      parseGetParams(req.getRequestURI(), req.getQueryString());
    }
    
    // replace any action=metadata parameters with locatt=role:metadata
    boolean setMetadataParam = false;
    String actionParam = params.getParameter(HDLProxy.ACTION_PARAM);
    if(actionParam!=null && actionParam.equalsIgnoreCase(HDLProxy.ACTION_METADATA)) {
      params.replaceParameterValue(HDLProxy.ACTION_PARAM, HDLProxy.ACTION_REDIRECT);
      params.addParameter("locatt", "role:metadata");
      setMetadataParam = true;
    }
    
    // lift query parameters to locatt parameters as configured (use for ap)
    List<String> locattParams = proxy.locattShortcutParameters.get(req.getServerName().toLowerCase());
    if(locattParams==null) locattParams = proxy.locattShortcutParameters.get("default");
    for(String locattParam : locattParams) {
        String value = params.getParameter(locattParam);
        if(value!=null) {
            params.addParameter("locatt",locattParam + ":" + value);
        }
    }
        
    // parse the Accept: header to see if they're looking specifically for metadata
    List<AcceptEntry> accepts = new ArrayList<AcceptEntry>();
    List<String> acceptsHeaders = getRequestHeader("accept");
    boolean acceptsNormalContent = false;
    for(String field : acceptsHeaders) { // iterate over multiple accepts headers
      String[] entries = StringUtils.split(field, ',');
      for(String headerValue : entries) { // iterate over the acceptable types
        AcceptEntry acceptEntry = new AcceptEntry(StringUtils.split(headerValue, ';'));
        
//        if(acceptEntry.acceptsBrowserContent()) {
//          acceptsNormalContent = true;
//          break;
//        } else {
          accepts.add(acceptEntry);
//        }
      }
      if(acceptsNormalContent) break;
    }
    
    // if html has the highest quality score, then this is a browser request and shouldn't do conneg
    float htmlScore = 0f;
    float maxScore = 0f;
    for(AcceptEntry acceptEntry : accepts) {
      float thisScore = acceptEntry.quality;
      if(thisScore > maxScore) maxScore = thisScore;
      if(thisScore > htmlScore && acceptEntry.acceptsBrowserContent()) htmlScore = thisScore;
    }
    
    // if the 'html score' is not one of the highest-quality content types, do conneg
    // and add locatt requests for specific content types
    if(htmlScore < maxScore) {
      if(!setMetadataParam) params.addParameter("locatt", "http_role:conneg");
      Collections.sort(accepts, acceptEntrySorter);
      // System.err.println("accept header requests non-browser content:\n  "+accepts);
      for(AcceptEntry acceptEntry : accepts) {
        if(acceptEntry.hasWildcard()) break;
        if(GENERIC_RDF_ENABLED && acceptEntry.contentType.equals("application/rdf+xml")) userWantsRDF = true; 
        params.addParameter("locatt", "ctype:"+acceptEntry.contentType);
      }
    }
  }
  
  
  private void parseGetParams(String URI, String query) {
    if(query==null || query.length()==0) {
      int n = URI.indexOf('#');
      if(n >= 0) params.addParameter("urlappend", StringUtils.decodeURLIgnorePlus(URI.substring(n)));
    }
    else {
      int n = query.indexOf('#');
      if(n >= 0) {
        params.addParameter("urlappend", StringUtils.decodeURLIgnorePlus(query.substring(n)));
        query = query.substring(0,n);
      }
      StringTokenizer st = new StringTokenizer(query, "&;");
      while (st.hasMoreTokens()){
        String s = st.nextToken();
        String key, val;
        int pos = s.indexOf('=');
        if (pos >= 0){
          key = s.substring(0, pos);
          val = s.substring(pos+1);
        } else {
          key = s;
          val = "";
        }
        params.addParameter(StringUtils.decodeURLIgnorePlus(key), StringUtils.decodeURLIgnorePlus(val));
        // if ("id".equals(key)) hdl = val;
      }
    }
  }
  
  
  /** Resolve the handle for this request based on the query parameters.  A side
   * effect of this method is that the resRequest and resResponse members are set
   * to non-null values (well, resResponse may be null if there was an exception 
   * during resolution.
   */
  public synchronized void resolveHandle() throws HandleException {
    
    byte types[][] = getRequestedTypes();
    int indices[] = null;
    try {
      indices = getRequestedIndices();
    } catch (Exception e) { } // we used to throw an exception here, now just ignore badly formatted indices

    resolveHandle(types, indices,
                  authenticationInfo==null, 
                  params.getParameter("auth")!=null,
                  params.getParameter("cert")!=null);
    
    if(resResponse!=null && resResponse.responseCode==AbstractMessage.RC_INVALID_ADMIN &&
        !resRequest.ignoreRestrictedValues) {
      resolveHandle(types, indices, true, resRequest.authoritative, resRequest.certify);
    }
  }
  
  /** send or re-send a resolution request for the requested handle with the given parameters */
  public synchronized void resolveHandle(byte types[][], int indices[],
                                         boolean ignoreRestrictedValues,
                                         boolean authoritative, 
                                         boolean certified)
  throws HandleException
  {
    resRequest = new ResolutionRequest(Util.encodeString(hdl),
                                       types, indices,
                                       authenticationInfo);
    resRequest.ignoreRestrictedValues = ignoreRestrictedValues;
    resRequest.authoritative = authoritative;
    resRequest.certify = certified;
    resolutionTime = System.currentTimeMillis();
    resResponse = resolver.processRequest(resRequest);
  }
  
  
  private class CachedTag {
    private long expirationDate = System.currentTimeMillis() + 60000 * 60; // default cache timeout: one hour
    private XTag cachedTag;
    
    CachedTag(XTag tagToCache) {
      this.cachedTag = tagToCache;
    }
    
    XTag cachedTag() { return cachedTag; }
    
    boolean isExpired() { return expirationDate <= System.currentTimeMillis(); }
  }
  
  private static XParser xmlParser = new XParser();

  /**
   * Find and return the first XML location structure in the given handle,
   * caching the parsed locations so as to avoid re-parsing the handle values
   * (which may also be cached at the handle resolution level).
   */
  public XTag resolveLocations(String handle) {
    if(handle==null) return null;
    boolean auth = params.getParameter("auth")!=null;
    boolean cert = params.getParameter("cert")!=null;
    CachedTag cachedVal = null;
    if(!auth && !cert) cachedVal = (CachedTag)locationsCache.get(handle);
    if(cachedVal!=null && !cachedVal.isExpired()) {
      if(cachedVal.expirationDate < expiration) expiration = cachedVal.expirationDate;
      return cachedVal.cachedTag();
    }
    
    try {
      ResolutionRequest hdlReq = new ResolutionRequest(Util.encodeString(handle),
                                                       new byte[][] { Location.LOCATION_TYPE },
                                                       null, null);
      hdlReq.authoritative = auth;
      hdlReq.certify = cert;
      long locResolutionTime = System.currentTimeMillis();
      AbstractResponse hdlResp = resolver.processRequest(hdlReq);
      if(hdlResp instanceof ResolutionResponse) {
        for(HandleValue value : ((ResolutionResponse)hdlResp).getHandleValues()) {
          if(value.hasType(Location.LOCATION_TYPE)) {
            modifyExpiration(locResolutionTime,value);
            String locationsStr = Util.decodeString(value.getData());
            
            XTag locXML = xmlParser.parse(new StringReader(locationsStr), false);
            if(locXML!=null) {
              CachedTag cachedTag = new CachedTag(locXML);
              cachedTag.expirationDate = expirationDateFor(locResolutionTime,value);
              locationsCache.put(handle, cachedTag);
              return locXML;
            }
          }
        }
      }
      
      return null;
    } catch (Exception e) {
      System.err.println("Error resolving locations for "+handle);
      
      // TODO:  is returning an expired cache entry when encountering an error better than failing?
      return cachedVal==null ? null : cachedVal.cachedTag();
    }
    
  }
  
  /** Remove any prefixes such as hdl: doi: info:doi/ etc. */
  public void normalizeHandle() {
    // remove any namespace prefixes
    String lowerHdl = hdl.toLowerCase();
    if(lowerHdl.startsWith("api/")) {
        api = true;
        hdl = hdl.substring(4);
        lowerHdl = lowerHdl.substring(4);
    }
    if(lowerHdl.startsWith("info:doi/") || lowerHdl.startsWith("info:hdl/")) {
      hdl = hdl.substring(9);
    } else if(lowerHdl.startsWith("hdl:") || lowerHdl.startsWith("doi:")) {
      hdl = hdl.substring(4);
    } else if(lowerHdl.startsWith("urn:hdl:") || lowerHdl.startsWith("urn:doi:")) {
        // First colon in a handle URN will be treated as a slash
        hdl = hdl.substring(8);
        int colon = hdl.indexOf(':');
        int slash = hdl.indexOf('/');
        if(colon>=0 && (slash<0 || slash>colon)) {
            hdl = hdl.substring(0,colon) + "/" + hdl.substring(colon+1);
        }
    }
  }
  
  
  /** Return the URL from which the request was linked */
  public String getReferer() {
    String ref = req.getHeader("Referer");
    return ref==null ? "" : ref;
  }
  
  
  public List<String> getRequestHeader(String headerName) {
    List<String> values = new ArrayList<String>();
    
    Enumeration<?> hvals = req.getHeaders(headerName.toString());
    while ( hvals.hasMoreElements() ) {
      String hval = String.valueOf(hvals.nextElement());
      values.add(hval);
    }
    
    return values;
  }
  
  
  /** Close the request and response objects and any other resources that may
    * have been used to process the request. */
  public void close() {
    try { req.getInputStream().close(); } catch (Exception e) {}
    try { response.getOutputStream().close(); } catch (Exception e) {}
  }
  
  public long getResponseTime() {
    return System.currentTimeMillis() - intime;
  }
  
  private int[] getRequestedIndices() {
    // parse requested types and indices from http request
    int indices[] = null;
    String s[] = params.getParameterValues("index");
    if (s != null) {
      indices = new int[s.length];
      for (int i=0; i<s.length; i++) indices[i] = Integer.parseInt(s[i]);
    }
    return indices;
  }
  
  private byte[][] getRequestedTypes() {
    // parse requested types and indices from http request
    byte types[][] = null;
    String s[] = params.getParameterValues("type");
    if (s != null) {
      types = new byte[s.length][];
      for (int i=0; i<s.length; i++) types[i] = Util.encodeString(s[i]);
    }
    return types;
  }
  
  
  public String getURLForHandle(String handle) {
      return getURLForHandle(handle,"");
  }

  public String getURLForHandle(String handle, String query) {
    if(query==null) query = "";
    String baseURL = servlet.getHandleLinkPrefix(req);
    if(baseURL.endsWith("/") || baseURL.endsWith(":"))
        return baseURL+StringUtils.encodeURLPath(handle) + query;
    else
        return baseURL+"/"+StringUtils.encodeURLPath(handle) + query;
  }
  
  private static final boolean haveIDNA;
  static {
      boolean found;
      try {
          Class.forName("com.ibm.icu.text.IDNA", false, HDLServletRequest.class.getClassLoader());
          found = true;
      }
      catch(ClassNotFoundException e) {
          found = false;
      }
      haveIDNA = found;
  }
  
  /**
   * Encodes an IRI as a URI.  Finds the domain name of an http:, https:, or ftp: URI and IDNA-encodes it (Nameprep/Punycode).
   * On current (mid-2010) browsers this is required to have the browser find the location.
   * Officially that step is optional and in fact we'll skip it if there's any problem (including if the IDNA jarfile is missing). 
   * Then percent-encodes everything else.
   */
  public String encodeIRIToURI(String location) {
      if(!haveIDNA) return StringUtils.encodeURL(location);
      String lower = location.toLowerCase();
      if(lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("ftp://")) {
          int startOfHost = location.indexOf(':') + 3;
          boolean potentialIDN = false;
          int endOfHost = location.length();
          int colon = endOfHost;
          boolean seenAt = false, seenColon = false;
          for(int i = startOfHost; i < endOfHost; i++) {
              char ch = location.charAt(i);
              if(ch>=128 && !seenColon) potentialIDN = true;
              else if(!seenAt && ch=='@') {
                  seenAt = true;
                  seenColon = false;
                  startOfHost = i + 1;
                  potentialIDN = false;
              }
              else if(ch=='/' || ch=='?' || ch=='#') {
                  endOfHost = i; 
                  break;
              }
              else if(!seenColon && ch==':') {
                  seenColon = true;
                  colon = i;
                  if(seenAt) break;
              }
          }
          if(seenColon) endOfHost = colon;

          if(potentialIDN) {
              String host = location.substring(startOfHost,endOfHost);
              try {
                  StringBuffer encodedHost = IDNA.convertIDNToASCII(host,IDNA.ALLOW_UNASSIGNED);
                  StringBuilder sb = new StringBuilder(location);
                  sb.replace(startOfHost,endOfHost,encodedHost.toString());
                  return StringUtils.encodeURL(sb.toString());
              }
              catch(ParseException e) {
                  // really, StringPrepParseException only; but we need not to mention it
                  // or class loader will complain if IDNA jarfile is missing; exception tables are static,
                  // and mentioned exceptions are loaded even if never exercised
              }
          }
      }
      
      return StringUtils.encodeURL(location);
  }
  
  /**
   * Send an HTTP redirect to the given location.  The kind of redirect depends 
   * upon the given redirectType.
   */
  public void sendHTTPRedirect(ResponseType redirectType, String location) {
    if(req.getProtocol().startsWith("HTTP/1.0") && redirectType!=ResponseType.MOVED_PERMANENTLY) {
      redirectType = ResponseType.OLD_MOVED_TEMPORARILY;
    }
    response.setStatus(redirectType.responseCode);
    response.setHeader("Location", encodeIRIToURI(location.trim()));
    if(getExpiration() < Long.MAX_VALUE) {
        response.setDateHeader("Expires",getExpiration());
    }
  }
  
  /** Set the expiration date sooner based on a value from the resRequest/resResponse fields */
  public void modifyExpiration(HandleValue val) {
      modifyExpiration(resolutionTime,val);
  }
  
  /** Set the expiration date sooner based on a value which may come from a different resolution */
  public void modifyExpiration(long aResolutionTime, HandleValue val) {
      long newExpiration = expirationDateFor(aResolutionTime,val);
      if(newExpiration < expiration) {
          expiration = newExpiration;
      }  
  }
  
  public long expirationDateFor(long aResolutionTime, HandleValue val) {
      long newExpiration;
      if(val.getTTLType()==HandleValue.TTL_TYPE_ABSOLUTE) {
          newExpiration = 1000L * val.getTTL();
      }
      else {
          newExpiration = aResolutionTime + 1000L * val.getTTL();
      }
      newExpiration = Math.min(newExpiration, aResolutionTime + 1000L * HandleValue.MAX_RECOGNIZED_TTL);
      return newExpiration;
  }

  public long getExpiration() {
      return expiration;
  }
  
  public class AcceptEntry {
    public String contentType;
    public float quality = 1f;
    
    AcceptEntry(String acceptFields[]) {
      this.contentType = acceptFields==null || acceptFields.length<=0 ? "*/*" : acceptFields[0];
      if(this.contentType!=null) this.contentType = this.contentType.trim().toLowerCase();
      if(acceptFields!=null && acceptFields.length>1) {
        // only look for "q" fields
        for(int i=1; i<acceptFields.length; i++) {
          String field = acceptFields[i].trim();
          if(field.startsWith("q=")) {
            try { quality = Float.parseFloat(field.substring(2)); } catch (Exception nfe) {}
          }
        }
      }
    }
    
    public String toString() { return "{"+contentType+"; q="+quality+"} (normal="+acceptsBrowserContent()+")"; }
    
    public boolean acceptsBrowserContent() {
      if(contentType==null) return true;
      if(contentType.indexOf('*')>=0) return true;
      if(SPECIFIC_BROWSER_CONTENT_TYPES.containsKey(contentType)) return true;
      if(contentType.startsWith("image/")) return true;
      if(contentType.startsWith("audio/")) return true;
      if(contentType.startsWith("video/")) return true;
      return false;
    }
    
    boolean hasWildcard() {
      return contentType==null || contentType.indexOf('*')>=0;
    }
    

  }
  


}


