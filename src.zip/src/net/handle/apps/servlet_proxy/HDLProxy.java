/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import net.handle.apps.servlet_proxy.HDLServletRequest.ResponseType;
import net.handle.hdllib.*;
import net.cnri.simplexml.*;
import net.cnri.util.StringUtils;

public class HDLProxy
  extends HttpServlet
{
    
  // constants
  public static final String ACTION_PARAM = "action";
  public static final String ACTION_REDIRECT = "redirect";
  public static final String ACTION_SHOWLOCS = "showurls";
  public static final String ACTION_SHOWVALUES = "showvalues";
  public static final String ACTION_TOOLBAR = "toolbar";
  public static final String ACTION_METADATA = "metadata";
  public static final String ACTION_REST = "api";
  public static final String FORMAT_PARAM = "format";
  
  public static final int MAX_ALIASES = 20;
  
  private static final String ACCEPT_HEADER_NAME = "Accept";
  
  private static final int DEFAULT_MAX_MESSAGE_LENGTH = 1024;
  public static final byte MSG_INVALID_MSG_SIZE[] =
    Util.encodeString("Invalid message length");
  public static final byte MSG_INVALID_REQUEST[] =
    Util.encodeString("Invalid request");
  
  Map<String,String> handleLinkPrefixMap = new HashMap<String,String>();
  
  protected String HTDOCS = "";
  public static Object resolverInitLock = new Object();
  public static HandleResolver resolver = null;
  private static MemCache memCache;
  protected static final NamespaceInfo DEFAULT_NAMESPACE_INFO = new NamespaceInfo();

  protected Properties config;
  private RotatingAccessLog logger;
  private boolean logReferrer = false;
  private boolean logHSAdmin = false;
  private boolean logUserAgent = false;
  private String favicon = null;
  private String defaultAction = ACTION_REDIRECT; // ACTION_TOOLBAR;
  
  // Map of type handlers, set from config props
  HashMap typeHandlers;
  class TypeHandlerEntry {
    TypeHandler handler;
    int position;
  }
  protected TypeHandler valueHandlers[] = {};
  
  // virtual host -> page mappings
  Hashtable<String, HTMLFile> queryPages = new Hashtable<String, HTMLFile>();
  Hashtable<String, HTMLFile> helpPages = new Hashtable<String, HTMLFile>();
  protected Hashtable<String, HTMLFile> errorPages = new Hashtable<String, HTMLFile>();
  Hashtable<String, HTMLFile> responsePages = new Hashtable<String, HTMLFile>();
  Hashtable<String, HTMLFile> valuesNotFoundPages = new Hashtable<String, HTMLFile>();
  
  Map<String,Boolean> retryAuthOnNotFound = new HashMap<String,Boolean>(); // if true, will re-try resolutions auth when originally not found

  Map<String,List<String>> locattShortcutParameters = new HashMap<String,List<String>>(); // query parameters automatically changed to locatt parameters
  
  // sfx
  boolean sfxEnabled;
  String sfxCookieName;    
  
  public synchronized void destroy() {
    loadedSettings = false;
    if(logger!=null) logger.shutdown();
    if(memCache!=null) memCache.close();
    logger = null;
  }

  protected volatile boolean loadedSettings = false;
  private boolean showToolbarDefault = false;
  
  protected void loadSettings()
    throws ServletException
  {
    if(loadedSettings) return;
    synchronized(resolverInitLock) {
      if(loadedSettings) return;
      System.err.println("initializing DOI/HDL proxy servlet");
      ServletConfig slConfig = getServletConfig();
      System.err.println("  servlet config: ");
      for(Enumeration en=slConfig.getInitParameterNames(); en.hasMoreElements(); ) {
        Object name = en.nextElement();
        System.err.println("   "+name+": "+slConfig.getInitParameter(String.valueOf(name)));
      }
      
      ServletContext slContext = slConfig.getServletContext();
      System.err.println("  context config: ");
      for(Enumeration en=slContext.getInitParameterNames(); en.hasMoreElements(); ) {
        Object name = en.nextElement();
        System.err.println("   "+name+": "+slContext.getInitParameter(String.valueOf(name)));
      }
      
      // init type handler map, with sort on position 
      typeHandlers = new HashMap();
      
      // load configuration properties
      config = new Properties();
      try {
        String configFileStr = getServletConfig().getInitParameter("config");
        System.err.println("  base path: "+(new File(".").getCanonicalPath()));
        System.err.println("  config file: "+configFileStr);
        config.list(System.err);
        File configFile = null;
        if (configFileStr!=null) configFile = new File(configFileStr);
        if(configFile!=null && configFile.exists() && configFile.canRead()) {
          System.err.println("Loading settings from "+configFile.getCanonicalPath());
          config.load(new FileInputStream(configFile));
        } else {
          InputStream in = getServletContext().getResourceAsStream("/WEB-INF/hdlproxy.properties");
          if(in!=null) {
              System.err.println("Loading settings from /WEB-INF/hdlproxy.properties");
              config.load(in);
          }
          else {
              System.err.println("Loading default settings");
              config.load(getClass().getResourceAsStream("hdlproxy.properties"));
          }
        }
        //config.list(System.err);
      } catch (IOException e) {
        throw new ServletException("Error loading servlet properties: "+e);
      }
      
      // htdocs dir
      HTDOCS = config.getProperty("htdocs");
        
      favicon = config.getProperty("favicon",null);
      if(favicon == null) {
          String faviconURL = config.getProperty("favicon_url", null);
          if(faviconURL!=null) favicon = "redirect:" + faviconURL.trim();
      } else favicon = favicon.trim();
      
      // prefix string (e.g "hdl:") used before handle links
      
      handleLinkPrefixMap.put("default",config.getProperty("handle_link_prefix"));
      // also allow per-host setting
      
      // get the singleton logger so that we don't clobber the logs from other servlets
      try {
        String logFileName = config.getProperty("access_log");
        if(logFileName!=null) {
          File logDir = new File(logFileName).getParentFile();
          System.err.println("loading logger for hdl/doi proxy");    
          System.err.println(" log folder: "+logDir.getAbsolutePath());
          logger = RotatingAccessLog.getMonthlyLogger(logDir);
        }
      } catch (Exception e){
        throw new ServletException("Error loading logger: "+e);
      }
      
      sfxEnabled = config.get("sfx_cookie")!=null;
      sfxCookieName = (String)config.get("sfx_cookie");
      logReferrer = Boolean.valueOf(config.getProperty("log_referrer","true")).booleanValue();
      logHSAdmin = Boolean.valueOf(config.getProperty("log_hs_admin","false")).booleanValue();
      logUserAgent = Boolean.valueOf(config.getProperty("log_user_agent","true")).booleanValue();
      // create a sorted list of handlers 
      TreeSet<HDLProxy.TypeHandlerEntry> handlers = 
        new TreeSet<HDLProxy.TypeHandlerEntry>(new Comparator<HDLProxy.TypeHandlerEntry>() {
        public int compare(HDLProxy.TypeHandlerEntry o1, HDLProxy.TypeHandlerEntry o2) {
          return o1.position - o2.position;
        }
      });
      
      retryAuthOnNotFound.put("default",Boolean.valueOf(config.getProperty("retry_auth_on_not_found","false")));

      {
          StringTokenizer st = new StringTokenizer(config.getProperty("locatt_shortcut_parameters",""));
          List<String> locattParams = new ArrayList<String>();
          while(st.hasMoreTokens()) locattParams.add(st.nextToken());
          locattShortcutParameters.put("default",locattParams);
      }
      
      // iterate through rest of config options for more control
      for (Enumeration enumeration=config.propertyNames(); enumeration.hasMoreElements();){
        String prop = (String)enumeration.nextElement();
        // type handler setting
        if (prop.startsWith("typehandler.")){
          TypeHandlerEntry entry = new TypeHandlerEntry();
          String klass = config.getProperty(prop);
          try {
            String pos = prop.substring("typehandler.".length());
            entry.position = Integer.parseInt(pos);
            entry.handler = (TypeHandler)Class.forName(klass).newInstance();
            handlers.add(entry);
          } catch (Exception e) {
            System.err.println("Error setting "+prop+" = "+klass+": "+e);
          }
        }
        // html pages
        else if (prop.startsWith("query-page.")){
          try {
            String host = prop.substring("query-page.".length()).toLowerCase();
            String file = config.getProperty(prop).trim();
            queryPages.put(host, new HTMLFile(HTDOCS, file, getServletContext()));
          }
          catch (Exception e){
            System.err.println("Error setting query page: "+prop+"\n"+e);
          }
        }
        else if (prop.startsWith("help-page.")){
          try {
            String host = prop.substring("help-page.".length()).toLowerCase();
            String file = config.getProperty(prop).trim();
            helpPages.put(host, new HTMLFile(HTDOCS, file, getServletContext()));
          }
          catch (Exception e){
            System.err.println("Error setting help page: "+prop+"\n"+e);
          }
        }
        else if (prop.startsWith("response-page.")){
          try {
            String host = prop.substring("response-page.".length()).toLowerCase();
            String file = config.getProperty(prop).trim();
            responsePages.put(host, new HTMLFile(HTDOCS, file, getServletContext()));
          }
          catch (Exception e) {
            System.err.println("Error setting response page: "+prop);
          }
        }
        else if (prop.startsWith("novalues-page.")){
          try {
            String host = prop.substring("novalues-page.".length()).toLowerCase();
            String file = config.getProperty(prop).trim();
            valuesNotFoundPages.put(host, new HTMLFile(HTDOCS, file, getServletContext()));
          }
          catch (Exception e) {
            System.err.println("Error setting valuesnotfound page: "+prop);
          }
        }
        else if (prop.startsWith("error-page.")){
          try {
            String host = prop.substring("error-page.".length()).toLowerCase();
            String file = config.getProperty(prop).trim();
            errorPages.put(host, new HTMLFile(HTDOCS, file, getServletContext()));
          }
          catch (Exception e){
            System.err.println("Error setting error page: "+prop);
          }
        }
        else if (prop.startsWith("retry_auth_on_not_found.")) {
            String host = prop.substring("retry_auth_on_not_found.".length()).toLowerCase();
            boolean val = Boolean.valueOf(config.getProperty(prop));
            retryAuthOnNotFound.put(host,val);
        }
        else if (prop.startsWith("handle_link_prefix.")) {
            String host = prop.substring("handle_link_prefix.".length()).toLowerCase();
            handleLinkPrefixMap.put(host,config.getProperty(prop).trim());
        }
        else if (prop.startsWith("locatt_shortcut_params.")) {
            String host = prop.substring("locatt_shortcut_params.".length()).toLowerCase();
            StringTokenizer st = new StringTokenizer(config.getProperty(prop,""));
            List<String> locattParams = new ArrayList<String>();
            while(st.hasMoreTokens()) locattParams.add(st.nextToken());
            locattShortcutParameters.put(host,locattParams);
        }
      }
      
      // copy the sorted list of handlers into a faster array
      valueHandlers = new TypeHandler[handlers.size()];
      Iterator iter = handlers.iterator();
      for(int i=0; i<valueHandlers.length; i++) {
        valueHandlers[i] = ((TypeHandlerEntry)iter.next()).handler;
      }
      
      // init resolver and set cache
      synchronized(resolverInitLock) {
        if (resolver == null){
          resolver = new HandleResolver();
          resolver.traceMessages = config.getProperty("trace_msgs", "false").equals("true");
          initResolver();
        }
      }
      loadedSettings = true;
    }
  }

  // for ease of override
  public void initResolver() {
    memCache = new MemCache(1024*16, 60*60, true);
    resolver.setCache(memCache);
  }
  
  private void handleFavicon(HttpServletResponse resp) throws IOException {
      if(favicon.startsWith("redirect:")) {
          String faviconURL = favicon.substring("redirect:".length());
          resp.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
          resp.setDateHeader("Expires",System.currentTimeMillis() + 7*24*60*60*1000);
          resp.setHeader("Location", faviconURL);
          try {
              resp.getWriter().write("Favicon moved to "+faviconURL);
          } catch (Exception t) {}
      } else if(favicon.startsWith("servlet:")) {
          String path = favicon.substring("servlet:".length());
          InputStream in = getServletContext().getResourceAsStream(path);
          if(in==null) {
              resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
          } else {
              try {
                  resp.setStatus(HttpServletResponse.SC_OK);
                  resp.setContentType("image/x-icon");
                  copyInputToOutput(in,resp.getOutputStream());
              } finally {
                  in.close();
              }
          }
      } else if(favicon.startsWith("res:")) {
          String path = favicon.substring("res:".length());
          InputStream in = getClass().getResourceAsStream(path);
          if(in==null) {
              resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
          } else {
              try {
                  resp.setStatus(HttpServletResponse.SC_OK);
                  resp.setContentType("image/x-icon");
                  copyInputToOutput(in,resp.getOutputStream());
              } finally {
                  in.close();
              }
          }
      } else {
          File file = new File(favicon);
          if(!file.exists()) {
              resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
          } else {
              InputStream in = new FileInputStream(favicon);
              try {
                  resp.setStatus(HttpServletResponse.SC_OK);
                  resp.setContentType("image/x-icon");
                  copyInputToOutput(in,resp.getOutputStream());
              } finally {
                  in.close();
              }
          }
      }
  }
  
  private static void copyInputToOutput(InputStream in, OutputStream out) throws IOException {
      byte[] buf = new byte[4096];
      int r;
      while((r = in.read(buf)) > 0) {
          out.write(buf,0,r);
      }
  }
  
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws IOException, ServletException
  {
    loadSettings();

    if (handleSpecial(req,resp)) return;
    
    HDLServletRequest hdlReq = new HDLServletRequest(this, req, resp, resolver);
    
    try {
      doResponse(hdlReq);
    } finally {
      hdlReq.close();
    }
  }

  protected boolean handleSpecial(HttpServletRequest req, HttpServletResponse resp) throws IOException {
      String servletPath = req.getServletPath();
      String pathInfo = req.getPathInfo();
      String path = (pathInfo==null) ? servletPath : (servletPath + pathInfo);
      if(favicon!=null && path.startsWith("/favicon.ico")) { // short-cut favorite icon retrieval
          handleFavicon(resp);
          return true;
      } else if(path.startsWith("/robots.txt")) { // short-cut robots.txt requests
          resp.setStatus(HttpServletResponse.SC_OK);
          resp.setContentType("text/plain");
          Writer w = resp.getWriter();
          w.write("Crawl-delay: 5\n");
          w.write("Request-rate: 1/5\n");
          try { w.close(); } catch (Exception e) {}
          try { req.getInputStream().close(); } catch (Exception e) {}
          return true;
      }
      return false;
  }
  
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws IOException, ServletException
  {
    loadSettings();
    
    HDLServletRequest hdl = new HDLServletRequest(this, req, resp, resolver);
    
    String accept = hdl.req.getHeader("Accept");
    if(accept!=null &&
       accept.toUpperCase().indexOf(Common.HDL_MIME_TYPE.toUpperCase())>=0){
      processNativeRequest(hdl);
      return;
    }
    
    try {
      doResponse(hdl);
    } finally {
      hdl.close();
    }
  }
  
  
  protected void doResponse(HDLServletRequest hdl)
    throws IOException, ServletException
  {
    if(hdl.hdl==null || hdl.hdl.length()<=0) {
      returnQueryPage(hdl);
      return;
    }
    if(hdl.hdl.equals("help.html")) {
      returnHelpPage(hdl);
      return;
    }
    
    hdl.normalizeHandle();
    
    doResolution(hdl, 0);
  }
  
  
  void processNativeRequest(HDLServletRequest hdl) 
    throws IOException, ServletException 
  {
    int r, n=0;
    byte envelopeBuf[] = new byte[Common.MESSAGE_ENVELOPE_SIZE];
    MessageEnvelope envelope = new MessageEnvelope();
    
    InputStream in = hdl.req.getInputStream();
    
    // ignore extra newline char, if necessary
    r = in.read();
    if(r!='\n' && r!='\r') {
      envelopeBuf[0] = (byte)r;
      n++;
    }
    
    // receive and parse the message envelope
    while(n < Common.MESSAGE_ENVELOPE_SIZE &&
          (r=in.read(envelopeBuf, n, Common.MESSAGE_ENVELOPE_SIZE-n))>=0) {
      n += r;
    }
    
    if(n < Common.MESSAGE_ENVELOPE_SIZE) {
      // not all of the envelope was received...
      //sendNativeResponse(envelope, envelopeBuf, 
      //                   new ErrorResponse(AbstractMessage.OC_RESERVED,
      //                                     AbstractMessage.RC_ERROR,
      //                                     MSG_INVALID_MSG_SIZE), hdl);
      logAccess("HTTP:HDL", AbstractMessage.OC_RESERVED,
                AbstractMessage.RC_PROTOCOL_ERROR, hdl, null);
      
      return;
    }
    
    try {
      Encoder.decodeEnvelope(envelopeBuf, envelope);
    } catch (HandleException e) {
      sendNativeResponse(envelope, envelopeBuf, 
                         new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_ERROR,
                                           Util.encodeString("Error decoding request")), hdl);
      return;
    }
    
    if(envelope.messageLength > Common.MAX_MESSAGE_LENGTH ||
       envelope.messageLength < 0) {
      sendNativeResponse(envelope, envelopeBuf, 
                         new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_ERROR,
                                           MSG_INVALID_MSG_SIZE), hdl);
      return;
    }
    
    
    byte messageBuf[] = new byte[envelope.messageLength];
    
    // receive the rest of the message
    r = n = 0;
    while(n<envelope.messageLength &&
          (r=in.read(messageBuf, n, envelope.messageLength-n))>=0) {
      n += r;
    }
    
    AbstractRequest hdlreq = null;
    try {
      if(n<envelope.messageLength)
        throw new HandleException(HandleException.MESSAGE_FORMAT_ERROR,
                                  "Expecting "+envelope.messageLength+" bytes, "+
                                  "only received "+n);
      
      hdlreq = (AbstractRequest)Encoder.decodeMessage(messageBuf, 0, envelope);
      hdl.hdl = Util.decodeString(hdlreq.handle);
      AbstractResponse hdlresp = resolver.processRequest(hdlreq);
      sendNativeResponse(envelope, envelopeBuf, hdlresp, hdl);
    } catch (HandleException e) {
      sendNativeResponse(envelope, envelopeBuf, 
                         new ErrorResponse(AbstractMessage.OC_RESERVED, 
                                           AbstractMessage.RC_ERROR,
                                           Util.encodeString(e.getMessage())), hdl);
      return;
    }
  }
  
  void sendNativeResponse(MessageEnvelope envelope, byte envelopeBuf[], 
                          AbstractResponse hdlresp, HDLServletRequest hdl){
    OutputStream out = null;
    try {
      byte msg[] = hdlresp.getEncodedMessage();
      boolean encrypted = false;
      
      envelope.sessionId = hdlresp.sessionId;
      envelope.requestId = hdlresp.requestId;
      envelope.messageId = 0;
      envelope.messageLength = msg.length;
      
      Encoder.encodeEnvelope(envelope, envelopeBuf);

      hdl.response.setContentType(Common.HDL_MIME_TYPE);
      hdl.response.setContentLength(envelopeBuf.length+msg.length);
      
      out = hdl.response.getOutputStream();
      out.write(Util.concat(envelopeBuf,msg));
      out.flush();
      
      logAccess("HTTP:HDL", hdlresp.opCode, hdlresp.responseCode, hdl, null);
      
      // if the response is "streamable," send the streamed part...
      if(hdlresp.streaming) {
        out = new BufferedOutputStream(out);
        hdlresp.streamResponse(out);
        out.flush();
      }
    } catch (Exception e) {
      System.err.println("Exception sending response: "+e);
    }
  }
  
  
  
  /** Perform handle resolution and return a redirect or HTML page.  The
    * aliasCount parameter indicates the maximum number of redirections that
    * we should return before assuming a loop is occurring. */
  void doResolution(HDLServletRequest hdl, int aliasCount) 
    throws IOException, ServletException
  {
    boolean clientUsesLocalResolver = false;
    String localResolverURL = null;
    
    // if invoking a toolbar, show the toolbar before anything else...
    boolean showToolbar = showToolbarDefault;
    
    String action = hdl.params.getParameter(ACTION_PARAM);
    String format = hdl.params.getParameter(FORMAT_PARAM);
    if(action==null && "json".equalsIgnoreCase(format)) action = ACTION_REST; 
    if(action==null && hdl.params.getParameter("noredirect")!=null) {
      action = "showvalues";
    }
    
    if(action==null) { // there is no explicit action, so find a sensible default
      action = defaultAction;
    }
    action = action.toLowerCase();
    
    // do sfx/local-copy redirect if sfx/local-copy cookie is present
    if (defaultAction.equals(action) && sfxEnabled && hdl.req.getCookies()!=null) {
      for (int i=0; i<hdl.req.getCookies().length; i++){
        Cookie cookie = hdl.req.getCookies()[i];
        if (cookie!=null && cookie.getName().equals(sfxCookieName)){
          String sfxBaseURL = cookie.getValue();
          clientUsesLocalResolver = true;
          localResolverURL = sfxBaseURL;
          if (sfxBaseURL!=null &&
              hdl.params.getParameter("nosfx")==null &&
              hdl.params.getParameter("nols")==null) {
            
            if (sfxBaseURL.startsWith("\"")) sfxBaseURL = sfxBaseURL.substring(1);
            if (sfxBaseURL.endsWith("\"")) {
              sfxBaseURL = sfxBaseURL.substring(0, sfxBaseURL.length()-1);
            }
            String url;
            String queryStr = hdl.req.getQueryString();
            if (queryStr!=null && queryStr.length()>0) {
              // If there was a query string, it was due to an unencoded question
              // mark in the handle, and encode it for the open URL version.
              url = StringUtils.encodeURLComponent(hdl.hdl+"?"+hdl.req.getQueryString());
            } else {
              url = StringUtils.encodeURLComponent(hdl.hdl);
            }
            
            logAccess("HTTP:SFX", AbstractResponse.OC_RESOLUTION, 0, hdl, null,
                      "sfxredirect:"+sfxBaseURL);
            
            hdl.sendHTTPRedirect(ResponseType.OLD_MOVED_TEMPORARILY, sfxBaseURL+"?id=doi:"+url);
            return;
          }
        }
      }
    }
    
    if(hdl.api || ACTION_REST.equals(action)) {
        resolveRestfully(hdl);
        return;
    }
    
    // resolve handle
    NamespaceInfo nsInfo = null;
    HandleValue vals[] = null;
    try {
      hdl.resolveHandle();
      
      // if we were querying non-authoritatively and we are configured to re-query 
      // non-authoritative resolutions resulting in not-found responses then submit
      // the query again with the authoritative flag not set
      if (!hdl.resRequest.authoritative && hdl.resResponse!=null && 
          hdl.resResponse.responseCode == AbstractMessage.RC_HANDLE_NOT_FOUND) {
        Boolean retry = this.retryAuthOnNotFound.get(hdl.req.getServerName().toLowerCase());
        if(retry==null) retry = this.retryAuthOnNotFound.get("default");
        if(retry==null) retry = Boolean.FALSE;
        if(retry) {
          hdl.resolveHandle(hdl.resRequest.requestedTypes, 
                            hdl.resRequest.requestedIndexes,
                            hdl.resRequest.ignoreRestrictedValues, 
                            true, // authoritative
                            hdl.resRequest.certify);
        }
      }
      
      nsInfo = hdl.resRequest.getNamespace();
      
      String msg = "";
      if(nsInfo!=null && nsInfo.getNamespaceStatus().equals(NamespaceInfo.STATUS_INACTIVE)) {
        // the namespace has an inactive status...
        msg = "Inactive Namespace";
        logAccess("HTTP:HDL", AbstractResponse.OC_RESOLUTION, 
                  AbstractMessage.RC_ERROR, hdl, null);
        returnErrorPage(msg, hdl, nsInfo, null, false);
        return;
      } else if (hdl.resResponse==null || hdl.resResponse.responseCode!=AbstractMessage.RC_SUCCESS) {
        // create a friendly message
        if (hdl.resResponse == null) {
          msg = "Resolution Error";
        } else if (hdl.resResponse.responseCode == AbstractMessage.RC_HANDLE_NOT_FOUND) {
          msg = "Not Found";
        } else if (hdl.resResponse.responseCode == AbstractMessage.RC_VALUES_NOT_FOUND) {
          // should this not be an error?  maybe just show an empty response
          // page?
          msg ="No Values Found";
          if(hdl.resRequest.requestedTypes!=null && hdl.resRequest.requestedTypes.length>0) {
            // if the user was querying for specific types, return a special
            // do-you-want-to-get-more-info error page
            logAccess("HTTP:HDL", AbstractResponse.OC_RESOLUTION, 
                      hdl.resResponse.responseCode, hdl, null);
            returnValuesNotFoundPage(msg, hdl, null);
            return;
          }
        } else {
          msg = "Resolution Error";
        }
        logAccess("HTTP:HDL", AbstractResponse.OC_RESOLUTION, 
                  hdl.resResponse.responseCode, hdl, null);
        returnErrorPage(msg, hdl, nsInfo, null, hdl.resResponse.responseCode == AbstractMessage.RC_HANDLE_NOT_FOUND);
        return;
      }
      vals = ((ResolutionResponse)hdl.resResponse).getHandleValues();
    } catch (HandleException e) {
      if(nsInfo==null) try { nsInfo = hdl.resRequest.getNamespace(); } catch(Exception ex) {}
      String msg = "";
      if (e.getCode() == HandleException.SERVICE_NOT_FOUND){
        int index = hdl.hdl.indexOf("/");
        String na = (index != -1) ? hdl.hdl.substring(0, index) : hdl.hdl;
        msg = "Naming Authority [" + na + "] Not Found";
      } else if (e.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER){
        msg = "Cannot Connect to Server";
      } else {
        msg = "System Error";
//        e.printStackTrace();  // TODO
      }
      logAccess("HTTP:HDL", AbstractResponse.OC_RESOLUTION, 
                AbstractResponse.RC_ERROR, hdl, null);
      hdl.exception = e;
      returnErrorPage(msg, hdl, nsInfo, null, e.getCode() == HandleException.SERVICE_NOT_FOUND);
      return;
    }
    
    // if not disabled, follow aliases
    if (hdl.params.getParameter("ignore_aliases")==null){
      for(int i=0; i<vals.length; i++) {
        if (vals[i].hasType(Common.STD_TYPE_HSALIAS)) {
          if(aliasCount<MAX_ALIASES) {
            hdl.hdl = Util.decodeString(vals[i].getData());
            hdl.modifyExpiration(vals[i]);
            doResolution(hdl, aliasCount+1);
            return;
          } else {
            returnErrorPage("Alias chain too long", hdl, nsInfo, null, false);
            return;
          }
        }
      }
    }
    
    try {
      if(action.equals(ACTION_SHOWVALUES)) {
        returnResponsePage(hdl, vals);
      } else if(action.equals(ACTION_SHOWLOCS)) {
        doShowLocations(hdl, vals);
      } else if(action.equals(ACTION_TOOLBAR)) {
        doShowToolbar(hdl, vals);
      } else /* if(action.equals(ACTION_REDIRECT)) */ {
        // the result of an alias; do a 301 redirect
        // don't try to do this for a POST, however
        if(aliasCount>0 && (hdl.req.getMethod().equalsIgnoreCase("GET") || hdl.req.getMethod().equalsIgnoreCase("HEAD"))) {
            String path = hdl.hdl;
            String query = "";
            if(hdl.req.getQueryString()!=null) query = "?" + hdl.req.getQueryString();
            hdl.sendHTTPRedirect(ResponseType.MOVED_PERMANENTLY,hdl.getURLForHandle(path,query));
        }
        else {
            doRedirect(hdl, vals);
        }
      }
    } finally {      
      logAccess("HTTP:HDL", AbstractResponse.OC_RESOLUTION, 
                hdl.resResponse.responseCode, hdl, vals);
    }
  }

  protected void resolveRestfully(HDLServletRequest hdl) throws IOException {
      AbstractResponse resp;
      try {
          hdl.resolveHandle();
          resp = hdl.resResponse;
      } catch(Exception e) {
          resp = HandleException.toErrorResponse(hdl.resRequest,e);
      }
      String callback = hdl.params.getParameter("callback");
      hdl.response.setStatus(statusCodeFromResponse(resp));
      if(callback==null) hdl.response.setContentType("application/json");
      else hdl.response.setContentType("application/javascript");
      hdl.response.setCharacterEncoding("UTF-8");
      if(callback!=null) hdl.response.getWriter().append(callback).append("(");
      GsonUtility.getGson().toJson(GsonUtility.serializeResponseToRequest(hdl.resRequest,resp),hdl.response.getWriter());
      if(callback!=null) hdl.response.getWriter().append(");");
      HandleValue[] vals = null;
      try {
          if(resp instanceof ResolutionResponse) vals = ((ResolutionResponse)resp).getHandleValues();
      } catch(HandleException e) {}
      logAccess("HTTP:HDL", AbstractResponse.OC_RESOLUTION, 
              resp.responseCode, hdl, vals);
  }
  
  protected int statusCodeFromResponse(AbstractResponse resp) {
      switch(resp.responseCode) {
      case AbstractMessage.RC_SUCCESS: 
      case AbstractMessage.RC_VALUES_NOT_FOUND: return HttpServletResponse.SC_OK;
      case AbstractMessage.RC_NA_DELEGATE:
      case AbstractMessage.RC_SERVICE_REFERRAL: return HttpServletResponse.SC_MULTIPLE_CHOICES;
      case AbstractMessage.RC_HANDLE_NOT_FOUND: return HttpServletResponse.SC_NOT_FOUND;
      case AbstractMessage.RC_HANDLE_ALREADY_EXISTS:
      case AbstractMessage.RC_VALUE_ALREADY_EXISTS: return HttpServletResponse.SC_CONFLICT;
      case AbstractMessage.RC_PROTOCOL_ERROR:
      case AbstractMessage.RC_INVALID_HANDLE:
      case AbstractMessage.RC_INVALID_VALUE: return HttpServletResponse.SC_BAD_REQUEST;
      case AbstractMessage.RC_SERVER_NOT_RESP: return HttpServletResponse.SC_BAD_REQUEST; // TODO: consider other status codes for server not responsible
      case AbstractMessage.RC_OPERATION_NOT_SUPPORTED: return HttpServletResponse.SC_NOT_IMPLEMENTED;
      case AbstractMessage.RC_SERVER_TOO_BUSY:
      case AbstractMessage.RC_SERVER_BACKUP: return HttpServletResponse.SC_SERVICE_UNAVAILABLE;
      case AbstractMessage.RC_AUTHENTICATION_NEEDED: return HttpServletResponse.SC_UNAUTHORIZED;
      case AbstractMessage.RC_INVALID_ADMIN:
      case AbstractMessage.RC_INSUFFICIENT_PERMISSIONS:
      case AbstractMessage.RC_AUTHENTICATION_FAILED:
      case AbstractMessage.RC_INVALID_CREDENTIAL: return HttpServletResponse.SC_FORBIDDEN;
      default: return HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
      }
  }
  
  protected void doShowToolbar(HDLServletRequest hdl, HandleValue vals[]) {
    
  }

  /** Returns a browser redirect based on the queried values.  This is only 
   * called if the 'noredirect' flag is not set.  This method should scan
   * the list of response handlers for the most appropriate one to handle
   * the response.
   */
  protected void doRedirect(HDLServletRequest hdl, HandleValue vals[])
    throws IOException, ServletException
  {
    // iterate over the handlers until one can handle the response
    for(int i=0; i<valueHandlers.length; i++) {
      TypeHandler handler = valueHandlers[i];
      if(handler.canRedirect(vals)) {
        try {
          if(handler.doRedirect(hdl, vals)) return;
        } catch (Exception e) {
          logger.logError(RotatingAccessLog.ERRLOG_LEVEL_NORMAL,
                          "Error showing redirect for '"+hdl.hdl+"': "+e);
          returnErrorPage("Error showing redirect for '"+hdl.hdl+"': "+
                          e.getMessage(), hdl, null, null, false);
          e.printStackTrace(System.err);
          return;
        }
      }
    }
    
    // no handler returned a response, so return results page
    returnResponsePage(hdl, vals);
  }
  
  
  /** Displays a list of all locations to which this handle resolves.  This corresponds
   *  to the "action=show" URI parameter.
   */
  protected void doShowLocations(HDLServletRequest hdl, HandleValue vals[])
    throws IOException, ServletException
  {
    // iterate over the handlers until one can handle the response
    for(int i=0; i<valueHandlers.length; i++) {
      TypeHandler handler = valueHandlers[i];
      if(handler.canShowLocations(vals)) {
        try {
          XTag locations = handler.doShowLocations(hdl, vals);
          if(locations!=null && locations.getSubTagCount()>0) {
            // display a page showing the locations
            hdl.response.setContentType("text/xml; charset=utf-8");
            locations.write(hdl.response.getOutputStream());
            return;
          }
        } catch (Exception e) {
          logger.logError(RotatingAccessLog.ERRLOG_LEVEL_NORMAL,
                          "Error showing locations for '"+hdl.hdl+"': "+e);
          returnErrorPage("Error showing locations for '"+hdl.hdl+"': "+
                          e.getMessage(), hdl, null, null, false);
          return;
        }
      }
    }
    
    // no handler returned a response, so return results page
    returnResponsePage(hdl, vals);
  }
  
  protected void returnErrorPage(String msg, HDLServletRequest hdl,
                               NamespaceInfo nsInfo, String trace, boolean is404) 
    throws IOException
  {
    returnErrorPage(msg, hdl, nsInfo, null, trace, is404);
  }

  
  private void returnValuesNotFoundPage(String msg, HDLServletRequest hdl, String trace) 
    throws IOException
  {
    if (msg == null) msg = "Requested Values Not Found";
    if (trace == null) trace = "";
    
    HTMLFile f =  null;
    try {
      f = valuesNotFoundPages.get(hdl.req.getServerName().toLowerCase());
    } catch (NullPointerException e) { }
    if (f == null) {
      f = valuesNotFoundPages.get("default");
    }
    if (f == null) { // no values-not-found page was found... resort to the error page
      returnErrorPage(msg, hdl, null, trace, false);
      return;
    }
    
    synchronized(f) { // lame synchronization... should use a template here
      f.reset();
      f.setValue("HANDLE_URL", hdl.getURLForHandle(hdl.hdl));
      f.setValue("HANDLE", hdl.hdl);
      f.setValue("ERROR", msg);
      f.setValue("REFERER", hdl.getReferer());
      f.setValue("TRACE", trace);
      
      hdl.response.setContentType("text/html; charset=utf-8");
      f.output(hdl.response.getOutputStream());
    }
  }
  
  protected void returnErrorPage(String msg, HDLServletRequest hdl,
                               NamespaceInfo nsInfo, String ref, String trace, boolean is404) 
    throws IOException 
  {
    if(is404) hdl.response.setStatus(HttpServletResponse.SC_NOT_FOUND);
      
    if (msg == null) msg = "Unknown error.";
    if (trace == null) trace = "";
    
    HTMLFile f =  null;
    try {
      f = errorPages.get(hdl.req.getServerName().toLowerCase());
    } catch (NullPointerException e) { }
    if (f == null) f = errorPages.get("default");
    if (f == null) {
      System.err.println("Error loading error page.");
      hdl.response.setContentType("text/plain");
      hdl.response.getWriter().println("Template page not found!\nError: "+msg);
      return;
    }
    
    synchronized(f) {
      f.reset();
      
      f.setValue("SERVER_ERROR", hdl.exception != null && hdl.exception.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER ? "Yes" : "No");
      
      boolean trailingSlash = hdl.hdl.endsWith("/");
      f.setValue("TRAILING_SLASH", trailingSlash?"Yes":"No");
      if(trailingSlash) {
        f.setValue("NOSLASH_HANDLE_URL", hdl.getURLForHandle(hdl.hdl.substring(0, hdl.hdl.length()-1)));
      } else {
        f.setValue("NOSLASH_HANDLE_URL", hdl.getURLForHandle(hdl.hdl));
      }
      boolean prefixOnly = !hdl.hdl.contains("/") || hdl.hdl.indexOf('/') == hdl.hdl.length() - 1;
      f.setValue("PREFIX_ONLY", prefixOnly?"Yes":"No");
      
      if(nsInfo==null) nsInfo = DEFAULT_NAMESPACE_INFO;
      String contactAddr = nsInfo.getResponsiblePartyContactAddress();
      if(contactAddr!=null && contactAddr.trim().length()>0) {
        contactAddr = contactAddr.trim();
        f.setValue("HAS_NS_CONTACT", "Yes");
        f.setValue("NS_CONTACT", contactAddr);
      }
      
      String nsStatusMsg = nsInfo.getStatusMessage();
      if(nsStatusMsg!=null && nsStatusMsg.trim().length()>0) {
        f.setValue("HAS_NS_STATUS_MSG", "Yes");
        f.setValue("NS_STATUS_MSG", nsStatusMsg.trim());
      }
      f.setValue("NS_STATUS", nsInfo.getNamespaceStatus());
      f.setValue("HANDLE", hdl.hdl);
      f.setValue("ERROR", msg);
      f.setValue("REFERER", hdl.getReferer());
      f.setValue("TRACE", trace);
      
      try {
        hdl.response.setContentType("text/html; charset=utf-8");
        f.output(hdl.response.getOutputStream());
      } catch (Throwable t) {
        System.err.println("Error sending response: "+t);
        t.printStackTrace();
      }
    }
  }
  
  protected void returnResponsePage(HDLServletRequest hdl, HandleValue vals[])
    throws IOException 
  {
    if(vals!=null && vals.length<=0) {
      returnValuesNotFoundPage(null, hdl, null);
      return;
    }
    
    HTMLFile f = responsePages.get(hdl.req.getServerName().toLowerCase());
    if (f == null) f = responsePages.get("default");
    
    StringBuffer page = new StringBuffer();
    if (vals!=null && vals.length > 0) {
      page.append("<tr><td align=\"left\" valign=\"top\">Index</td>");
      page.append("<td align=\"left\" valign=\"top\">Type</td>");
      page.append("<td align=\"left\" valign=\"top\">Timestamp");
      page.append("</td><td align=\"left\" valign=\"top\">Data</td>");
      page.append("</tr>\n");
      for(int i=0; i<vals.length; i++) {
        HandleValue val = vals[i];
        TypeHandler t = null;
        for(int j=0; j<valueHandlers.length; j++) {
          if(valueHandlers[j].canFormat(val)) {
            t = valueHandlers[j];
            break;
          }
        }
        String dataStr;
        if (t!=null) dataStr = t.toHTML(hdl.hdl, val);
        else {
            dataStr = val.getDataAsString();
            if(looksLikeURI(dataStr)) {
                dataStr = StringUtils.htmlEscapeWhitespace(dataStr);
                dataStr = "<a href=\"" + dataStr + "\">" + dataStr + "</a>";
            }
            else dataStr = StringUtils.htmlEscapeWhitespace(dataStr);
        }
        
        page.append("<tr bgcolor=\"#"+ (i%2==0? "dddddd":"ffffff")+"\">");
        page.append("<td align=\"left\" valign=\"top\"><b>");
        page.append(val.getIndex()+"</b>");
        page.append("</td><td align=\"left\" valign=\"top\"><b>");
        String typeAsStr = val.getTypeAsString();
        if(looksLikeURI(typeAsStr)) {
            typeAsStr = StringUtils.htmlEscapeWhitespaceNonBreakingSpaces(typeAsStr);
            page.append("<a href=\"" + StringUtils.encodeURLForAttr(typeAsStr) + "\">" + typeAsStr + "</a>");
        }
        else if(typeAsStr.indexOf("/")>=0) {
            typeAsStr = StringUtils.htmlEscapeWhitespaceNonBreakingSpaces(typeAsStr);
            page.append("<a href=\"" + StringUtils.encodeURLForAttr(hdl.getURLForHandle(typeAsStr)) + "\">" + typeAsStr + "</a>");
        }
        else {
            String ucType = typeAsStr.toUpperCase();
            if(ucType.startsWith("HS_") || ucType.equals("URL") || ucType.equals("DESC") || ucType.equals("EMAIL")) {
                typeAsStr = StringUtils.htmlEscapeWhitespaceNonBreakingSpaces(typeAsStr);
                page.append("<a href=\"" + StringUtils.encodeURLForAttr(hdl.getURLForHandle("0.TYPE/" + typeAsStr)) + "\">" + typeAsStr + "</a>");
            }
            else page.append(StringUtils.htmlEscapeWhitespaceNonBreakingSpaces(typeAsStr));
        }
        page.append("</b></td><td valign=\"top\">");
        page.append(StringUtils.htmlEscapeWhitespaceNonBreakingSpaces(val.getNicerTimestampAsString()));
        page.append("</td>\n");
        page.append("<td>"+dataStr+"</td>");
        page.append("</tr>\n");
      }
    } else {
      page.append("<tr><td align=CENTER><b>No values found.</b></td></tr>");
    }
    
    
    if(f!=null) {
      synchronized(f) {
        f.reset();
        f.setValue("HANDLE", hdl.hdl);
        f.setValue("VALUES", page.toString());
        
        hdl.response.setContentType("text/html; charset=utf-8");
        f.output(hdl.response.getOutputStream());
      }
    }
  }
  
  
  private void returnQueryPage(HDLServletRequest hdl)
    throws IOException
  {
    HTMLFile f = queryPages.get(hdl.req.getServerName().toLowerCase());
    if (f == null) f = queryPages.get("default");
    if (f == null) {
      returnErrorPage("Empty handle invalid.", hdl, null, null, false);
      return;
    }
    hdl.response.setContentType("text/html; charset=utf-8");
    synchronized(f) {
      f.output(hdl.response.getOutputStream());
    }
  }

  private void returnHelpPage(HDLServletRequest hdl)
    throws IOException
  {
    HTMLFile f = helpPages.get(hdl.req.getServerName().toLowerCase());
    if (f == null) f = helpPages.get("default");
    if (f == null) {
      returnErrorPage("help.html not found!", hdl, null, null, false);
      return;
    }
    hdl.response.setContentType("text/html; charset=utf-8");
    synchronized(f) {
      f.output(hdl.response.getOutputStream());
    }
  }

  public static final boolean looksLikeURI(String str) {
      if(str==null) return false;
      int sz = str.length();
      if(sz==0) return false;
      for(int i=0; i<sz; i++) {
          char ch = str.charAt(i);
          if(ch==' ' || ch=='\r' || ch=='\t' || ch=='\n') return false;
      }
      char ch = str.charAt(0);
      if(ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z') {
          for(int j=1; j<sz; j++) {
              ch = str.charAt(j);
              if(ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z' || ch=='+' || ch=='-' || ch=='.') continue;
              if(ch==':') return true;
              break;
          }
      }
      return false;
  }

  
  public void logAccess(String accessType, int oc, int rc,
                        HDLServletRequest req, HandleValue vals[])
  {
    logAccess(accessType, oc, rc, req, vals, null);
  }
    
  public void logAccess(String accessType, int oc, int rc,
                        HDLServletRequest req, HandleValue vals[], 
                        String extraLogEntry)
  {
    if (logger == null) return;
    String addr = "";
    try { addr = req.req.getRemoteAddr(); } catch (Throwable t) {}
    
    StringBuffer msg = new StringBuffer(50);
    msg.append(addr==null ? "" : addr);
    msg.append(' ');
    msg.append(accessType);
    msg.append(" \"");
    String dateStr = String.valueOf(new Date());
    msg.append(dateStr);
    msg.append("\" ");
    msg.append(oc);
    msg.append(' ');
    msg.append(rc);
    msg.append(' ');
    msg.append(req.getResponseTime());
    msg.append("ms ");
    msg.append(req.hdl);
    
    if (logHSAdmin){
      msg.append(" \"");
      boolean firstAdmin = true;
      for (int i=0; vals!=null && i<vals.length; i++){
        if(!vals[i].hasType(Common.STD_TYPE_HSADMIN)) {
          continue;
        }
        AdminRecord adm = new AdminRecord();
        try {
          Encoder.decodeAdminRecord(vals[i].getData(), 0, adm);
        } catch (HandleException e) {
          continue;
        }
        if (!firstAdmin) msg.append(',');
        firstAdmin = false;
        
        msg.append(adm.adminIdIndex);
        msg.append(':');
        encodeLogField(msg, Util.decodeString(adm.adminId));
      }
      msg.append('"');
    }
    
    // log the referrer
    if(logReferrer) {
      msg.append(" \"");
      encodeLogField(msg, req.getReferer());
      msg.append('"');
    }
    
    logger.logAccess(msg.toString());
    if(extraLogEntry!=null) {
      logger.logExtra(dateStr +' ' + extraLogEntry);
    }
    if(logUserAgent) {
        String userAgent = req.req.getHeader("user-agent");
        if(userAgent!=null) {
            logger.logExtra(dateStr + " user-agent:"+userAgent);
        }
    }
  }
  
  private static final void encodeLogField(StringBuffer sb, String str) {
    if(str==null) return;
    int strLen = str.length();
    char ch;
    for(int i=0; i<strLen; i++) {
      ch = str.charAt(i);
      if(ch=='\\')
        sb.append("\\\\");
      else
        sb.append(ch);
    }
  }
  
  public String getHandleLinkPrefix(HttpServletRequest req) {
      String prefix = handleLinkPrefixMap.get(req.getServerName().toLowerCase());
      if(prefix==null) prefix = handleLinkPrefixMap.get("default");
      if(prefix==null) {
          int port = req.getServerPort();
          boolean usePort = true;
          if("http".equalsIgnoreCase(req.getScheme()) && port==80) usePort = false;
          if("https".equalsIgnoreCase(req.getScheme()) && port==443) usePort = false;
          prefix = req.getScheme() + "://" + req.getServerName() + (usePort ? ":" + port : "") + req.getContextPath() + "/";
      }
      return prefix;
  }
  
}
