/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

/**********************************************************************\
 Java servlet lib doesn't support ';' as a CGI delimiter.  This is a wrapper
 class to allow it.
\***********************************************************************/

package net.handle.apps.servlet_proxy;

import java.util.HashMap;
import java.util.ArrayList;

public class HttpParams {
  HashMap<String, ArrayList<String>> params = new HashMap<String, ArrayList<String>>();
  
  public String getParameter(String name){
    ArrayList<String> v = params.get(name);
    if (v == null) return null;
    else return v.get(0);
  }
  
  public void replaceParameterValue(String name, String newValue) {
    ArrayList<String> v = params.get(name);
    if (v == null) return;
    for(int i=0; i<v.size(); i++) {
      v.set(i, newValue);
    }
  }
  
  public String[] getParameterValues(String name){
    ArrayList<String> v = params.get(name);
    if (v == null) return null;
    return v.toArray(new String[v.size()]);
  }
  
  public void addParameter(String name, String val){
    ArrayList<String> v = params.get(name);
    if (v == null){ 
      v = new ArrayList<String>();
      params.put(name, v);
    }
    v.add(val);
  }

  public void addParameters(String name, String vals[]){
    for (int i=0; i<vals.length; i++) addParameter(name, vals[i]);
  }
  
  public void clear(){
    params.clear();
  }
}
