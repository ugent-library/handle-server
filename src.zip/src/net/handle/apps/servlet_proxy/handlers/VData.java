/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy.handlers;

import net.handle.hdllib.*;
import net.cnri.simplexml.*;
import java.io.IOException;
import java.io.OutputStreamWriter;
import net.handle.apps.servlet_proxy.*;
import net.handle.apps.servlet_proxy.HDLServletRequest.ResponseType;

public class VData implements TypeHandler {
  private static final String VDATA_PARAM_KEY = "VData";
  private static final byte VDATA_TYPE[] = {'V','D','a','t','a'};
  private XParser parser = new XParser();
  
  
  /** 
  * Parse the XML from a data value and return the contents of a tag based on
  * the parameters to a request.
  */
  public boolean canRedirect(HandleValue values[]) {
    if(values==null) return false;
    for(int i=values.length-1; i>=0; i--) {
      if(values[i].hasType(VDATA_TYPE))
        return true;
    }
    return false;
  }
  
  
  /** 
    * Return true iff this TypeHandler can format the data from the given
    * HandleValue for a human client.
    */
  public boolean canFormat(HandleValue value) {
    return false;
  }
  
  public String toHTML(String handle, HandleValue value){
    return String.valueOf(value);
  }
  
  public boolean doRedirect(HDLServletRequest req, HandleValue values[])
    throws IOException
  {
    if(values==null) return false;

    // if the VDATA parameter wasn't passed as part of the request then
    // leave this for the normal URL handler
    String vdataParam = req.params.getParameter(VDATA_PARAM_KEY);
    if(vdataParam==null || vdataParam.trim().length()<=0) return false;
    
    // for now just look for the given tag with the 'id' attribute matching
    // that from the request.  This could be made more flexible in the future
    // by allowing the request to provide an xpath or something
    String idStr = req.params.getParameter("id");
    if(idStr==null || idStr.trim().length()<=0) return false;
    
    String xmlStr = null;
    String redirectURL = null;

    // first check for VDATA values
    for(int i=0; i<values.length; i++) {
      HandleValue val = values[i];      if(val==null) continue;
      if(val.hasType(VDATA_TYPE)) {
        req.modifyExpiration(val);
        xmlStr = val.getDataAsString();
        break;
      }
    }
    
    if(xmlStr==null) return false; // no VDATA was found
    
    try { // parse the VDATA XML
      XTag xml = parser.parse(new java.io.StringReader(xmlStr), false);
      for(int i=xml.getSubTagCount()-1; i>=0; i--) {
        XTag subtag = xml.getSubTag(i);
        if(!subtag.getName().equals(vdataParam)) continue;
        String subtagVal = subtag.getStrSubTag("id", null);
        if(subtagVal==null) continue;
        if(!subtagVal.equals(idStr)) continue;
        String urlVal = subtag.getStrSubTag("url", null);
        if(urlVal!=null && urlVal.trim().length()>0) {
          redirectURL = urlVal;
          break;
        }
      }
    } catch (Exception e) {
      System.err.println("Error parsing XML for handle "+req.hdl+": "+e);
    }
    
    if(redirectURL==null) {
      return false;
    }
    
    String urlSuffix = req.params.getParameter("urlappend");
    if (urlSuffix == null) urlSuffix = "";
    // already decoded
    //    else urlSuffix = StringUtils.decodeURLIgnorePlus(urlSuffix);
    
    // send a redirect to the URL, with any suffix provided by the user
    try { 
      // don't use sendRedirect(), because it tries to be smart and 
      // occasionally mangles the uri(e.g. on mailto's)
      // response.sendRedirect(url+suffix); 
      req.sendHTTPRedirect(ResponseType.DEFAULT_RESPONSE_TYPE,redirectURL+urlSuffix);
      // print out terse page to avoid tomcat's redirect message for
      // things like mailto where a separate viewer is spawned
      // XXX: seems to be ignored by tomcat?
      OutputStreamWriter out = new OutputStreamWriter(req.response.getOutputStream(),"UTF-8");
      out.write("\n<HTML><HEAD><TITLE>Handle Redirect</TITLE></HEAD>");
      out.write("\n<BODY><A HREF=\""+redirectURL+urlSuffix+"\">");
      out.write(redirectURL+urlSuffix+"</A></BODY></HTML>");
      out.close(); 
      return true;
    } catch (Exception e) {
      System.out.println("Error in Url.doRedirect for "+req.hdl+": "+e); 
    }
    return false;
  }
  
  
  /** 
   * Return true iff this handler can display a list of locations to which this handle
   * refers.
   */
  public boolean canShowLocations(HandleValue values[]) { return false; }
  
  /** 
   * Display a menu of locations to which this handle refers.  A nonnegative return value 
   * indicates that the servlet should not invoke doResponse on any subsequent type
   * handlers, and is the position in values[] of the first value displayed in the response.
   */
  public net.cnri.simplexml.XTag doShowLocations(HDLServletRequest req, HandleValue values[]) 
  throws Exception
  {
    return null;
  }
  
  
}
