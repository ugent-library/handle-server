/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

/**********************************************************************\
Redirects to a mirror based on a browser cookie.  If there is no cookie
first mirror is used.
\***********************************************************************/

package net.handle.apps.servlet_proxy.handlers;

import javax.servlet.http.*;
import net.handle.hdllib.*;
import java.util.*;
import java.io.IOException;
import net.handle.apps.servlet_proxy.*;
import net.handle.apps.servlet_proxy.HDLServletRequest.ResponseType;

public class MirrorUrls implements TypeHandler {
  private static final byte MIRROR_URLS_TYPE[] = Util.encodeString("MIRROR_URLS");
  private static final byte MIRROR_URLS_REF_TYPE[] = Util.encodeString("MIRROR_URLS_REF");
  public static final String COOKIE = "preferred_country";
  
  /** 
  * Return true iff this TypeHandler can send a redirect to the client
  * based on the given set of HandleValues.
  */
  public boolean canRedirect(HandleValue values[]) {
    if(values==null) return false;
    for(int i=values.length-1; i>=0; i--) {
      if(values[i].hasType(MIRROR_URLS_TYPE))
        return true;
      if(values[i].hasType(MIRROR_URLS_REF_TYPE))
        return true;
    }
    return false;
  }

  /** 
    * Return true iff this TypeHandler can and should be used to format the 
    * data from the given HandleValue for a human client.
    */
  public boolean canFormat(HandleValue value) {
    return false;
  }
  
  public String toHTML(String handle, HandleValue value){
    return value.getDataAsString();
  }
  
  private String getCountry(HttpServletRequest req) {
    Cookie cookies[] = req.getCookies();
    if (cookies == null) return null;
    for (int i=0; i<cookies.length; i++){
      if (cookies[i].getName().equals(COOKIE)){
        return cookies[i].getValue();
      }
    } 
    return null;
  }

  public boolean doRedirect(HDLServletRequest req, HandleValue vals[])
    throws IOException
  {
    if(vals==null) return false;
    
    // if there is a MIRROR_URLS value, use that...
    HandleValue val;
    for(int i=0; i<vals.length; i++) {
      val = vals[i];
      if(val.hasType(MIRROR_URLS_TYPE)) {
        req.modifyExpiration(val);
        return doMirrorUrls(req, val);
      }
    }
    
    // ...otherwise, look for a MIRROR_URLS_REF value
    for(int i=0; i<vals.length; i++) {
      val = vals[i];
      if(val.hasType(MIRROR_URLS_REF_TYPE)) {
        req.modifyExpiration(val);
        return doMirrorUrlsRef(req, val);
      }
    }
    return false; // didn't redirect for some reason
  }
  
  
  
  /**
   * MIRROR_URLS_REF values contain a suffix(ie the mirrored document) and 
   * a handle+index to a MIRROR_URLS list to append the suffix to.
   *
   * suffix is all chars up to space(not \t or \n).  index:handle is the rest
   * of the value.  e.g.:
   * 
   * /mydir/foo.html 1:10.1045/mirrorsites
   **/
  boolean doMirrorUrlsRef(HDLServletRequest req, HandleValue val)
    throws IOException
  {
    try {
      String data = val.getDataAsString();
      int i = data.indexOf(' ');
      String suffix = data.substring(0, i).trim();
      String ref = data.substring(i).trim();
      i = ref.indexOf(':');
      int index = Integer.parseInt(ref.substring(0, i));
      String hdl = ref.substring(i+1);
      long resolutionTime = System.currentTimeMillis();
      HandleValue vals[] = HDLProxy.resolver.resolveHandle(hdl, null, new int[]{index});
      if(vals!=null && vals.length>0) {
        String mirror = getMirror(req, vals[0]);
        req.modifyExpiration(resolutionTime,vals[0]);
        if (mirror == null) return false;
        String append = req.params.getParameter("urlappend");
        if (append == null) append = "";
        req.sendHTTPRedirect(ResponseType.DEFAULT_RESPONSE_TYPE,mirror+suffix+append);
        return true;
      } else {
        System.err.println("Error in doMirrorUrlsRef for hdl='"+req.hdl+
                           "' val='"+val+"': Mirror URL values not found");
        return false;
      }
    } catch (Exception e){
      System.err.println("Error in doMirrorUrlsRef for hdl='"+req.hdl+
                         "' val='"+val+"' error="+e); 
    }
    return false;
  }
  
  boolean doMirrorUrls(HDLServletRequest req, HandleValue val)
     throws IOException
  {
    String url = getMirror(req, val);
    if (url == null) return false;
    String suffix = req.params.getParameter("urlappend");
    if (suffix == null) suffix = "";
    req.sendHTTPRedirect(ResponseType.DEFAULT_RESPONSE_TYPE,url+suffix);
    return true;
  }

  String getMirror(HDLServletRequest req, HandleValue val){
    String preferredCountry = getCountry(req.req);
    StringTokenizer tok = new StringTokenizer(val.getDataAsString());
    String first = null;
    while (tok.hasMoreElements()){
      String country = (String)tok.nextElement();
      String url = (String)tok.nextElement();
      // System.err.println("COUNTRY: "+country+" =? "+preferredCountry);
      if (first == null) first = url;
      if (preferredCountry==null || preferredCountry.equals(country)){
        return url;
      }
    }
    return first;
  }
  
  
  /** 
   * Return true iff this handler can display a list of locations to which this handle
   * refers.
   */
  public boolean canShowLocations(HandleValue values[]) { return false; }
  
  /** 
   * Display a menu of locations to which this handle refers.  A nonnegative return value 
   * indicates that the servlet should not invoke doResponse on any subsequent type
   * handlers, and is the position in values[] of the first value displayed in the response.
   */
  public net.cnri.simplexml.XTag doShowLocations(HDLServletRequest req, HandleValue values[]) 
  throws Exception
  {
    return null;
  }
  
}
