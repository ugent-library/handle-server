/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy.handlers;

import net.handle.apps.servlet_proxy.*;
import net.handle.apps.servlet_proxy.HDLServletRequest.ResponseType;
import net.handle.hdllib.*;
import net.cnri.simplexml.*;
import net.cnri.util.StringUtils;

import com.maxmind.geoip.*;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

public class Location 
  implements TypeHandler
{
  public static final String CHOOSEBY_COUNTRY = "country";
  public static final String CHOOSEBY_WEIGHTED = "weighted";
  public static final String CHOOSEBY_LINKPARAM = "locatt";
  public static final String DEFAULT_CHOOSEBY[] = {"locatt", "country", "weighted"};
  public static final String CHOOSEBY_OLD_ATTRIBUTE = "chooseby";
  public static final String CHOOSEBY_ATTRIBUTE = "choose_by";
  public static final String SUPPRESS_LEGACY = "no_legacy";
  public static final String SUPPRESS_NAMESPACE_LOCS = "no_nslocs";
  public static final String ACCEPT_HEADER_STRING = "Accept";
  public static final String NS_LOCS_OVERRIDE_ATTRIBUTE = "nshdl";
  public static final String HDL_TEMPLATE_STRING = "{hdl}";
  public static final String LOC_ATTRIBUTE = "href";
  public static final String LOC_TEMPLATE_ATTRIBUTE = "href_template";
  public static final String LOC_TAG_NAME = "location";
  public static final String OLD_LOC_TEMPLATE_TAG_NAME = "loc_template";
  public static final String REDIRECT_TYPE_ATT = "http_sc";
  public static final String LOC_ATT_HTTP_ROLE = "http_role";
  public static final String LOC_ATT_VALUE_CONNEG = "conneg";
  
  public static final byte LOCATION_TYPE[] = Util.encodeString("10320/loc");
  public static final byte URL_TYPE[] = Util.encodeString("URL");
  
  private XParser parser = new XParser();
  
  private Object lookupInitLock = new Object();
  private boolean lookupServiceInitialized = false;
  private LookupService geoIP = null;
  private Random random = new Random();
  private boolean debug = false;
  
  /** Return the country code that should be used to */
  private String getCountryCode(HDLServletRequest req) {
    String countryCode = req.params.getParameter("country");
    if(countryCode!=null) return countryCode;
    
    String ipAddress = req.params.getParameter("ip");
    if(ipAddress==null) {
      ipAddress = req.req.getRemoteAddr();
    }
    
    if(!lookupServiceInitialized) {  // first 'if' is non-synchronized for speed
      synchronized (lookupInitLock) {
        if(!lookupServiceInitialized) { // this 'if' is synchronized for safety
          try {
            String dbFile = req.servlet.getInitParameter("geoip_data_file");
            if(dbFile==null) {
                dbFile = req.servlet.getServletContext().getRealPath("/WEB-INF/GeoIP.dat");
            }
            System.err.println("Creating GeoIP LookupService using "+dbFile);
            geoIP = new LookupService(dbFile, 
                                      LookupService.GEOIP_MEMORY_CACHE |
                                      LookupService.GEOIP_CHECK_CACHE);
          } catch (Throwable e) {
            System.err.println("Unable to initialize country lookup service: "+e);
            e.printStackTrace(System.err);
          }
          lookupServiceInitialized = true;
        }
      }
    }
    
    if(geoIP!=null) {
      try {
        Country country = geoIP.getCountry(ipAddress);
        //System.err.println("Got country: "+country.getCode()+" for IP "+ipAddress);
        return country.getCode();
      } catch (Exception e) {
        System.err.println("Error resolving country for request: "+req);
      }
    }
    return null;
  }
  
  
  /** 
  * Return true if the handle values contain a 10320/loc value or a value with
  * a sub-type of 10320/loc.
  */
  public boolean canRedirect(HandleValue values[]) {
    if(values==null) return false;
    for(int i=values.length-1; i>=0; i--) {
      if(values[i].hasType(LOCATION_TYPE) || values[i].hasType(URL_TYPE))
        return true;
    }
    return false;
  }
  
  /** Return true if the handle values contain either a URL or 10320/loc value */
  public boolean canShowLocations(HandleValue values[]) {
    if(values==null) return false;
    for(int i=values.length-1; i>=0; i--) {
      if(values[i].hasType(LOCATION_TYPE) || values[i].hasType(URL_TYPE))
        return true;
    }
    return false;
  }
  
  
  /** 
    * Return true iff this TypeHandler can format the data from the given
    * HandleValue for a human client.
    */
  public boolean canFormat(HandleValue value) { 
    return false;
    //return value!=null && value.hasType(LOCATION_TYPE);
  }
  
  
  
  public String toHTML(String handle, HandleValue value){
    // a nicer display would be as a list of links
    return "<pre>"+value.getDataAsString()+"<pre>";
  }
  
  
  /** Gather all of the known locations and put them into an XML structure */
  public XTag doShowLocations(HDLServletRequest req, HandleValue values[]) 
    throws Exception
  {
    if(values==null) return null;
    
    ArrayList<XTag> nsLocs = new ArrayList<XTag>();
    ArrayList<XTag> legacyLocs = new ArrayList<XTag>();
    boolean extractedNSLocs = false;
    boolean extractedURLs = false;
    
    for(int i=0; i<values.length; i++) {
      if(values[i].hasType(LOCATION_TYPE)) {
        String locationsStr = Util.decodeString(values[i].getData());
        XTag locXML = parser.parse(new StringReader(locationsStr), false);
        ArrayList<XTag> locations = new ArrayList<XTag>();
        
        // add legacy URL handle values to the list of locations
        if(!locXML.getBoolAttribute(SUPPRESS_LEGACY, false)) {
          if(!extractedURLs) {
            extractLegacyURLs(req, values, legacyLocs, 0f, 0f);
            extractedURLs = true;
          }
          if(legacyLocs.size()>0) locations.addAll(legacyLocs);
        }
        
        // add any namespace URLs to the list of locations
        if(!locXML.getBoolAttribute(SUPPRESS_NAMESPACE_LOCS, false)) {
          if(!extractedNSLocs) {
            resolveNamespaceLocations(req, locXML, nsLocs);
            extractedNSLocs = true;
          }
          if(nsLocs.size()>0) locations.addAll(nsLocs);
        }
        
        // add the locations from this handle
        for(int hdlLoc = locXML.getSubTagCount()-1; hdlLoc >= 0; hdlLoc--) {
          XTag subtag = locXML.getSubTag(hdlLoc);
          if(subtag.getName().equals(LOC_TAG_NAME)) {
            locations.add(subtag);
          }
        }
        
        XTag locs = new XTag(locXML.getName());
        for(XTag loc : locations) {
          locs.addSubTag(processTemplate(loc, req));
        }
        return locs;
      }
    }
    
    // we should only get here if there is no 10320/loc value
    // so we process the namespace locations and URL values
    // add legacy URL handle values to the list of locations
    ArrayList<XTag> locations = new ArrayList<XTag>();
    extractLegacyURLs(req, values, locations, 1f, 0f);
    
    // add any namespace URLs to the list of locations
    if(!extractedNSLocs) {
      resolveNamespaceLocations(req, null, nsLocs);
    }
    if(nsLocs.size()>0) locations.addAll(nsLocs);
    
    XTag locs = new XTag("locations");
    for(XTag loc : locations) {
      locs.addSubTag(processTemplate(loc, req));
    }
    return locs;
  }
  
  
  /**  
   * Take any URL handle values from the given list and put them into an array
   * of XTags that describe a set of locations.
   * If there are URL types and URL.foo types, give them different weights.  If only URL.foo types, give them the higher default weight.
   */
  private static final void extractLegacyURLs(HDLServletRequest req, HandleValue values[], ArrayList<XTag> urlLocs, float defaultWeight, float defaultSubTypeWeight) {
    boolean hasJustUrl = false;
    for(int i=0; values!=null && i<values.length; i++) {
        if(Util.equalsCI(values[i].getType(), Common.STD_TYPE_URL)) {
            hasJustUrl = true;
            break;
        }
    }
    if(!hasJustUrl) defaultSubTypeWeight = defaultWeight; 
    for(int i=0; values!=null && i<values.length; i++) {
      if(!values[i].hasType(Common.STD_TYPE_URL)) continue;
      req.modifyExpiration(values[i]);
      XTag urltag = new XTag(LOC_TAG_NAME);
      urltag.setAttribute(LOC_ATTRIBUTE, values[i].getDataAsString());
      float weight = defaultSubTypeWeight;
      if(hasJustUrl && Util.equalsCI(values[i].getType(), Common.STD_TYPE_URL)) weight = defaultWeight;
      urltag.setAttribute("weight", String.valueOf(weight));
      urltag.setAttribute("mode", "legacy");
      urlLocs.add(urltag);
    }
  }
  
  
  /**  
   * Find any namespace locations based on the handle resolution and possibly any
   * overriding namespace identifier in the locations XML.
   */
  private void resolveNamespaceLocations(HDLServletRequest req, XTag locXML, ArrayList<XTag> nsLocs) {
    NamespaceInfo nsInfo = req.resRequest.getNamespace();
    String nsHandle = null;
    if(nsHandle==null && nsInfo!=null) nsHandle = nsInfo.getLocationTemplateHandle();
    if(nsHandle==null && locXML!=null) nsHandle = locXML.getAttribute(NS_LOCS_OVERRIDE_ATTRIBUTE, null);
    if(nsHandle==null) return;
    
    XTag nsLocXML = req.resolveLocations(nsHandle);
    if(nsLocXML==null) return;
    
    for(int i=0; nsLocXML!=null && i<nsLocXML.getSubTagCount(); i++) {
      XTag subtag = nsLocXML.getSubTag(i);
      if(!subtag.getName().equalsIgnoreCase(LOC_TAG_NAME) &&
         !subtag.getName().equalsIgnoreCase(OLD_LOC_TEMPLATE_TAG_NAME)) continue;
      // need to clone the subtags here!
      nsLocs.add(subtag);
    }
  }
  
  
  public boolean doRedirect(HDLServletRequest req, HandleValue values[])
    throws Exception
  {
    if(values==null) return false;
    
    ArrayList<XTag> nsLocs = new ArrayList<XTag>();
    ArrayList<XTag> legacyLocs = new ArrayList<XTag>();
    boolean extractedNSLocs = false;
    boolean extractedURLs = false;
    
    NamespaceInfo nsInfo = req.resRequest.getNamespace();
    
    boolean hasLocationTypeValue = false;
    
    for(int i=0; i<values.length; i++) {
      if(values[i].hasType(LOCATION_TYPE)) {
        hasLocationTypeValue = true;
          
        req.modifyExpiration(values[i]);
        String locationsStr = Util.decodeString(values[i].getData());
        
        XTag locXML = parser.parse(new StringReader(locationsStr), false);
        ArrayList<XTag> locations = new ArrayList<XTag>();
        
        // add legacy URL handle values to the list of locations
        if(!locXML.getBoolAttribute(SUPPRESS_LEGACY, false)) {
          if(!extractedURLs) {
            extractLegacyURLs(req, values, legacyLocs, 0, 0);
            extractedURLs = true;
          }
          if(legacyLocs.size()>0) locations.addAll(legacyLocs);
        }
        
        // add any namespace URLs to the list of locations
        if(!locXML.getBoolAttribute(SUPPRESS_NAMESPACE_LOCS, false)) {
          if(!extractedNSLocs) {
            resolveNamespaceLocations(req, locXML, nsLocs);
            extractedNSLocs = true;
            locations.addAll(nsLocs);
          }
        }
        
        // add the locations from this handle
        for(int hdlLoc = locXML.getSubTagCount()-1; hdlLoc >= 0; hdlLoc--) {
          XTag subtag = locXML.getSubTag(hdlLoc);
          if(subtag.getName().equals(LOC_TAG_NAME)) {
            locations.add(subtag);
          }
        }
        
        if(req.userWantsRDF) {
            boolean generateLocationRDF = true;
            for(XTag loc : locations) {
                if(loc.getAttribute("http_role","").contains("conneg")) {
                    String ctype = loc.getAttribute("ctype");
                    if(ctype==null || ctype.contains("application/rdf+xml")) {
                        generateLocationRDF = false;
                        break;
                    }
                }
            }
            if(generateLocationRDF) {
                return generateLocationRDF(req,locations);
            }
        }
        
        if(chooseLocationFromValue(req, locXML, new LocContext(req, locXML, nsInfo), locations)) {
          return true;
        }
      }
    }
    
    // add any namespace URLs to the list of locations
    if(!extractedNSLocs) {
      resolveNamespaceLocations(req, null, nsLocs);
    }

    if(hasLocationTypeValue || !nsLocs.isEmpty()) {
        // we should only get here if there is no 10320/loc value
        // so we process the namespace locations and URL values
        // add legacy URL handle values to the list of locations
        ArrayList<XTag> locations = new ArrayList<XTag>();
        extractLegacyURLs(req, values, locations, 1f, 0f);
        locations.addAll(nsLocs);

        if(req.userWantsRDF) {
            boolean generateLocationRDF = true;
            for(XTag loc : locations) {
                if(loc.getAttribute("http_role","").contains("conneg")) {
                    String ctype = loc.getAttribute("ctype");
                    if(ctype==null || ctype.contains("application/rdf+xml")) {
                        generateLocationRDF = false;
                        break;
                    }
                }
            }
            if(generateLocationRDF) {
                return generateLocationRDF(req,locations);
            }
        }
        if(chooseLocationFromValue(req, null, new LocContext(req, null, nsInfo), locations)) {
            return true;
        }
    }
    else {
        // use legacy proxy behavior
        String redirectURL = null;
        
        // first check for base URL values
        HandleValue val;
        byte valType[];
        for(int i=0; i<values.length; i++) {
          val = values[i];
          if(val==null) continue;
          valType = val.getType();
          if(valType==null) continue;
          if(Util.equalsCI(valType, Common.STD_TYPE_URL) || Util.equalsCI(valType,Url.zeroDotTypeUrl)) {
            req.modifyExpiration(val);
            redirectURL = val.getDataAsString();
            break;
          }
        }
        
        // if no simple URL value exists, look for URL sub-types
        if(redirectURL==null) {
          for(int i=0; i<values.length; i++) {
            val = values[i];
            if(val==null) continue;
            if(val.hasType(Common.STD_TYPE_URL) || val.hasType(Url.zeroDotTypeUrl)) {
              req.modifyExpiration(val);
              redirectURL = val.getDataAsString();
              break;
            }
          }
        }
        
        if(redirectURL==null) {
          // no value was found with type URL or any subtypes
          return false;
        }
        
        String urlSuffix = req.params.getParameter("urlappend");
        if (urlSuffix == null) urlSuffix = "";
    // already decoded
//        else urlSuffix = StringUtils.decodeURLIgnorePlus(urlSuffix);
        
        // send a redirect to the URL, with any suffix provided by the user
        try { 
          // don't use sendRedirect(), because it tries to be smart and 
          // occasionally mangles the uri(e.g. on mailto's)
          // response.sendRedirect(url+suffix); 
          req.sendHTTPRedirect(ResponseType.DEFAULT_RESPONSE_TYPE,redirectURL+urlSuffix);
          // print out terse page to avoid tomcat's redirect message for
          // things like mailto where a separate viewer is spawned
          // XXX: seems to be ignored by tomcat?
          req.response.setContentType("text/html; charset=utf-8");
          String escapedURL = StringUtils.cgiEscape(redirectURL+urlSuffix);
          OutputStreamWriter out = new OutputStreamWriter(req.response.getOutputStream(),"UTF-8");
          out.write("\n<HTML><HEAD><TITLE>Handle Redirect</TITLE></HEAD>");
          out.write("\n<BODY><A HREF=\""+escapedURL+"\">");
          out.write(escapedURL+"</A></BODY></HTML>");
          out.close(); 
          return true;
        } catch (Exception e) {
          System.out.println("Error in legacy case of Location.doRedirect for "+req.hdl+": "+e); 
        }
        return false;
    }
    
    if(debug) System.err.println("Didn't find any acceptable redirects...");
    return false;
  }
  
  private boolean generateLocationRDF(HDLServletRequest req, List<XTag> locations) {
      try {
          req.response.setContentType("application/rdf+xml");
          req.response.setCharacterEncoding("UTF-8");
          PrintWriter writer = req.response.getWriter();
          writer.println("<?xml version='1.0' encoding='UTF-8'?>");
          writer.println("<rdf:RDF xmlns:dc='http://purl.org/dc/elements/1.1/' xmlns:hdl='http://132.151.2.156/hdlschema.rdf#' xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#'>");
          writer.println("  <hdl:WebLocation rdf:about='" + StringUtils.encodeURLForAttr(req.getURLForHandle(req.hdl)) + "'>");
          for(XTag loc : locations) {
              String url = loc.getStrAttribute(LOC_ATTRIBUTE, null);
              if(url!=null) {
                  writer.println("    <hdl:loc rdf:resource='" + StringUtils.encodeURLForAttr(url) + "'/>");
              }
          }
          writer.println("  </hdl:WebLocation>");
          writer.println("</rdf:RDF>");
          writer.close();
          return true;
      }
      catch(Exception e) {
          e.printStackTrace();
          return false;
      }
  }
  
  private static boolean someLocationDoesConneg(List<XTag> locations) {
      for(XTag loc : locations) {
          if(loc.getAttribute("http_role","").contains("conneg")) {
              return true;
          }
      }      
      return false;
  }
  
  private static void addVaryAccept(HttpServletResponse resp) {
      resp.addHeader("Vary","Accept");
  }
  
  private boolean chooseLocationFromValue(HDLServletRequest req,
                                          XTag locXML, LocContext locContext,
                                          ArrayList<XTag> locations) 
    throws Exception
  {
    if(debug) System.err.println("hdl:"+req.hdl+" locations: "+locations);
    String chooseByStr = locContext.getAttribute(null, CHOOSEBY_ATTRIBUTE, null);
    String chooseBy[] = chooseByStr==null ? DEFAULT_CHOOSEBY : StringUtils.split(chooseByStr, ',');
    
    if(someLocationDoesConneg(locations)) addVaryAccept(req.response);
    
    // find appropriate locations according to the chooseby attribute
    for(int i=0; i<chooseBy.length; i++) {
      if(locations.size()<=1) {
        // only one location left, redirect to it
        return sendRedirect(req, locContext, locations.get(0));
      }
      
      String fieldType = chooseBy[i].trim().toLowerCase();
      if(fieldType.length()<=0) continue; // skip blank values
      
      if(fieldType.equals(CHOOSEBY_COUNTRY)) {
        // narrow down the list of choices based on the country in which the
        // caller is located
        String myCountry = null;
        ArrayList<XTag> countryLocs = new ArrayList<XTag>();
        for(int v=0; v<locations.size(); v++) {
          XTag loctag = locations.get(v);
          String locCountry = loctag.getStrAttribute("country", null);
          if(locCountry!=null && myCountry==null) {
            // lazy lookup of country from IP address
            myCountry = getCountryCode(req);
            if(myCountry==null) {
              System.err.println("Couldn't determine country from address: "+
                                 req.req.getRemoteAddr());
              break;
            }
          }
          if(locCountry!=null && myCountry.equalsIgnoreCase(locCountry.trim())) {
            // the country is specified and matches
            countryLocs.add(loctag);
          } else if(locCountry!=null) {
            // the country is specified, but doesn't match.  Remove it from  
            // consideration for resolution
            locations.remove(v--);
          }
        }
        
        // if there is at least one country match, use it/them
        // if there are no country matches, don't filter by country at all
        if(countryLocs.size()>0) {
          locations = countryLocs;
        }
      } else if(fieldType.equals(CHOOSEBY_LINKPARAM)) {
        // the preferred location(s) are indicated by a parameter in the URI
        // try each locatt parameter in order to select the locations
        String linkParams[] = req.params.getParameterValues("locatt");
        if(linkParams==null || linkParams.length<=0) continue;
        for(String linkParam : linkParams) {
          if(linkParam!=null) {
            int colIdx = linkParam.indexOf(':');
            String attName = colIdx<0 ? linkParam.trim() : linkParam.substring(0,colIdx).trim();
            String attVal = colIdx<0 ? null : linkParam.substring(colIdx+1);
            ArrayList<XTag> newlocs = new ArrayList<XTag>();
            for(int v=0; v<locations.size(); v++) {
              XTag loctag = locations.get(v);
              String att = loctag.getAttribute(attName, null);
              if(att!=null) {
                if(attVal==null || (attVal!=null && attVal.equals(att))) {
                  newlocs.add(loctag);
                }
              }
            }
            
            // if there is at least one attribute match, use it/them
            // if there are no matches, use the whole set
            if(newlocs.size()>0) {
              locations = newlocs;
            }
          }
        }
      } else if(fieldType.equals(CHOOSEBY_WEIGHTED)) {
        return sendWeightedRedirect(req, locContext, locations);
      }
    }
    
    return sendWeightedRedirect(req, locContext, locations);
  }
  
  
  private boolean sendWeightedRedirect(HDLServletRequest req, LocContext locContext, ArrayList<XTag> locations) 
    throws IOException
  {
    if(debug) System.err.println("Sending weighted redirect of "+locations);
    if(locations.size()<=0) {
      // no available locations!
      return false;
    }
    
    // calculate the sum of the non-negative location weights
    double totalWeight = 0f;
    for(int i=locations.size()-1; i>=0; i--) {
      double weight = locations.get(i).getDoubleAttribute("weight", 1f);
      totalWeight += Math.max(0f, weight);
    }
    
    int randIdx = 0;
    if(totalWeight>0) {
      double randVal = random.nextFloat() * totalWeight;
      totalWeight = 0f;
      XTag loc = null;
      for(int i=locations.size()-1; i>=0; i--) {
        loc = locations.get(i);
        totalWeight += Math.max(0f, loc.getDoubleAttribute("weight", 1f));
        if(totalWeight>=randVal) {
          return sendRedirect(req, locContext, loc);
        }
      }
      if(loc!=null) { // shouldn't happen... return the last location
        return sendRedirect(req, locContext, loc);
      } else {
        // there were no locations!  can't get here
        return false;
      }
    } else {
      // the items all have zero (or less) weight... rare but might happen
      randIdx = Math.round(Math.abs(random.nextFloat()) * locations.size());
      randIdx = Math.max(0, Math.min(locations.size()-1, randIdx));
      return sendRedirect(req, locContext, locations.get(randIdx));
    }
  }
  
  
  
  /** 
   * Return an XTag with any template href values converted to regular hrefs.
   * If there are any templates, then the returned XTag may be different than
   * the one passed to this method.  For efficiency reasons this will return the
   * exact same XTag if no templates needed to be processed.
   */
  private XTag processTemplate(XTag locInfo, HDLServletRequest req) {
    if(locInfo.getStrAttribute(LOC_ATTRIBUTE, null)==null) {
      String locTemplate = locInfo.getStrAttribute(LOC_TEMPLATE_ATTRIBUTE, null);
      if(locTemplate!=null) {
        int hdlIdx = locTemplate.indexOf(HDL_TEMPLATE_STRING);
        if(hdlIdx >=0 ) {
          StringBuilder sb = new StringBuilder(locTemplate.length() + 20);
          sb.append(locTemplate);
          sb.replace(hdlIdx, hdlIdx+HDL_TEMPLATE_STRING.length(), StringUtils.encodeURLComponent(req.hdl));
          locInfo = locInfo.shallowCloneTag();
          locInfo.setAttribute(LOC_ATTRIBUTE, sb.toString());
          return locInfo;
        }
      }
    }
    return locInfo;
  }
  
  
  private boolean sendRedirect(HDLServletRequest req, LocContext locContext, XTag locInfo)
    throws IOException
  {
    try {
      if(debug) System.err.println("Redirecting to: "+locInfo);
      
      locInfo = processTemplate(locInfo, req);
      
      String url = locInfo.getStrAttribute(LOC_ATTRIBUTE, null);
      if(url==null) {
        System.err.println("Error: no URL in location: "+locInfo);
        return false;
      }
      
      String urlSuffix = req.params.getParameter("urlappend");
      if (urlSuffix != null) url += urlSuffix;
      
      // don't use sendRedirect(), because it tries to be smart and 
      // occasionally mangles the uri(e.g. on mailto's)
      // response.sendRedirect(url+suffix);
      String redirectType = locContext.getAttribute(locInfo, REDIRECT_TYPE_ATT, null); 
      req.sendHTTPRedirect(ResponseType.typeForString(redirectType), url);
      // print out terse page to avoid tomcat's redirect message for
      // things like mailto where a separate viewer is spawned
      // XXX: seems to be ignored by tomcat?
      req.response.setContentType("text/html; charset=utf-8");
      String escapedURL = StringUtils.cgiEscape(url);
      OutputStreamWriter out = new OutputStreamWriter(req.response.getOutputStream(),"UTF-8");
      out.write("\n<HTML><HEAD><TITLE>Handle Redirect</TITLE></HEAD>");
      out.write("\n<BODY><A HREF=\""+escapedURL+"\">");
      out.write(escapedURL+"</A></BODY></HTML>");
      out.close(); 
      return true;
    } catch (Exception e) {
      System.err.println("Error in Location.sendRedirect for "+req+": "+e); 
    }
    return false;
  }
  
  
  
  private class LocContext {
    private NamespaceInfo nsInfo;
    private XTag parentInfo;
    private HDLServletRequest req;
    
    LocContext(HDLServletRequest req, XTag parentInfo, NamespaceInfo nsInfo) {
      this.parentInfo = parentInfo;
      this.nsInfo = nsInfo;
      this.req = req;
    }
    
    public String getAttribute(XTag loc, String attributeName) {
      return this.getAttribute(loc, attributeName, null);
    }
    
    public String getAttribute(XTag loc, String attributeName, String defaultValue) {
      String val = null;
      // return the location-specific attribute, if any
      if(loc!=null) {
        val = loc.getAttribute(attributeName);
        if(val!=null) return val;
      }
      
      // return the location-set-specific attribute, if any
      if(parentInfo!=null) {
        val = parentInfo.getAttribute(attributeName);
        if(val!=null) return val;
      }
      
      // iterate over parent namespaces until we find the given attribute or SUPPRESS_NAMESPACE_LOCS flags
      NamespaceInfo nsInfo = this.nsInfo;
      int counter = 10;
      while(nsInfo!=null && counter-- > 0) {
        String nsLocs = nsInfo.getLocationTemplateHandle();
        if(nsLocs!=null) {
          XTag parentLocs = req.resolveLocations(nsLocs);
          if(parentLocs==null) continue;
          val = parentLocs.getAttribute(attributeName);
          if(val!=null) return val;
          
          boolean suppressParents = parentLocs.getBoolAttribute(SUPPRESS_NAMESPACE_LOCS, false);
          if(suppressParents) break;
        }
        
        nsInfo = nsInfo.getParentNamespace(); 
      }
      
      return defaultValue;
    }
    
    
  }
  
  
}
