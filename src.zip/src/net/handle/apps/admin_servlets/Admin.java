/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admin_servlets;

/**
 *Servlet used for administration of a handle server via the web.
 **/

import net.handle.hdllib.*;
import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import javax.servlet.*;
import javax.servlet.http.*;
import net.cnri.util.Template;

public class Admin extends HttpServlet {
  
  public static final String TEMPLATE_DIR_KEY = "adminhs.html_template_dir";
  public static final String BATCH_DIR_KEY = "adminhs.batch_dir";
  public static final String NA_KEY = "adminhs.na";
  public static final String ADMIN_NA_KEY = "adminhs.adminhdl";
  public static final String VERIFY_PREFIXES_KEY = "adminhs.check_prefixes";
  public static final String TRACE_MESSAGES_KEY = "adminhs.trace_messages";
  
  public static final String YOUR_NAMING_AUTHORITY = "1030";
  public static final String ADMIN_NA = "1030.admin";
  
  public static final int SEC_KEY_IDX = 300;
  public static final int ADMIN_GROUP_IDX = 200;
  
  private String localNA = YOUR_NAMING_AUTHORITY;
  private String adminNA = ADMIN_NA;
  private boolean verifyPrefixes = true;
  private HandleResolver resolver = new HandleResolver();
  private File templateDir = null;
  private File batchDir = null;
  private int counter = 0;
  private static final String CHECKED = "CHECKED";
  
  public void init(ServletConfig config) throws ServletException{
    super.init(config);
    System.err.println("Initializing handle admin servlet");
    String templateDirStr = getInitParameter(TEMPLATE_DIR_KEY);
    if(templateDirStr!=null) {
      templateDir = new File(templateDirStr.trim());
    } else {
      System.err.println("Error: init parameter "+TEMPLATE_DIR_KEY+" not set! Using default: .");
      templateDir = new File(".");
    }
    
    String traceMessagesVal = getInitParameter(TRACE_MESSAGES_KEY);
    if(traceMessagesVal!=null && traceMessagesVal.trim().toLowerCase().startsWith("y"))
      resolver.traceMessages = true;
    
    String verifyPrefixesVal = getInitParameter(VERIFY_PREFIXES_KEY);
    if(verifyPrefixesVal!=null && verifyPrefixesVal.trim().toLowerCase().startsWith("n"))
      verifyPrefixes = false;
    
    String batchDirStr = getInitParameter(BATCH_DIR_KEY);
    if(batchDirStr!=null) {
      batchDir = new File(batchDirStr.trim());
    } else {
      System.err.println("Error: init parameter "+TEMPLATE_DIR_KEY+" not set! Using default: .");
      batchDir = new File(".");
    }

    String naStr = getInitParameter(NA_KEY);
    if(naStr!=null) localNA = naStr;
    else System.err.println("Error: init parameter "+NA_KEY+" not set.  Using default: "+localNA);
    
    String adminStr = getInitParameter(ADMIN_NA_KEY);
    if(adminStr!=null) adminNA = adminStr;
    else System.err.println("Error: init parameter "+ADMIN_NA_KEY+" not set.  Using default: "+adminNA);

    
    

    
    System.err.println("Servlet initialized, using template dir: "+
                       templateDir+";  batchDir: "+batchDir);
  }

  public void destroy() {
    super.destroy();
  }

  public String getServletInfo() {
    return "This servlet is used for administration of a handle server via the web.";
  }

  public void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
  {
    doPost(req, resp);
  }
  
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
  {
    Hashtable mergeDict = new Hashtable();
    mergeDict.put("base_uri", req.getServletPath());
    mergeDict.put("upload_uri", req.getServletPath()+"/upload");

    String pathInfo = req.getPathInfo();
    if(pathInfo==null)
      pathInfo = "";

    if(pathInfo.startsWith("/upload")) {
      // need to upload and process the batch file...
      try {
        processUpload(req, resp, mergeDict);
      }
      catch (IOException e){
        throw new ServletException(e.toString());
      }
    } else {
      processRequest(req, resp, mergeDict);
    }

    try {
      if(counter%20==0) {
        counter = 0;
        System.gc();
        System.runFinalization();
      }
    } catch (Throwable e) { }
  }

  private void processUpload(HttpServletRequest req, HttpServletResponse resp,
                             Hashtable mergeDict)
    throws IOException
  {
    Hashtable reqParams = new Hashtable();
    File batchFile = new File(batchDir, String.valueOf(System.currentTimeMillis())+".batch");

    // make a working directory for this batch, and save the batch 
    // submission to a file
    int fileLength = 0;

    resp.setContentType("text/plain");
    String contentType = req.getContentType();
    try { contentType.length(); }
    catch (Exception e) { 
      e.printStackTrace(); 
      contentType = req.getHeader("Content-type");
    }
    PrintWriter out = new PrintWriter(resp.getOutputStream());
    
    if (contentType.indexOf("multipart/form-data") != -1 ) {
      String boundary=contentType.substring(contentType.indexOf("boundary=")+9);
      boundary = "--" + boundary;
      LineNumberReader in = new LineNumberReader(
                                  new InputStreamReader(req.getInputStream()));

      String name = null;
      String line;
      String filename = null;
      line = in.readLine();
      while (true){
        while (line !=null && !line.startsWith(boundary)){ 
          line = in.readLine();
        }
        if (line == null) break;
        // read headers
        while (true){
          line = in.readLine();
          if (line == null || line.trim().length() == 0) break;
          if (line.toLowerCase().startsWith("content-disposition")){
            int begin = line.indexOf("name=")+6;
            int end = line.indexOf('"', begin);
            name = line.substring(begin, end);
            begin = line.toLowerCase().indexOf("filename");
            if (begin != -1){
              end = line.indexOf('"', begin+10);
              filename = line.substring(begin+10, end);
            }
            else {
              filename = null;
            }
          }
        }
        // read body 
        StringBuffer data = new StringBuffer();
        line = in.readLine();
        Writer f;
        if (filename != null) f = new OutputStreamWriter(new FileOutputStream(batchFile),"UTF-8");
        else f = new StringWriter();
        
        while (line !=null && !line.startsWith(boundary)){ 
          f.write(line);
          f.write('\n');
          line = in.readLine();
        }
        if (filename != null){
            f.close();
        }
        else {
          reqParams.put(name, ((StringWriter)f).toString().trim());
        }
      }
    } else {
      throw new IOException("Invalid content-type for upload");
    }


    out.println("\nprocessing Batch: "+batchFile);
    System.out.println("\nprocessing Batch: "+batchFile);
    String action = String.valueOf(reqParams.get("action"));
    LoginInfo login = getLoginInfo(reqParams);
    
    boolean detailed =
      String.valueOf(reqParams.get("response_format")).equals("record_status");
    BufferedReader bin = null;

    try {
      bin = new BufferedReader(new InputStreamReader(new FileInputStream(batchFile),"UTF-8"));
      if(action.equals("batch_create")) {
        processBatchCreate(login, bin, detailed, out);
      } else if(action.equals("batch_delete")) {
        processBatchDelete(login, bin, detailed, out);
      } else if(action.equals("batch_update")) {
        processBatchUpdate(login, bin, detailed, out);
      } else {
        throw new IOException("Unknown action: \""+action+"\"");
      }
    } finally {
      try { bin.close(); } catch (Throwable t) {}
      try { batchFile.delete(); } catch (Throwable t) {}
    }
    
    try { out.flush(); } catch (Exception e) {}
    try { out.close(); } catch (Exception e) {}
  }

  /** Run a batch-create job */
  private void processBatchCreate(LoginInfo login, BufferedReader in,
                                  boolean detailedResults, PrintWriter out)
    throws IOException
  {
    String line;
    String handle = "";
    AuthenticationInfo auth = login.getAuth();
    AdminRecord admin = getAdminRecord(login.prefix);
    int size = 0;
    int successes = 0;
    int records = 0;
    
    while(true) {
      line = in.readLine();
      if(line==null)
        break;      
      line = line.trim();
      if(line.length()<=0)
        continue;
     
      if (line.indexOf(localNA)>=0) {
        handle = line.trim();
        if (detailedResults) {
          out.println("handle: " +handle);
        }
        continue;
      }

      String prefix = Util.decodeString(Util.getPrefixPart(Util.encodeString(handle)));

      if(!prefix.equals(login.prefix)) {
        out.println("Prefix '"+prefix+"', in batch file does not match prefix at login, '"+login.prefix+"'.  \nPlease resubmit the batch file with the correct prefix.");
        break;
      }

      Vector url = new Vector();
      
      for(int i=0;(line.length()>0);i++) {
        url.insertElementAt(line.trim(), i);
        if (detailedResults) {
          out.println((i+1)+" url: "+url.elementAt(i));
        }
        line = in.readLine();
        if (line == null) break;
      }
      size = url.size();

      HandleValue[] values = new HandleValue[size+1];
      for(int j=0; j<size; j++) {        
        values[j] = new HandleValue();
        values[j].setIndex(j+1);
        values[j].setType(Common.STD_TYPE_URL);
        values[j].setData(Util.encodeString((String) url.elementAt(j)));
      }
      values[size] = new HandleValue();
      values[size].setIndex(100);
      values[size].setType(Common.STD_TYPE_HSADMIN);
      values[size].setData(Encoder.encodeAdminRecord(admin));

      CreateHandleRequest chReq = new CreateHandleRequest(Util.encodeString(handle), values, auth);
      chReq.authoritative = true;
      
      records++;
      AbstractResponse response = null;
      try {
        response = resolver.processRequest(chReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          successes++;
          if(detailedResults) {
            out.println("CREATED: "+handle+"\n");
          }
        } else {
          out.println("FAILURE: "+handle+": "+response);
        }
      } catch (HandleException e) {
        out.println("FAILURE: "+handle+": "+e);
      }
      try { out.flush(); } catch (Throwable t) {}
      chReq.clearBuffers();

    }//end while
    out.println("SUMMARY: "+successes+" of "+records+" records created");
  }


  /** Run a batch-delete job */
  private void processBatchDelete(LoginInfo login, BufferedReader in,
                                  boolean detailedResults, PrintWriter out)
    throws IOException
  {
    String line;
    int spaceIdx;
    int lineNum = 0;
    AuthenticationInfo auth = login.getAuth();

    DeleteHandleRequest dhReq = new DeleteHandleRequest(null, auth);

    int successes = 0;
    int records = 0;
    String handle;
    
    while(true) {
      line = in.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
      spaceIdx = line.indexOf(' ');
      if(spaceIdx>0) {
        handle = line.substring(0, spaceIdx).trim();
      } else {
        handle = line;
      }

      String prefix = Util.decodeString(Util.getPrefixPart(Util.encodeString(handle)));

      if(!prefix.equals(login.prefix)) {
        out.println("Prefix '"+prefix+"', in batch file does not match prefix at login, '"+login.prefix+"'.  \nPlease resubmit the batch file with the correct prefix.");
        break;
      }

      dhReq.handle = Util.encodeString(handle);
      
      records++;
      dhReq.clearBuffers();
      AbstractResponse response = null;
      try {
        response = resolver.processRequest(dhReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          successes++;
          if(detailedResults) {
            out.println("DELETED: "+handle);
          }
        } else {
          out.println("FAILURE: "+handle+": "+response);
        }
      } catch (HandleException e) {
        out.println("FAILURE: "+handle+": "+e);
      }
      try { out.flush(); } catch (Throwable t) {}
    }

    out.println("SUMMARY: "+successes+" of "+records+" records deleted");
  }

  /** Run a batch-update job */
  private void processBatchUpdate(LoginInfo login, BufferedReader in,
                                  boolean detailedResults, PrintWriter out)
    throws IOException
  {
    String line;
    String handle = "";
    String url = "";
    AuthenticationInfo auth = login.getAuth();
    byte[][] reqTypes = {Common.STD_TYPE_URL};

    ModifyValueRequest mvReq = new ModifyValueRequest((byte[])null, (HandleValue[])null, auth); 
    ResolutionRequest queryReq = new ResolutionRequest((byte[])null,reqTypes, (int[])null, auth);
    queryReq.certify = true;
    AbstractResponse response =null;
   
    int successes = 0;
    int records = 0;
    
    while(true) {
      line = in.readLine();
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;

      if (line.indexOf(localNA)>=0) {
        handle = line.trim();
        continue;
      }

      String prefix = Util.decodeString(Util.getPrefixPart(Util.encodeString(handle)));
      
      if(!prefix.equals(login.prefix)) {
        out.println("Prefix '"+prefix+"', in batch file does not match prefix at login, '"+login.prefix+"'.  \nPlease resubmit the batch file with the correct prefix.");
        break;
      }

      if (line.length()>0)
        url = line.trim();
      
      records++;
      byte[] handleBytes = Util.encodeString(handle);
       
       try{
	  //retrieve all URLs for given handle
	  queryReq.handle = handleBytes; 
	  queryReq.clearBuffers();
	  response = resolver.processRequest(queryReq);
	  if(!(response instanceof ResolutionResponse)){
	      out.println("FAILURE: "+handle+": "+response);
	      try { out.flush(); } catch (Throwable t) {}
	      continue;
	  }
          
	  HandleValue[] values = ((ResolutionResponse) response).getHandleValues();
	  if(values.length!=1){
	      out.println("FAILURE: "+handle+": Handle has more than one URL value.. do not know which one to update.");
	      try { out.flush(); } catch (Throwable t) {}
	      continue;
	  }
	  
	  //do update
	  values[0].setData(Util.encodeString(url));
	  mvReq.handle = handleBytes;
	  mvReq.values = values;
	  mvReq.clearBuffers();
	  response = resolver.processRequest(mvReq);
	  if(response.responseCode==AbstractMessage.RC_SUCCESS) {
	      successes++;
	      if(detailedResults) {
		  out.println("Updated: "+handle);
	      }
	  } else {
	      out.println("FAILURE: "+handle+": "+response);
	  }
       } catch (HandleException e) {
	   out.println("FAILURE: "+handle+": "+e);
       }
       try { out.flush(); } catch (Throwable t) {}
    }
    
    out.println("SUMMARY: "+successes+" of "+records+" records updated");
  }

  private void processRequest(HttpServletRequest req, HttpServletResponse resp,
                              Hashtable mergeDict)
    throws ServletException, IOException
  {
    LoginInfo login = null;
    PrintWriter out = null;
    try {
      resp.setContentType("text/html");
      out = new PrintWriter(resp.getOutputStream());
      login = getLoginInfo(req);

      mergeDict.put("userid", login.userid);
      mergeDict.put("passwd", login.passwd);
      mergeDict.put("prefix", login.prefix);
      
      showTemplate("admin_header.html", out, mergeDict);
      String action = req.getParameter("action");
      action = action==null ? "" : action.trim();   
            
      if(action.equals("login")) {
        //verify that the prefix exists
        if(!login.verifyPrefix()) {
          mergeDict.put("login_message", "Invalid prefix, please try again.");
          action = "";
        }
        
        else if(login.verifyLogin()) {
          action = req.getParameter("action2");
          action = action==null ? "" : action.trim();
        } else {
          mergeDict.put("login_message", "Invalid username/password, please try again.");
          action = "";
        }
      }
      
      if(action.equals("goto_new")) {
        showTemplate("new.html", out, mergeDict);
      } else if(action.equals("goto_edit")) {
        showTemplate("edit.html", out, mergeDict);
      } else if(action.equals("goto_delete")) {
        showTemplate("delete.html", out, mergeDict);
      } else if(action.equals("goto_batch")) {
        showTemplate("batch.html", out, mergeDict);
      } else if(action.equals("goto_list")) {
        doList(req, login, out, mergeDict);        
      } else if(action.equals("goto_changePassword")){
	showTemplate("password.html", out, mergeDict); 
      } else if(action.equals("new")) {
        doNew(req, login, out, mergeDict);
      }	else if(action.equals("new_more")){
	doNewMore(req, login, out, mergeDict);
      } else if(action.equals("delete")) {
        doDelete(req, login, out, mergeDict);
      } else if(action.equals("begin_edit")) {
        doBeginEdit(req, login, out, mergeDict);
      } else if(action.equals("edit")) {
        doEdit(req, login, out, mergeDict);
      } else if(action.equals("changePassword")){
	  doChangePassword(req, login, out, mergeDict);

      } else {
        if(action.length()>0) {
          mergeDict.put("login_message", "Invalid action: '"+action+"'");
        }
        showTemplate("admin_form.html", out, mergeDict);
      }
      
    } catch (Exception e) {
      out.println("There was an error processing your request: "+e);
      out.println("<pre>");
      e.printStackTrace(out);
      out.println("</pre>");
    }

    try {
      showTemplate("admin_footer.html", out, mergeDict);
    } catch (Exception e) {
      out.println("<br><br>Unable to print footer: "+e);
      out.println("<pre>");
      e.printStackTrace(out);
      out.println("</pre>");
    }
    
    try { out.flush(); } catch (Exception e) {}
    try { out.close(); } catch (Exception e) {}
  }


  private AdminRecord getAdminRecord(String prefix) {
    return new AdminRecord(Util.getZeroNAHandle(Util.encodeString(prefix)), ADMIN_GROUP_IDX,
                           false, true, false, false, true, true,
                           true, true, true, true, true, false);
  }
  


  /**change user password */
  private void doChangePassword(HttpServletRequest req, LoginInfo login, 
                                PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String newPassword1 = req.getParameter("password1");
    String newPassword2 = req.getParameter("password2");

    if(!newPassword1.equals(newPassword2)){
      mergeDict.put("password_message", "passwords do not match, please re-enter");
      showTemplate("password.html", out, mergeDict);
      return;
    }

    byte idHandle[] = Util.encodeString(adminNA+'/'+login.userid);
    HandleValue value = new HandleValue();
    value.setIndex(300);
    value.setType(Common.STD_TYPE_HSSECKEY);
    value.setData(Util.encodeString(newPassword1));
    value.setAnyoneCanRead(false);
    ModifyValueRequest mhReq = new ModifyValueRequest(idHandle,value, login.getAuth());
    AbstractResponse response = resolver.processRequest(mhReq);
    if(response.responseCode==AbstractMessage.RC_SUCCESS) {
      mergeDict.put("login_message", "Password Successfully changed, Please re-login with new password");
    } else {
      mergeDict.put("login_message", "Unable to change password  - "+response);
    }
	
    showTemplate("admin_form.html", out, mergeDict);
  }


  /**Create a new Handle */
  private void doNew(HttpServletRequest req, LoginInfo login,
                     PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String handleStr = login.prefix + '/' +
      decodeURLIgnorePlus(req.getParameter("handle_suffix"));
    String value = req.getParameter("value");

    //continue to add more values to the new handle
    if(req.getParameter("more")!=null){   
      int add_counter = 0;
      Vector addVect = new Vector();
      mergeDict.put("adds", addVect);
      Hashtable valueDict = new Hashtable();
      valueDict.put("idx", String.valueOf(add_counter++));
      valueDict.put("value_data", value);
      addVect.addElement(valueDict);

      //add 5 new values
      for(int i=0; i<5; i++){
        Hashtable value2Dict = new Hashtable();
        value2Dict.put("idx", String.valueOf(add_counter++));
        value2Dict.put("value_data", "");
        addVect.addElement(value2Dict);
      }
      mergeDict.put("handle", handleStr);
      mergeDict.put("add_counter", String.valueOf(add_counter));
      showTemplate("new_more.html", out, mergeDict);
      return;
    }

    //create new handle
    byte handle[] = Util.encodeString(handleStr);
    AdminRecord admin = getAdminRecord(login.prefix);

    HandleValue values[] = new HandleValue[2];
    values[0] = new HandleValue();
    values[0].setIndex(1);
    values[0].setType(Common.STD_TYPE_URL);
    values[0].setData(Util.encodeString(value));

    values[1] = new HandleValue();
    values[1].setIndex(100);
    values[1].setType(Common.STD_TYPE_HSADMIN);
    values[1].setData(Encoder.encodeAdminRecord(admin));

    CreateHandleRequest chReq =
      new CreateHandleRequest(handle, values, login.getAuth());
	
    AbstractResponse response = resolver.processRequest(chReq);
    if(response.responseCode==AbstractMessage.RC_SUCCESS) {
      mergeDict.put("login_message", "Handle \""+handleStr+"\" Successfully Created");
    } else {
      mergeDict.put("login_message", "Unable to create Handle: "+handleStr+" - "+response);
    }
    showTemplate("admin_form.html", out, mergeDict);
  }
    
  /**Input more values to the new handle*/
  private void doNewMore(HttpServletRequest req, LoginInfo login, 
                         PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String handleStr = req.getParameter("handle");
    int add_counter = Integer.parseInt(req.getParameter("add_counter"));
	
    //continue to add more values to the new handle
    if(req.getParameter("more")!=null){
      //copy inputed values from last page
      Vector addVect = new Vector();
      mergeDict.put("adds", addVect);
      int new_counter=0;
      for(int i=0; i<add_counter; i++){
        String value = req.getParameter("value_index_"+String.valueOf(i)).trim();
        if(value==null || value.length()<=0) continue;
        Hashtable valueDict = new Hashtable();
        valueDict.put("idx", String.valueOf(new_counter++));
        valueDict.put("value_data", value);
        addVect.addElement(valueDict);
      }
      //add 5 new values
      for(int i=0; i<5; i++){
        Hashtable valueDict = new Hashtable();
        valueDict.put("idx", String.valueOf(new_counter++));
        valueDict.put("value_data", "");
        addVect.addElement(valueDict);
      }
      mergeDict.put("handle", handleStr);
      mergeDict.put("add_counter", String.valueOf(new_counter));
      showTemplate("new_more.html", out, mergeDict);
      return;
    }

    //create the new handle
    byte handle[] = Util.encodeString(handleStr);
    AdminRecord admin = getAdminRecord(login.prefix);

    Vector v = new Vector();
    //get values from last page
    for(int i=0; i<add_counter; i++){
      String value = req.getParameter("value_index_"+String.valueOf(i)).trim();
      if(value!=null && value.length()>0) v.addElement(value);
    }
	
    int size = v.size();
    HandleValue[] values = new HandleValue[size+1];
    for(int i=0; i<size; i++){
      values[i] = new HandleValue();
      values[i].setIndex(i+1);
      values[i].setType(Common.STD_TYPE_URL);
      values[i].setData(Util.encodeString((String) v.elementAt(i)));
    }
    values[size] = new HandleValue();
    values[size].setIndex(100);
    values[size].setType(Common.STD_TYPE_HSADMIN);
    values[size].setData(Encoder.encodeAdminRecord(admin));
	
    CreateHandleRequest chReq = new CreateHandleRequest(handle, values, login.getAuth());

    AbstractResponse response = resolver.processRequest(chReq);
    if(response.responseCode == AbstractMessage.RC_SUCCESS){
      mergeDict.put("login_message", "Handle \""+handleStr+"\" Successfully Created");
    } else{
      mergeDict.put("login_message", "Unable to create Handle: "+handleStr+" - "+response);
    }

    showTemplate("admin_form.html", out, mergeDict);
  }

  /**Delete a Handle */
  private void doDelete(HttpServletRequest req, LoginInfo login,
                        PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String handleStr = login.prefix + '/' +
      decodeURLIgnorePlus(req.getParameter("handle_suffix"));
    byte handle[] = Util.encodeString(handleStr);
    DeleteHandleRequest dhReq =
      new DeleteHandleRequest(handle, login.getAuth());
	
    AbstractResponse response = resolver.processRequest(dhReq);
    if(response.responseCode==AbstractMessage.RC_SUCCESS) {
      mergeDict.put("login_message", "Handle \""+handleStr+"\" Successfully Deleted");
    } else {
      mergeDict.put("login_message", "Unable to delete Handle: "+response);
    }
    showTemplate("admin_form.html", out, mergeDict);
  }
    
    
  /** Retrieve and display the current values of the Handle so that they can be edited. */
  private void doBeginEdit(HttpServletRequest req, LoginInfo login,
                           PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String handleStr = login.prefix + '/' +
      decodeURLIgnorePlus(req.getParameter("handle_suffix"));
    mergeDict.put("handle", handleStr);
    byte handle[] = Util.encodeString(handleStr);
    ResolutionRequest rReq = new ResolutionRequest(handle,
                                                   new byte[][]{Common.STD_TYPE_URL},
                                                   null, login.getAuth());
	
    rReq.authoritative = true;
    AbstractResponse response = resolver.processRequest(rReq);
    if(response.responseCode==AbstractMessage.RC_SUCCESS) {
      Vector valueVect = new Vector();
      mergeDict.put("values", valueVect);
      HandleValue values[] = ((ResolutionResponse)response).getHandleValues();
      int counter = 0;
      for(int i=0; i<values.length; i++) {
        if(values[i].hasType(Common.STD_TYPE_URL)) {
          Hashtable valueDict = new Hashtable();
          valueDict.put("value_idx", String.valueOf(values[i].getIndex()));
          valueDict.put("value_data", Util.decodeString(values[i].getData()));
          valueDict.put("counter", String.valueOf(counter++));
          valueDict.put("modify", "");
          valueDict.put("remove", "");
          valueVect.addElement(valueDict);
        }
      }
	    
      Vector addVect = new Vector();
      mergeDict.put("adds", addVect);

      int add_index=0;
      for(int i=0; i<3; i++){
        Hashtable valueDict = new Hashtable();
        valueDict.put("value_data","");
        valueDict.put("add_counter", String.valueOf(i));
        valueDict.put("add", "");
        addVect.addElement(valueDict);
      }
      mergeDict.put("add_counter", String.valueOf(3));
      showTemplate("edit2.html", out, mergeDict);
    } else {
      out.println("Unable to edit Handle: "+response);
    }
  }
    
  /** Save the edited values associated with the handle/name. */
  private void doEdit(HttpServletRequest req, LoginInfo login,
                      PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String handleStr = req.getParameter("handle");
    int add_counter = Integer.parseInt(req.getParameter("add_counter").trim());

    //continue to add handle values
    if(req.getParameter("more") != null){
      mergeDict.put("handle", handleStr);

      //copy existing values from last page
      Vector valueVect = new Vector();
      mergeDict.put("values", valueVect);
      int counter =0;
      while(true){
        String indexStr = req.getParameter("value_index_"+counter);
        if(indexStr == null) break;
		
        Hashtable valueDict = new Hashtable();
        valueDict.put("value_idx", indexStr);
        String tmp = req.getParameter("value_data_"+String.valueOf(counter));
        if(tmp != null) valueDict.put("value_data", tmp);
        valueDict.put("counter", String.valueOf(counter));
        if(req.getParameter("modify_index_"+String.valueOf(counter))!=null)
          valueDict.put("modify", CHECKED);
        else
          valueDict.put("modify", "");
        if(req.getParameter("remove_index_"+String.valueOf(counter))!=null)
          valueDict.put("remove", CHECKED);
        else
          valueDict.put("remove", "");
        valueVect.addElement(valueDict);
		
        counter++;
      }
	    
      //copy added values from last page
      Vector addVect = new Vector();
      mergeDict.put("adds", addVect);
      int ac=0;
      for(int i=0; i<add_counter; i++){
        Hashtable valueDict = new Hashtable();
        String tmp = req.getParameter("add_value_data_"+String.valueOf(i)).trim();
        if(tmp == null || tmp.length()<=0) continue;
        valueDict.put("value_data", tmp);
        valueDict.put("add_counter", String.valueOf(ac++));
        if(req.getParameter("add_"+String.valueOf(i))!=null)
          valueDict.put("add", CHECKED);
        else
          valueDict.put("add", "");
        addVect.addElement(valueDict);
      }

      //add new values
      for(int i=0; i<3; i++){
        Hashtable valueDict = new Hashtable();
        valueDict.put("value_data","");
        valueDict.put("add_counter", String.valueOf(ac++));
        valueDict.put("add", "");
        addVect.addElement(valueDict);
      }

      mergeDict.put("add_counter", String.valueOf(ac));
      showTemplate("edit2.html", out, mergeDict);
      return;
    }
	
    byte handle[] = Util.encodeString(handleStr);
	
    Vector editValues = new Vector();
    Vector delValues = new Vector();
    Vector addValues = new Vector();
    int counter = 0; 
    Vector indexVect = new Vector();
    while(true) {
      String indexStr = req.getParameter("value_index_"+counter);
      if(indexStr==null)
        break;
      indexVect.addElement(indexStr);
      if(req.getParameter("modify_index_"+counter) != null){
        HandleValue value = new HandleValue();
        value.setIndex(Integer.parseInt(indexStr));
        value.setType(Common.STD_TYPE_URL);
        value.setData(Util.encodeString(req.getParameter("value_data_"+counter)));
        editValues.addElement(value);
      } else if(req.getParameter("remove_index_"+counter) != null){
        delValues.addElement(indexStr);
      }
      counter++;
    }
	
    int add_index =1;
    for(int i=0; i<add_counter; i++){
      String dataStr = req.getParameter("add_value_data_"+i);
      if (dataStr == null) continue;
      if(req.getParameter("add_"+i)!= null){
        HandleValue value = new HandleValue();
        while(indexVect.contains(String.valueOf(add_index++))) {}
        value.setIndex(add_index-1);
        value.setType(Common.STD_TYPE_URL);
        value.setData(Util.encodeString(dataStr));
        addValues.addElement(value);
      }
    }

	
    if(editValues.size()<=0 && delValues.size()<=0 && addValues.size()<=0) {
      out.println("<br><h1><font color=red>Error: No updated values sent!</font></h1><br>");
      return;
    }
	 
    StringBuffer log = new StringBuffer("Handle \""+handleStr+"\"-- ");
    if(addValues.size() > 0)
      try{
        HandleValue values[] = new HandleValue[addValues.size()];
        for(int i=0; i<values.length; i++) {
          values[i] = (HandleValue)addValues.elementAt(i);
        }
        AddValueRequest aReq = new AddValueRequest(handle, values, login.getAuth());    
        AbstractResponse response = resolver.processRequest(aReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          log.append("Successfully added value(s)");
        } else {
          log.append("Add Value Error: Received unexpected response "+response+" || ");
        }
      }catch(HandleException e){
        log.append("Add Value Error: " +e.getMessage()+" || ");
      }

    if(editValues.size() > 0)	    
      try{
        HandleValue values[] = new HandleValue[editValues.size()];
        for(int i=0; i<values.length; i++) {
          values[i] = (HandleValue)editValues.elementAt(i);
        }
        ModifyValueRequest mReq = new ModifyValueRequest(handle, values, login.getAuth());
        AbstractResponse response = resolver.processRequest(mReq);
		
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          log.append("Successfully modified value(s)");
        } else {
          log.append("Modify Value Error: Received unexpected response "+response+" || ");
        }
      }catch(HandleException e){
        log.append("Modify Value Error: "+e.getMessage()+" || ");
      }
	

    if(delValues.size() > 0)
      try{
        int indexes[] = new int[delValues.size()];
        for(int i=0; i<indexes.length; i++) {
          indexes[i] = Integer.parseInt((String) delValues.elementAt(i));
        }
		
        RemoveValueRequest rReq = new RemoveValueRequest(handle, indexes, login.getAuth());
		
        AbstractResponse response = resolver.processRequest(rReq);
		
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          log.append("Successfully removed value(s) ");
        } else {
          log.append("Remove Value Error: Received unexpected response "+response+" || ");
        }
      }catch(HandleException e){
        log.append("Remove Value Error" +e.getMessage()+" || ");
      }
	
    mergeDict.put("login_message", new String(log));
    showTemplate("admin_form.html", out, mergeDict);       

  }
    
  /**List handles under given sub_naming_authority handle. */
  private void doList(HttpServletRequest req, LoginInfo login,
                      PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    String naHandleStr = Util.decodeString(Common.NA_HANDLE_PREFIX)+login.prefix;
    byte naHandle[] = Util.encodeString(naHandleStr);
    ListHandlesRequest listReq = new ListHandlesRequest(naHandle, login.getAuth());

    ResolutionRequest dudReq =
      new ResolutionRequest(Util.encodeString(login.prefix+"/test"), null, null, null);
    SiteInfo sites[] = resolver.findLocalSites(dudReq);

    //pick a site at random...
    SiteInfo site = sites[Math.abs(new java.util.Random().nextInt())%sites.length];

    //send a list-handles request to each server in the site...
    out.println("<h3>List handles under \"" + naHandleStr +"\":</h3>");
    for(int i=0; i<site.servers.length; i++) {
      ServerInfo server = site.servers[i];
      out.println("Contacting server: "+server +"<br>");
      try{
        AbstractResponse response = resolver.sendRequestToServer(listReq, site, server);
        if(response.responseCode!=AbstractMessage.RC_SUCCESS ||
           !(response instanceof ListHandlesResponse)) {
          out.println("Unable to list handles: "+response+"<br>");
          return;
        } else {
          ListHandlesResponse lhResp = (ListHandlesResponse)response;
          byte handles[][] = lhResp.handles;
          for(int j=0; j<handles.length; j++) {
            out.println(Util.decodeString(handles[j]) +"<br>");
          }
        }
      }catch(Exception e) {
        e.printStackTrace(out);
        out.println("<br>");
      }
    }
    out.println("<br>Listing of handles finished. <br><br>");
  }
  
  //Utility functions
  private LoginInfo getLoginInfo(HttpServletRequest req) {
    return new LoginInfo(req.getParameter("userid"),
                         req.getParameter("passwd"),
                         req.getParameter("prefix"));
  }
    
  private LoginInfo getLoginInfo(Hashtable req) {
    return new LoginInfo((String)req.get("userid"),
                         (String)req.get("passwd"),
                         (String)req.get("prefix"));
  }
    
  private void showTemplate(String templateFileStr, PrintWriter out, Hashtable mergeDict)
    throws Exception
  {
    File templateFile = new File(templateDir, templateFileStr);
    if(!templateFile.exists()) {
      out.println("[Error: template does not exist: "+templateFile.getAbsolutePath()+"]<br>");
      return;
    }
    if(!templateFile.canRead()) {
      out.println("[Error: can't read template file: "+templateFile+"]<br>");
      return;
    }
	
    out.print(Template.subDictIntoFile(templateFile, mergeDict));
  }
    
    
  class LoginInfo {
    String userid;
    String passwd;
    String prefix;
	
    LoginInfo(String userid, String passwd, String prefix) {
      this.userid = (userid==null) ? "" : userid.trim();
      this.passwd = (passwd==null) ? "" : passwd.trim();
      this.prefix = (prefix==null) ? "" : prefix.trim();
    }

    /** Verify that the prefix exists in the system. */
    public boolean verifyPrefix() {
      if(!verifyPrefixes)
        return true;
      if(prefix.length()<=0)
        return false;
      
      ResolutionRequest rReq = new ResolutionRequest(null, null, null, null);
      rReq.authoritative = true;
      rReq.handle = Util.getZeroNAHandle(Util.encodeString(prefix));
      rReq.clearBuffers();

      try {
        AbstractResponse response = resolver.processRequest(rReq);
        if(response.responseCode==AbstractMessage.RC_SUCCESS) {
          return true;
        } else if (response.responseCode==AbstractMessage.RC_HANDLE_NOT_FOUND) {
          return false;
        }
      } catch (HandleException e) {
        System.err.println("ERROR: "+e.getCode()+" "+HandleException.getCodeStr(e.getCode()));
      }
      return false;
    }
    
    /** Verify that the user is who they claim to be.  This doesn't
        verify that the user has any permissions at all. */
    public boolean verifyLogin() {
      if(userid.length()<=0 || passwd.length()<=0 || prefix.length()<=0)
        return false;
	    
      try {
        byte idHandle[] = Util.encodeString(adminNA+'/'+userid);
        SecretKeyAuthenticationInfo auth =
          new SecretKeyAuthenticationInfo(idHandle, SEC_KEY_IDX, Util.encodeString(passwd));

        ResolutionRequest dummyReq =
          new ResolutionRequest(Common.BLANK_HANDLE, null, null, null);
        dummyReq.majorProtocolVersion = 2;
        dummyReq.minorProtocolVersion = 0;
        ChallengeResponse challResp =
          new ChallengeResponse(dummyReq);
        challResp.majorProtocolVersion = 2;
        challResp.minorProtocolVersion = 0;

        byte authBytes[] =
          auth.authenticate(challResp, dummyReq);
		
        VerifyAuthRequest vaReq = 
          new VerifyAuthRequest(idHandle, challResp.nonce, 
                                challResp.requestDigest,challResp.rdHashType,
                                authBytes,
                                SEC_KEY_IDX, null);
        vaReq.certify = true;
        AbstractResponse response = resolver.processRequest(vaReq);
		
        if(!(response instanceof VerifyAuthResponse)) {
          System.err.println("Unexpected response verifying authentication: "+response);
          return false;
        }
		
        return ((VerifyAuthResponse)response).isValid;
      } catch (Throwable e) {
        System.err.println("Error verifying user: "+e);
        e.printStackTrace(System.err);
      }
      return false;
    }
	
	
    SecretKeyAuthenticationInfo getAuth() {
      byte idHandle[] = Util.encodeString(adminNA+'/'+userid);
      return new SecretKeyAuthenticationInfo(idHandle, SEC_KEY_IDX,
                                             Util.encodeString(passwd));
    }

  }
    
    
  /**
     * decodes the special characters in a URL encoded string *except* for
     * the + to space conversion.
     */
  public static String decodeURLIgnorePlus(String str)
    throws UTFDataFormatException
  {
    byte utf8Buf[] = new byte[str.length()];
    int utf8Loc = 0;
    int strLoc = 0;
    int strLen = str.length();
    while(strLoc < strLen) {
      char ch = str.charAt(strLoc++);
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str.charAt(strLoc++),
                                           str.charAt(strLoc++));
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }
	
    if(!Util.isValidString(utf8Buf, 0, utf8Loc)) {
      throw new UTFDataFormatException("Invalid UTF-8 encoding: "+str);
    }
	
    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    }
  }
    
  public static final byte decodeHexByte(char ch1, char ch2) {
    ch1 = (char) ((ch1>='0' && ch1<='9') ? ch1-'0' : ((ch1>='a' && ch1<='z') ? ch1-'a'+10 : ch1-'A'+10));
    ch2 = (char) ((ch2>='0' && ch2<='9') ? ch2-'0' : ((ch2>='a' && ch2<='z') ? ch2-'a'+10 : ch2-'A'+10));
    return (byte)(ch1<<4 | ch2);
  }
    
    
}
