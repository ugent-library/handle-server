/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.batch;

import java.io.*;
import java.util.*;

/**
 Command line tool to average the raw data output performance file from DOIBatch.
 
 Execution is done with the following command:
 java net.handle.apps.batch.AvgRawData [rawdatafile] [howmany_raw_data:1_avgED_data] [avgED_file] [desired_col_num_in_avgED_file]

 where [rawdatafile] is the output file from DOIBatch execution;
 [howmany_raw_data:1_avgED_data] is the number that you wish to average with, like 5, 10;
 [avgED_file] is the file where all averaged data will go to;
 [desired_col_num_in_avgED_file] is the number of cloumn you wish to have in averaged file.
 
 i.e. Example as: "java net.handle.apps.batch.AvgRawData stat500 5 avgDataFile 1"
 will average every 5 data rows in <stat500> and save one row of data in <avgDataFile>.
 The data in averaged file looked like 
 0.456
 0.5858
 1.044
 2.374
 ..
*/

public class AvgRawData {
    
    
public static void printUsage() {
    System.err.println("Usage: java net.handle.apps.batch.AvgRawData"+
                       " <rawdatafile> <howmany_raw_data:1_avgED_data> <avgED_file> <desired_col_num_in_avgED_file>");
    System.err.println("\nExample as: java net.handle.apps.batch.AvgRawData stat500 5 avgDataFile 1");
    System.err.println("will average 5 data rows in <stat500> file and average it and save to one row in <avgDataFile>.");
    System.err.println("For a statatistics file from updates, do as: java net.handle.apps.batch.AvgRawData statUpd500 5 avgUpdDataFile 3");                  
    System.err.println("so it will average every 5 raw data on resoltion time, remove value time, add value time seperately and save it.");
}
  
public static void main(String argv[])
    throws Exception
  {
    BufferedReader fileRaw = null;
    Writer fileEven = null;
    
    if(argv.length != 4) {
      printUsage();
      System.exit(-1);
      return;
    }
    
    String howmanytoEven = argv[1];
    int weight = 5;
    try {
      weight = Integer.valueOf(howmanytoEven).intValue();
    }
    catch (Exception e) {
      System.out.println("Using 5 as default.");
    }
   
    fileRaw = new BufferedReader(new InputStreamReader(new FileInputStream(new File(argv[0])),"UTF-8"));
    fileEven = new OutputStreamWriter(new FileOutputStream(argv[2]),"UTF-8");
    
    int col = 1;
    if(argv.length > 3) {
      try {
        col = Integer.valueOf(argv[3]).intValue();
      }
      catch (Exception e){}
    }
    if (col < 1) col = 1;
    System.out.println("Column number is " + col);
    
    String line;
    int commonIdx;
    int totalNumber = 0;
    int lineNum = 0;
    
    float[][] rawArry = new float[col][weight];
    
    int i = 0;
    while (true) {
        
      line = fileRaw.readLine();
      lineNum++;
      if(line==null)
        break;
      line = line.trim();
      if(line.length()<=0)
        continue;
        
      commonIdx = line.indexOf(':');
      if(commonIdx > 0){
        //this is a comment line, skip
        continue;
      }
  
      commonIdx = line.indexOf('_');
      if(commonIdx > 0){
        //this is a comment line, skip
        continue;
      }
      
      try {
        i++;
        //if the line has more than data
        float raw = 0.0f;
        float sumLine = 0.0f;  
        System.out.println("reading line " + line);
        StringTokenizer st = new StringTokenizer(line, "\t");
        if (st.hasMoreTokens()) {
          
            int colInd = 0;
            while (st.hasMoreTokens()) {
              String token = st.nextToken();
              
              if (col == 1){
                //sum all data together
                sumLine += Float.valueOf(token).floatValue();
              } else {
          
                raw = Float.valueOf(token).floatValue();
            
                rawArry[colInd][i-1] = raw;
                System.out.println("reading " + token);
                colInd++;
              }
            }
            
            if (col == 1)
              rawArry[0][i-1] = sumLine;      
        
        }
        else {
          raw = Float.valueOf(line).floatValue();
          rawArry[0][i-1] = raw;
          System.out.println("reading " + line);
        }
       
        
        if (i % weight == 0) {
          System.out.println("do averageING now");
          try {
          float[] sum = new float[col];
          for (int ind = 0; ind < col; ind++)
            sum[ind] = 0.0f;
            
          for (int ind = 0; ind < col; ind++) {
            for (int j = 0; j < weight; j++) {
              sum[ind] += rawArry[ind][j];
            }
            
            //store the average in same place
            sum[ind] = sum[ind]/weight;
            
          }
          
          for (int ind =0; ind < col-1; ind++){
            fileEven.write( sum[ind] + "\t");
            System.out.println("writing <" + sum[ind] + ">");
          }
            
            
          //float evenOfSamples = sum/weight;
          fileEven.write( sum[col-1] + "\n");
          System.out.println("writing <" + sum[col-1] + ">");
          }
          catch (Exception e) {
            e.printStackTrace();
          }
          
          //reset
          i = 0;
        }
      }
      catch (Exception e){
        if (e instanceof NumberFormatException) i--;
      }
      
    }
 
    try {
        fileEven.close();
    }
    catch (Exception e){}
  }
}
