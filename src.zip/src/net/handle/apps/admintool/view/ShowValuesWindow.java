/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import net.handle.awt.*;
import net.cnri.guiutil.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class ShowValuesWindow
  extends JFrame
  implements ActionListener,
             MouseListener,
             ViewConstants
{
  private int mode = VIEW_HDL_MODE;
  private String handle = null;
  private HandleValue originalValues[] = null;
  private DefaultListModel valuesListModel;
  private JList valuesList;
  private AdminToolUI ui;
  
  private HDLAction saveValuesAction;
  private HDLAction saveValueAction;
  private HDLAction editHandleAction;
  private HDLAction signHandleAction;
  private HDLAction viewValueAction;
  private HDLAction editValueAction;
  private HDLAction testSiteAction;
  
  private JPanel modValPanel;
  private JButton copyButton;
  private JButton doneButton;
  private JButton cancelButton;
  private JButton editValButton;
  private JLabel sigStatusLabel;
  
  private JButton addValButton;
  private JButton delValButton;
  private JButton editHdlButton;
  private JPopupMenu addValPopup;
  
  private boolean canceled = true;
  
  public ShowValuesWindow(AdminToolUI appUI) {
    super("Show Handle Values");
    this.ui = appUI;
    
    setJMenuBar(appUI.getAppMenu());
    
    addValPopup = new JPopupMenu();
    addValPopup.add(new HDLAction(ui, "add_url_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addValueWithParams(1, Common.STD_TYPE_URL,
                           Util.encodeString("http://example.com/"));
      }
    }));
    
    addValPopup.add(new HDLAction(ui, "add_email_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addValueWithParams(1, Common.STD_TYPE_EMAIL,
                           Util.encodeString("you@example.com"));
      }
    }));
    
    addValPopup.add(new HDLAction(ui, "add_admin_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        AdminRecord adminInfo = new AdminRecord();
        String hdl = handle;
        if(hdl==null) hdl = "0.NA/test";
        byte hdlBytes[] = Util.encodeString(handle);
        try {
          adminInfo.adminId = ui.getMain().getResolver().getNAHandle(hdlBytes);
        }
        catch (HandleException e) {
          adminInfo.adminId = Util.getZeroNAHandle(hdlBytes);        
        }
        adminInfo.adminIdIndex = 200;
        adminInfo.perms[AdminRecord.DELETE_HANDLE] = true;
        adminInfo.perms[AdminRecord.ADD_VALUE] = true;
        adminInfo.perms[AdminRecord.REMOVE_VALUE] = true;
        adminInfo.perms[AdminRecord.MODIFY_VALUE] = true;
        adminInfo.perms[AdminRecord.READ_VALUE] = true;
        adminInfo.perms[AdminRecord.ADD_ADMIN] = true;
        adminInfo.perms[AdminRecord.REMOVE_ADMIN] = true;
        adminInfo.perms[AdminRecord.MODIFY_ADMIN] = true;
        adminInfo.perms[AdminRecord.ADD_HANDLE] = true;
        adminInfo.perms[AdminRecord.LIST_HANDLES] = false;
        adminInfo.perms[AdminRecord.ADD_NAMING_AUTH] = false;
        adminInfo.perms[AdminRecord.DELETE_NAMING_AUTH] = false;
        
        addValueWithParams(100, Common.STD_TYPE_HSADMIN,
                           Encoder.encodeAdminRecord(adminInfo));
      }
    }));
    
    addValPopup.add(new HDLAction(ui, "add_blank_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addValueWithParams(1, new byte[0],
                           Util.encodeString(""));
      }
    }));
    
    addValPopup.addSeparator();
    
    addValPopup.add(new HDLAction(ui, "add_digest_all", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addHashOfAllValues();
      }
    }));
    
    addValPopup.add(new HDLAction(ui, "add_digest_selected", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addHashOfSelectedValues();
      }
    }));
    
    
    addValPopup.add(new HDLAction(ui, "add_signature", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addSignature();
      }
    }));
    
    addValPopup.add(new HDLAction(ui, "add_digest_and_sig_all", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addDigestAndSignatureForAllValues();
      }
    }));

    addValPopup.pack();
    
    valuesListModel = new DefaultListModel();
    valuesList = new JList(valuesListModel);
    valuesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    valuesList.setCellRenderer(new HandleValueRenderer());
    doneButton = new JButton(ui.getStr("ok"));
    cancelButton = new JButton(ui.getStr("cancel"));
    editValButton = new JButton(ui.getStr("edit_val_button"));
    addValButton = new JButton(ui.getStr("add_val_button"));
    delValButton = new JButton(ui.getStr("remove_val_button"));
    editHdlButton = new JButton(ui.getStr("edit_hdl_button"));
    copyButton = new JButton(ui.getStr("copy_hdl_button"));
    sigStatusLabel = new JLabel(" ");
    
    saveValuesAction = new HDLAction(ui, "save_values", "save_values", this);
    saveValueAction = new HDLAction(ui, "save_value", "save_value", this);
    editHandleAction = new HDLAction(ui, "edit_handle", "edit_handle", this);
    viewValueAction = new HDLAction(ui, "view_value", "view_value", this);
    editValueAction = new HDLAction(ui, "edit_value", "edit_value", this);
    testSiteAction = new HDLAction(ui, "run_site_test", "run_site_test", this);
    signHandleAction = new HDLAction(ui, "sign_handle", "sign_handle", this);
    
    JPanel p = new JPanel(new GridBagLayout());
    p.add(new JScrollPane(valuesList), GridC.getc(0,0).wxy(1,1).colspan(2).fillboth());
    modValPanel = new JPanel(new GridBagLayout());
    modValPanel.add(addValButton, GridC.getc(0,0).insets(0,0,0,10));
    modValPanel.add(editValButton, GridC.getc(1,0).insets(0,0,0,10));
    modValPanel.add(delValButton, GridC.getc(2,0).insets(0,0,0,10));
    modValPanel.add(new JButton(signHandleAction), GridC.getc(3,0).insets(0,0,0,10));
    p.add(modValPanel, GridC.getc(0,1).insets(10,10,2,10).fillboth());
    p.add(editHdlButton, GridC.getc(0,1).insets(10,10,2,10));
    p.add(copyButton, GridC.getc(1,1).insets(10,10,2,10).east());
    JPanel bottomLine = new JPanel(new GridBagLayout());
    bottomLine.add(sigStatusLabel, GridC.getc(0,0).wx(1).insets(0,0,0,10).fillboth());
    bottomLine.add(cancelButton, GridC.getc(1,0).insets(0,0,0,10));
    bottomLine.add(doneButton, GridC.getc(2,0).insets(0,0,0,10));
    p.add(bottomLine, GridC.getc(0,2).insets(2,10,10,0).colspan(2).east());
    
    getContentPane().add(p);
    
    cancelButton.addActionListener(this);
    doneButton.addActionListener(this);
    editValButton.addActionListener(this);
    addValButton.addActionListener(this);
    delValButton.addActionListener(this);
    editHdlButton.addActionListener(this);
    copyButton.addActionListener(this);
    valuesList.addMouseListener(this);
    
    getRootPane().setDefaultButton(doneButton);

    setSize(700, 330);
  }
  
  public void mousePressed(MouseEvent evt) {
    if(evt.isPopupTrigger()) {
      showPopupMenu(evt);
    }
  }
  public void mouseReleased(MouseEvent evt) {
    if(evt.isPopupTrigger()) {
      showPopupMenu(evt);
    }
  }
  public void mouseExited(MouseEvent evt) {}
  public void mouseEntered(MouseEvent evt) {}
  public void mouseClicked(MouseEvent evt) {
    if(evt.isPopupTrigger()) {
      showPopupMenu(evt);
    } else if(evt.getClickCount()>=2) {
      if(mode==EDIT_HDL_MODE || mode==CREATE_HDL_MODE) {
        editValue();
      } else {
        viewSelectedValue();
      }
    }
  }

  private void revert() {
    this.setValues(this.handle, this.originalValues, this.mode);
  }

  private boolean performOperation(String opName, AbstractRequest req) {
    AuthenticationInfo auth = ui.getAuthentication(false);
    if(auth==null) return false;
    req.authInfo = auth;
    
    try {
      AbstractResponse resp;
      SiteInfo site = ui.getSpecificSite();
      if(site==null) {
          resp = ui.getMain().getResolver().processRequest(req);
      }
      else {
          resp = ui.getMain().getResolver().sendRequestToSite(req,site);
      }
      if(resp==null || resp.responseCode!=AbstractMessage.RC_SUCCESS) {
        JOptionPane.showMessageDialog(this, "The '"+opName+"' operation"+
                                      " was not successful.  Response was: "+resp);
        return false;
      } else {
        return true;
      }
    } catch (Exception e) {
      e.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this, "There was an error processing the"+
                                    " '"+opName+"' operation.\n\nMessage: "+e);
      return false;
    }
  }
  
  private void deleteValue() {
    Object selObjs[] = valuesList.getSelectedValues();
    if(selObjs==null || selObjs.length<=0) return;
    
    if(JOptionPane.YES_OPTION==
       JOptionPane.showConfirmDialog(this,
                                     "Are you sure you would like to delete the selected values?",
                                     "Delete Confirmation",
                                     JOptionPane.YES_NO_OPTION,
                                     JOptionPane.QUESTION_MESSAGE)) {
      if(mode==EDIT_HDL_MODE) {
        int idxList[] = new int[selObjs.length];
        for(int i=0; i<idxList.length; i++) {
          idxList[i] = ((HandleValue)selObjs[i]).getIndex();
        }
        if(performOperation("remove value",
                            new RemoveValueRequest(Util.encodeString(this.handle), idxList, null))) {
          for(int i=0; i<selObjs.length; i++) {
            valuesListModel.removeElement(selObjs[i]);
          }
        }
      } else {
        for(int i=0; i<selObjs.length; i++) {
          valuesListModel.removeElement(selObjs[i]);
        }
      }
    }
  }
  
  
  private void viewSelectedValue() {
    int selIdx = valuesList.getSelectedIndex();
    if(selIdx<0) return;
    HandleValue value = (HandleValue)valuesListModel.getElementAt(selIdx);
    if(value==null) return;
    
    EditValueWindow editWin = new EditValueWindow(ui, this);
    editWin.loadValueData(value.duplicate(), false);
    editWin.setMode(EditValueWindow.VIEW_MODE);
    editWin.setVisible(true);
  }


  private void showPopupMenu(MouseEvent evt) {
    int index = valuesList.locationToIndex(evt.getPoint());
    
    HandleValue value = null;
    if(index>=0) {
      valuesList.setSelectedIndex(index);
      value = (HandleValue)valuesListModel.getElementAt(index);
    }
    
    
    JPopupMenu popup = new JPopupMenu();
    if(mode==VIEW_HDL_MODE) {
      if(index>=0) popup.add(viewValueAction);
      popup.add(editHandleAction);
      popup.addSeparator();
    }
    if(mode==EDIT_HDL_MODE && index>=0) {
      popup.add(editValueAction);
      popup.addSeparator();
    }
    if(value!=null && value.hasType(Common.STD_TYPE_HSSITE)) {
      popup.add(testSiteAction);
      popup.addSeparator();
    }
    
    if(index>=0) popup.add(saveValueAction);
    popup.add(saveValuesAction);
    
    popup.pack();
    popup.show(valuesList, evt.getX(), evt.getY());
  }
  
  
  private void editValue() {
    int selIdx = valuesList.getSelectedIndex();
    if(selIdx<0 || valuesList.getSelectedIndices().length>1) return;
    HandleValue valueToEdit = (HandleValue)valuesListModel.getElementAt(selIdx);
    if(valueToEdit==null) return;
    
    HandleValue originalValue = valueToEdit;
    valueToEdit = originalValue.duplicate();
    
    EditValueWindow editWin = new EditValueWindow(ui, this);
    editWin.loadValueData(valueToEdit, false);
    AwtUtil.setWindowPosition(editWin, this);
    
    while(true) {
      editWin.setVisible(true);
      if(editWin.wasCanceled())
        break;
      
      if(editWin.saveValueData(valueToEdit)) {
        if(mode==EDIT_HDL_MODE) { // actually save the modified value
          if(performOperation("edit value",
                              new ModifyValueRequest(Util.encodeString(this.handle),
                                                     valueToEdit, null))) {
            valuesListModel.setElementAt(valueToEdit, selIdx);
            valuesList.repaint();
            break;
          }
        } else {
          valuesListModel.setElementAt(valueToEdit, selIdx);
          valuesList.repaint();
          break;
        }
      }
    }
  }

  
  private void saveValues() {
    Object[] valueObjects = valuesListModel.toArray();
    
    if(valueObjects==null || valueObjects.length<=0) {
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    
    
    FileDialog fwin = new FileDialog(this, //AwtUtil.getFrame(this),
                                     ui.getStr("choose_values_file_to_save"),
                                     FileDialog.SAVE);
    fwin.setVisible(true);
    String fileName = fwin.getFile();
    String dirName = fwin.getDirectory();
    if(fileName==null || dirName==null)
      return;
    
    FileOutputStream fout = null;
    try {
      HandleValue values[] = new HandleValue[valueObjects.length];
      for(int i=0; i<values.length; i++) values[i] = (HandleValue)valueObjects[i];
      
      byte[] buffer = Encoder.encodeGlobalValues(values);
      fout = new FileOutputStream(new File(dirName, fileName));
      fout.write(buffer);
      fout.close();
    } catch(Exception e) {
      e.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("error_saving_values")+"\n\n"+e,
                                    ui.getStr("error_title"),
                                    JOptionPane.ERROR_MESSAGE);
    } finally {
      try { fout.close(); } catch(Throwable t) {}
    }
    
  }
  
  private void saveSelectedValue() {
    int selectedIdx = valuesList.getSelectedIndex();
    if(selectedIdx<0 || valuesList.getSelectedIndices().length>1) {
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    
    HandleValue val = (HandleValue)valuesListModel.getElementAt(selectedIdx);
    if(val==null) {
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    
    FileDialog fwin = new FileDialog(this,
                                     ui.getStr("choose_value_file_to_save"),
                                     FileDialog.SAVE);
    fwin.setVisible(true);
    String fileName = fwin.getFile();
    String dirName = fwin.getDirectory();
    if(fileName==null || dirName==null)
      return;
    
    FileOutputStream fout = null;
    try {
      fout = new FileOutputStream(new File(dirName, fileName));
      fout.write(val.getData());
      fout.close();
    } catch(Exception e) {
      e.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("error_saving_value")+"\n\n"+e,
                                    ui.getStr("error_title"),
                                    JOptionPane.ERROR_MESSAGE);
    } finally {
      try { fout.close(); } catch(Throwable t) {}
    }
  }
  
  public int getNextUnusedIndex(int firstIdx) {
    int nextIdx = firstIdx-1;
    boolean duplicate = true;
    while(duplicate) {
      nextIdx++;
      duplicate = false;
      for(int i=valuesListModel.getSize()-1; i>=0; i--) {
        HandleValue val = (HandleValue)valuesListModel.getElementAt(i);
        if(val!=null && val.getIndex()==nextIdx) {
          duplicate = true;
          break;
        }
      }
    }
    return nextIdx;
  }
  
  
  
  private void addValue(HandleValue newValue) {
    EditValueWindow editWin = new EditValueWindow(ui, this);
    editWin.setTitle("Add Handle Value");
    editWin.loadValueData(newValue, true);
    AwtUtil.setWindowPosition(editWin, this);
    while(true) {
      editWin.setVisible(true);
      if(editWin.wasCanceled())
        break;

      if(!editWin.saveValueData(newValue))
        continue;
      
      if(mode==EDIT_HDL_MODE) { // actually save the modified value
        if(performOperation("add value",
                            new AddValueRequest(Util.encodeString(this.handle),
                                                newValue, null))) {
          valuesListModel.addElement(newValue);
          break;
        }
      } else {
        valuesListModel.addElement(newValue);
        break;
      }
    }
  }
  
  public void setValues(String handle, HandleValue values[], int mode) {
    this.originalValues = values;
    this.mode = mode;
    this.handle = handle;
    
    valuesListModel.removeAllElements();
    for(int i=0; values!=null && i<values.length; i++)
      valuesListModel.addElement(values[i].duplicate());

    if(mode==CREATE_HDL_MODE) {
      setTitle("Create Handle: "+handle);
      doneButton.setText(ui.getStr("create_hdl_button"));
      cancelButton.setVisible(true);
      editHdlButton.setVisible(false);
      //copyButton.setVisible(true);
      modValPanel.setVisible(true);
      modValPanel.setEnabled(true);
    } else if(mode==EDIT_HDL_MODE) {
      setTitle("Edit Handle: "+handle);
      doneButton.setText(ui.getStr("dismiss"));
      cancelButton.setVisible(false);
      editHdlButton.setVisible(false);
      //copyButton.setVisible(true);
      modValPanel.setVisible(true);
      modValPanel.setEnabled(true);
    } else if(mode==VIEW_HDL_MODE) {
      setTitle("View Handle: "+handle);
      doneButton.setText(ui.getStr("dismiss"));
      cancelButton.setVisible(false);
      //copyButton.setVisible(true);
      editHdlButton.setVisible(true);
      modValPanel.setVisible(false);
      modValPanel.setEnabled(false);
    } else {
      setTitle("????: "+handle);
      doneButton.setText("????");
      cancelButton.setVisible(true);
      //copyButton.setVisible(false);
      editHdlButton.setVisible(false);
      modValPanel.setVisible(false);
      modValPanel.setEnabled(false);
    }
  }

  private void cancelButtonPressed() {
    canceled = true;
    setVisible(false);
  }
  
  private void doneButtonPressed() {
    if(mode==CREATE_HDL_MODE) {
      HandleValue values[] = new HandleValue[valuesListModel.getSize()];
      for(int i=0; i<values.length; i++) {
        values[i] = (HandleValue)valuesListModel.getElementAt(i);
      }
      
      boolean success = 
        performOperation("create handle",
                         new CreateHandleRequest(Util.encodeString(this.handle),
                                                 values, null));
      if(success) {
          JOptionPane.showMessageDialog(this, "The handle '"+this.handle+"' "+
                                      " was created!");

          setVisible(false);
      }
    } else if(mode==EDIT_HDL_MODE) {
      // values are added/deleted/modified individually
      // so nothing needs to be done here
      setVisible(false);
    } else if(mode==VIEW_HDL_MODE) {
      canceled = false;
      setVisible(false);
    }
  }
  
  public void actionPerformed(ActionEvent evt) {
    Object src = evt.getSource();
    if(src==doneButton) {
      doneButtonPressed();
    } else if(src==cancelButton) {
      cancelButtonPressed();
    } else if(src==delValButton) {
      deleteValue();
    } else if(src==editValButton) {
      editValue();
    } else if(src==addValButton) {
      showAddValuePopup();
    } else if(src==editHdlButton ||
              editHandleAction.matchesCommand(evt)) {
      String hdl = handle;
      if(ui.getMainWindow().editHandle(hdl))
        cancelButtonPressed();
    } else if(src==copyButton) {
      String newHdlStr = JOptionPane.showInputDialog(ui.getStr("copy_hdl_prompt"));
      if(newHdlStr==null) return;
      MainWindow.ActionHandler handler =
        (ui.getMainWindow()).new ActionHandler(MainWindow.ActionHandler.CREATE_ACTION,
                                               newHdlStr);
      HandleValue newValues[] = new HandleValue[valuesListModel.getSize()];
      for(int i=0; i<newValues.length; i++)
        newValues[i] = (HandleValue)valuesListModel.getElementAt(i);
      handler.setValues(newValues);
      handler.performAction();
    } else if(saveValuesAction.matchesCommand(evt)) {
      saveValues();
    } else if(saveValueAction.matchesCommand(evt)) {
      saveSelectedValue();
    } else if(viewValueAction.matchesCommand(evt)) {
      viewSelectedValue();
    } else if(editValueAction.matchesCommand(evt)) {
      editValue();
    } else if(signHandleAction.matchesCommand(evt)) {
      addDigestAndSignatureForAllValues();
    } else if(testSiteAction.matchesCommand(evt)) {
      Object selObjs[] = valuesList.getSelectedValues();
      for(int i=0; selObjs!=null && i<selObjs.length; i++) {
        try {
          HandleValue siteValue = (HandleValue)selObjs[i];
          if(siteValue!=null) {
            SiteTester tester = new SiteTester(this, ui, siteValue);
            tester.setLocationRelativeTo(this);
            tester.setVisible(true);
          }
        } catch (Exception e) {
          JOptionPane.showMessageDialog(null, "Error parsing site information: "+e,
                                        "Error", JOptionPane.ERROR_MESSAGE);
          e.printStackTrace(System.err);
        }
      }
    }
  }

  private void showError(Throwable error) {
    JOptionPane.showMessageDialog(this, 
                                  ui.getStr("error_message")+"\n\n"+error,
                                  ui.getStr("error_title"),
                                  JOptionPane.ERROR_MESSAGE);
  }
  
  

  private void addHashOfAllValues() {
    try {
      Object objVals[] = valuesListModel.toArray();
      HandleValue values[] = new HandleValue[objVals.length];
      System.arraycopy(objVals, 0, values, 0, values.length);
      
      String digestStr = SecureResolver.createDigestOfValues(handle, values);
      addValueWithParams(getNextUnusedIndex(400), SecureResolver.METADATA_TYPE,
                         Util.encodeString(digestStr));
    } catch (Exception e) {
      showError(e);
    }
  }
  
  private void addHashOfSelectedValues() {
    try {
      Object selObjs[] = valuesList.getSelectedValues();
      if(selObjs==null || selObjs.length<=0) {
        Toolkit.getDefaultToolkit().beep();
        return;
      }
      HandleValue values[] = new HandleValue[selObjs.length];
      System.arraycopy(selObjs, 0, values, 0, values.length);
      
      String digestStr = SecureResolver.createDigestOfValues(handle, values);
      addValueWithParams(getNextUnusedIndex(400), SecureResolver.METADATA_TYPE,
                         Util.encodeString(digestStr));
    } catch (Exception e) {
      showError(e);
    }
  }
  
  private void addDigestAndSignatureForAllValues() {
    try {
      PublicKeyAuthenticationInfo sigInfo = ui.getSignatureInfo(false);
      if(sigInfo==null) return;
      
      HandleValue values[] = new HandleValue[valuesListModel.getSize()];
      valuesListModel.copyInto(values);
      
      HandleValue digestValue = new HandleValue();
      digestValue.setType(SecureResolver.METADATA_TYPE);
      digestValue.setIndex(getNextUnusedIndex(400));
      digestValue.setData(Util.encodeString(SecureResolver.createDigestOfValues(handle, values)));
      
      HandleValue sigValue = new HandleValue();
      sigValue.setType(SecureResolver.SIGNATURE_TYPE);
      sigValue.setIndex(getNextUnusedIndex(digestValue.getIndex()+1));
      String sigStr = SecureResolver.signValue(Util.decodeString(sigInfo.getUserIdHandle()),
                                               sigInfo.getUserIdIndex(),
                                               sigInfo.getPrivateKey(), handle,
                                               digestValue);
      sigValue.setData(Util.encodeString(sigStr));
      
      if(performOperation("sign values",
                          new AddValueRequest(Util.encodeString(this.handle),
                                              new HandleValue[] {digestValue, sigValue},
                                              null))) {
        valuesListModel.addElement(digestValue);
        valuesListModel.addElement(sigValue);
      }
    } catch (Exception e) {
      showError(e);
    }
  }
  
  
  private void addSignature() {
    try {
      Object selVals[] = valuesList.getSelectedValues();
      if(selVals==null || selVals.length==0 || selVals.length>1) {
        Toolkit.getDefaultToolkit().beep();
        return;
      }
      
      PublicKeyAuthenticationInfo sigInfo = ui.getSignatureInfo(false);
      if(sigInfo==null) return;
      
      String sigStr = 
        SecureResolver.signValue(Util.decodeString(sigInfo.getUserIdHandle()),
                                 sigInfo.getUserIdIndex(),
                                 sigInfo.getPrivateKey(), handle,
                                 (HandleValue)selVals[0]);
      addValueWithParams(getNextUnusedIndex(400),
                         SecureResolver.SIGNATURE_TYPE, 
                         Util.encodeString(sigStr));
    } catch (Exception e) {
      showError(e);
    }
  }
  
  private void addValueWithParams(int idx, byte valType[], byte valData[]) {
    HandleValue newValue = new HandleValue();
    newValue.setType(valType);
    newValue.setData(valData);
    newValue.setIndex(getNextUnusedIndex(idx));
    addValue(newValue);
  }
    
  private synchronized void showAddValuePopup() {
    addValPopup.show(addValButton, 0, 0-addValPopup.getPreferredSize().height);
  }
  
}
