/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.tools;
                         
import net.handle.hdllib.*;
import java.io.*;
import java.net.*;
import java.security.*;

/***************************************************************************
 * Command-line tool to send a checkpoint/backup request to a  handle server.
 ***************************************************************************/

public class BackupServer {
  private AuthenticationInfo authInfo = null;
  private InetAddress svrAddress;
  private int svrPort;
  private static byte svrProtocol;
  private static HandleResolver resolver = new HandleResolver();
  
  public static void main(String argv[])
    throws Exception
  {
    if(argv.length!=6) {
      System.err.println("Usage: java net.handle.apps.tools.BackupServer [admin-hdl] [admin-idx] [privkey] [svr-address] [svr-port] [svr-protocol]");
      System.exit(-1);
    }

    if (argv[5].equals("UDP")){
      svrProtocol = Interface.SP_HDL_UDP; //0
    }else if (argv[5].equals("TCP")){
      svrProtocol = Interface.SP_HDL_TCP; //1
    }else if (argv[5].equals("HTTP")){
      svrProtocol = Interface.SP_HDL_HTTP; //2
    }

    resolver.traceMessages = true;    
    AuthenticationInfo auth = createAuth(argv[0], argv[1], argv[2]);
    BackupServer bs = new BackupServer(auth);
    bs.doBackup(argv[3],argv[4],svrProtocol,auth);
  }

  public BackupServer(AuthenticationInfo auth){
    this.authInfo = auth;
  }

  private static AuthenticationInfo createAuth(String adminHdl, String adminIdx, String privatekey)
    throws Exception
  {
    //read private key file
      File f = new File(privatekey);
      FileInputStream fs = new FileInputStream(f);
      byte key[] = new byte[(int)f.length()];
      int n=0;
      while(n<key.length) key[n++] = (byte)fs.read();
      fs.read(key);
      
      byte seckey[] = null;

      if(Util.requiresSecretKey(key)){
        seckey = Util.getPassphrase("Please enter your passphrase:");
      }

      
      key = Util.decrypt(key, seckey);
      PrivateKey privkey = Util.getPrivateKeyFromBytes(key, 0);
      return new PublicKeyAuthenticationInfo(adminHdl.getBytes("UTF8"),
                                             Integer.parseInt(adminIdx), privkey);
  }
    
  //Send backup request to the server.
  public void doBackup(String addr, String port, byte svrProtocol,
                               AuthenticationInfo auth){
    try{
      InetAddress svrAddr = InetAddress.getByName(addr);
      int svrPort = Integer.parseInt(port);
      
      //retrieve the site information
      GenericRequest siReq = new GenericRequest(Common.BLANK_HANDLE,
                                                AbstractMessage.OC_GET_SITE_INFO,
                                                null);
      
      //restrieve response in order to check site information
      AbstractResponse response = null;
      System.err.println("\nGetting site values for: "+addr+"..");
      switch(svrProtocol){
        case 0:
          response = resolver.sendHdlUdpRequest(siReq, svrAddr, svrPort);
          break;
        case 1:
          response = resolver.sendHdlTcpRequest(siReq, svrAddr, svrPort);
          break;
        case 2:
          response = resolver.sendHttpRequest(siReq, svrAddr, svrPort);
          break;
        default:
          throw new Exception("No protocol specified");
      }
      
      //check site information
      SiteInfo siteInfo = null;
      if(response!=null && response.responseCode==AbstractMessage.RC_SUCCESS){
        siteInfo = ((GetSiteInfoResponse)response).siteInfo;
      }else{
        throw new Exception("Unable to retrieve site information from server.");
      }
      
      if(!siteInfo.isPrimary){
        throw new Exception("Given server is not a primary server.");
      }
      
      if(auth==null){
        System.err.println("Authentication value is null. Please try again.");
      }
        
      GenericRequest backupReq = new GenericRequest(Common.BLANK_HANDLE,
                                                    AbstractMessage.OC_BACKUP_SERVER,
                                                    auth);
        
      //set request protocol version
      if((siteInfo.majorProtocolVersion==5 && siteInfo.minorProtocolVersion==0) ||
         (siteInfo.majorProtocolVersion<Common.MAJOR_VERSION) ||
         (siteInfo.majorProtocolVersion==Common.MAJOR_VERSION &&
          siteInfo.minorProtocolVersion<Common.MINOR_VERSION)) {
        //older version server
        backupReq.majorProtocolVersion = siteInfo.majorProtocolVersion;
        backupReq.minorProtocolVersion = siteInfo.minorProtocolVersion;
      } else {
        //current version server
        backupReq.majorProtocolVersion = Common.MAJOR_VERSION;
        backupReq.minorProtocolVersion = Common.MINOR_VERSION;
      }
      backupReq.certify = true;
        
      String respStr = null;
      response=null;
      //for each server within the site
      for(int i=0; i<siteInfo.servers.length; i++)
        if(siteInfo.servers[i].getInetAddress().equals(svrAddr)){ 
          //for each interface within the server
          for(int j=0; j<siteInfo.servers[i].interfaces.length; j++){
            Interface interf = siteInfo.servers[i].interfaces[j];
            //send backup request if server port and protocol match
            if(interf.port==svrPort && interf.protocol==svrProtocol){
              System.err.println("\nSending backup request to server: "+siteInfo.servers[i]+" ..");
              response = resolver.sendRequestToServer(backupReq,siteInfo,siteInfo.servers[i]);
              if(response == null){
                respStr = "There was no response to the server backup request.\n";
              }
              else if(response.responseCode == AbstractMessage.RC_SUCCESS){
                System.err.println("\nThe server is performing backup.\n");
                break;
              }
              else if(response instanceof ErrorResponse)
                respStr = String.valueOf(response);
              else
                respStr = response.getClass().getName()+"( "+
                  String.valueOf(response.responseCode)+"): "+
                  AbstractMessage.getResponseCodeMessage(response.responseCode);

              System.err.println("Can not process the backup request for server: "+siteInfo.servers[i]+"\n"+response);
              System.exit(-1);
            }
          }
        }
    }catch(Exception e){
      System.err.println("Error backing up server:\n"+e.getMessage()+
                         "\nTry again please.");
      e.printStackTrace(System.err);
    }
  }
}


