/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/** 
 * Request used to resolve a handle.  Holds the handle and parameters
 * used in resolution.
 */
public class ResolutionRequest extends AbstractRequest {

  public byte requestedTypes[][] = null;
  public int requestedIndexes[] = null;
  public final boolean isAdminRequest = false;
  
  public ResolutionRequest(byte handle[], byte reqTypes[][], int reqIndexes[], 
                           AuthenticationInfo authInfo) {
    super( handle, AbstractMessage.OC_RESOLUTION, authInfo);
    this.requestedIndexes = reqIndexes;
    this.requestedTypes = reqTypes;
    this.authInfo = authInfo;
  }
  
  private String getTypesString() {
    if(requestedTypes==null || requestedTypes.length<=0)
      return "[ ]";
    StringBuffer sb = new StringBuffer("[");
    for(int i=0; i<requestedTypes.length; i++) {
      sb.append(Util.decodeString(requestedTypes[i]));
      sb.append(", ");
    }
    sb.append("]");
    return sb.toString();
  }
  
  private String getIndexesString() {
    if(requestedIndexes==null || requestedIndexes.length<=0)
      return "[ ]";
    StringBuffer sb = new StringBuffer("[");
    for(int i=0; i<requestedIndexes.length; i++) {
      sb.append(requestedIndexes[i]);
      sb.append(", ");
    }
    sb.append("]");
    return sb.toString();
  }

  public String toString() {
    return super.toString()+' '+getTypesString()+' '+getIndexesString();
  }

}
