/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.io.*;
import java.security.*;

/***************************************************************************
 * Response used to forward any new transactions to a replicated site/server.
 * This response is used for server&lt;-&gt;server (or replicator&lt;-&gt;server)
 * communication.
 ***************************************************************************/

public class RetrieveTxnResponse
  extends AbstractResponse
{
  public static final int NEED_TO_REDUMP = 1;
  public static final int SENDING_TRANSACTIONS = 2;
  
  private static final byte END_TRANSMISSION_RECORD = 0; 
  private static final byte HANDLE_RECORD = 1;
  
  // - settings used on both sides of the connection -
  public boolean keepAlive = false;

  // - settings used only on the server side -
  public RetrieveTxnRequest req = null;
  public TransactionQueueInterface txnQueue = null;
  
  // used on the server side as a source for the handle data
  private HandleStorage storage = null;
  // used on the server side only to sign the message
  private PrivateKey sourcePrivKey = null;
  // used on the server side to determine where to start sending txns
  private long lastTxnId = 0;
  // next txn id from the server
  private long nextTxnId = 0;

  /***************************************************************
   * Constructor for the server side. 
   ***************************************************************/
  public RetrieveTxnResponse(TransactionQueueInterface txnQueue, 
                             long nextTxnId,
                             RetrieveTxnRequest req,
                             boolean keepAlive,
                             HandleStorage storage,
                             PrivateKey sourcePrivKey)
    throws HandleException
  {
    super( req, AbstractMessage.RC_SUCCESS);
    this.req = req;
    this.txnQueue = txnQueue;
    this.keepAlive = keepAlive;
    this.storage = storage;
    this.streaming = true;
    this.sourcePrivKey = sourcePrivKey;
    this.lastTxnId = req.lastTxnId;
    this.nextTxnId = nextTxnId;
  }


  /***************************************************************
   * Constructor for the client side.
   ***************************************************************/
  public RetrieveTxnResponse() {
    super(AbstractMessage.OC_RETRIEVE_TXN_LOG, AbstractMessage.RC_SUCCESS);
    this.streaming = true;
  }


  /**********************************************************************
   * Process the incoming stream and call the given callback for every
   * transaction that is retrieved.  The status codes that this function
   * can return include SENDING_TRANSACTIONS, or NEED_TO_REDUMP.  If
   * NEED_TO_REDUMP is returned, all of the handles should be requested
   * from all of the servers in the primary site.
   **********************************************************************/
  public int processStreamedPart(TransactionCallback callback, PublicKey sourceKey) 
    throws HandleException
  {
    if(stream==null) {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Response stream not found");
    }


    // downgrade this threads priority so that request handler threads
    // don't starve.
    int threadPriority = Thread.currentThread().getPriority();
    /*
    try {
      Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
    } catch (Exception e) {
      System.err.println("Unable to downgrade thread priority: "+e);
    }
    */
    
    try {
      // get a signature object based on the public key
      SignedInputStream sin = new SignedInputStream(sourceKey, stream);
      DataInputStream in = new DataInputStream(sin);
      int dataVersion = in.readInt();
      int status = in.readInt();

      // verify the signature for the header information
      if(!sin.verifyBlock()) {
        throw new HandleException(HandleException.SECURITY_ALERT,
                                  "Invalid signature on replication stream");
      }
      
      // if the status is NEED_TO_REDUMP, then only an END_TRANSMISSION_RECORD will
      // be sent
      while(true) {
        byte recordType = in.readByte();
        if(recordType==END_TRANSMISSION_RECORD) {
          long sourceDate = in.readLong();

          // verify the signature for this record
          if(!sin.verifyBlock()) {
            throw new HandleException(HandleException.SECURITY_ALERT,
                                      "Invalid signature on replication stream");
          }
          callback.finishProcessing(sourceDate);
          return status;
        } else if(recordType==HANDLE_RECORD) {
          // get the record information...
          Transaction txn = new Transaction();
          txn.txnId = in.readLong();
          txn.handle = new byte[in.readInt()];
          in.read(txn.handle, 0, txn.handle.length);
          txn.action = in.readByte();
          txn.date = in.readLong();

          // get the current value of the handle record
          switch(txn.action) {
            case Transaction.ACTION_CREATE_HANDLE:
            case Transaction.ACTION_UPDATE_HANDLE:
              int numValues = in.readInt();
              txn.values = new HandleValue[numValues];
              for(int i=0; i<numValues; i++) {
                int valueSize = in.readInt();
                byte buf[] = new byte[valueSize];
                int r, n=0;
                while(n<valueSize && (r=in.read(buf,n,valueSize-n))>=0) {
                  n += r;
                }
                txn.values[i] = new HandleValue();
                Encoder.decodeHandleValue(buf,0,txn.values[i]);
              }
              break;
            case Transaction.ACTION_DELETE_HANDLE:
            case Transaction.ACTION_HOME_NA:
            case Transaction.ACTION_UNHOME_NA:
            default:
              break;
          }

          // verify the signature for this record
          if(!sin.verifyBlock()) {
            throw new HandleException(HandleException.SECURITY_ALERT,
                                      "Invalid signature on replication stream");
          }
          
          callback.processTransaction(txn);
          Thread.yield();
        } else {
          throw new HandleException(HandleException.INVALID_VALUE,
                                    "Unknown transmission record type: "+recordType);
        }
      }
    } catch (Exception e) {
      // the replication stream can be broken in the middle... no big deal
      System.err.println(">>> Exception streaming: "+e);
      e.printStackTrace(System.err);
      if(e instanceof HandleException)
        throw (HandleException)e;
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Exception receiving transactions: "+e);
    } finally {
      if(stream!=null) {
        try { stream.close(); } catch (Exception e) {}
      }
      try {
        Thread.currentThread().setPriority(threadPriority);
      } catch (Exception e) {
        System.err.println("Unable to upgrade thread priority: "+e);
      }
    }
  }



  /***********************************************************************
   * Write the response to the specified output stream.  This will
   * send all of the transactions that hash to the requestor
   * beginning with the specified transaction ID.  This method is
   * typically called on the server side.
   ***********************************************************************/
  public void streamResponse(java.io.OutputStream outStream)
    throws HandleException
  { 
    int threadPriority = Thread.currentThread().getPriority();

    // downgrade this threads priority so that request handler threads
    // don't starve.
    /*
    try {
      Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
    } catch (Exception e) {
      System.err.println("Unable to downgrade thread priority: "+e);
    }
    */
    
    // need to get all of the transactions starting with req.lastTxnId
    try {

      // use our private key to sign the response stream
      SignedOutputStream sout = new SignedOutputStream(sourcePrivKey, outStream);
      DataOutputStream out = new DataOutputStream(sout);
      
      // send a 4-byte data format version number
      out.writeInt(1);

      // write a status code that will indicate if the receiver needs
      // to re-retrieve the entire database or not.
      
      // don't require redump if there are no transactions at all
      // this allows to upgrade a secondary to a primary without dumping 
      boolean needToRedump = nextTxnId > 0 && txnQueue.getFirstDate() > this.req.lastQueryDate;

      if(needToRedump) {
        // The receiver may have missed some transactions that this
        // server doesn't have anymore.  The receiver needs to 
        // re-retrieve all handles!  (as a separate request)
        out.writeInt(NEED_TO_REDUMP);

        // sign the header info
        sout.signBlock();
      } else {
        // we will forward all of the transactions that the requestor
        // doesn't have yet.
        out.writeInt(SENDING_TRANSACTIONS);
        
        // sign the header info
        sout.signBlock();
        
        forwardTransactions(out, sout);
      }
      
      // write the ending summary record...
      out.writeByte(END_TRANSMISSION_RECORD);

      // write the date that the requestor should use
      // as the lastQueryDate for their next RetrieveTxnRequest.
      // This is needed because if there are no transactions in a while,
      // we don't want the receiver to have to redump the entire database.
      if(needToRedump) out.writeLong(this.req.lastQueryDate);
      else out.writeLong(System.currentTimeMillis());

      // sign this last record
      sout.signBlock();
      
      out.flush();

    } catch (Exception e) {
      // the replication stream can be broken in the middle... no biggie
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Exception sending transactions: ",e);
    } finally {
      try {
        Thread.currentThread().setPriority(threadPriority);
      } catch (Exception e) {
        System.err.println("Unable to upgrade thread priority: "+e);
      }
    }
  }


  /***************************************************************************
   * Forward all of the transactions that the requestor doesn't already have.
   ***************************************************************************/
  private void forwardTransactions(DataOutputStream out,
                                   SignedOutputStream sout) 
    throws Exception
  {
    
    TransactionScannerInterface scanner = txnQueue.getScanner(lastTxnId);
    try {
      
      Transaction txn = null;
      while((txn=scanner.nextTransaction())!=null) {
        /////// This currently doesn't handle wrap-around transaction IDs
        if(txn.txnId <= req.lastTxnId)
          continue;
        
        if(txn.action!=Transaction.ACTION_UNHOME_NA &&
            txn.action!=Transaction.ACTION_HOME_NA) {
          // only hash to the appropriate site, unless it is a NA home or unhome
          // transaction.  In that case, send the message to all servers!
          boolean hashes;
          switch(req.rcvrHashType) {
            case SiteInfo.HASH_TYPE_BY_PREFIX:
              hashes = (Math.abs(txn.hashOnNA%req.numServers)==req.serverNum);
              break;
            case SiteInfo.HASH_TYPE_BY_SUFFIX:
              hashes = (Math.abs(txn.hashOnId%req.numServers)==req.serverNum);
              break;
            case SiteInfo.HASH_TYPE_BY_ALL:
              hashes = (Math.abs(txn.hashOnAll%req.numServers)==req.serverNum);
              break;
            default:
              System.err.println("Warning: unknown hash type ("+req.rcvrHashType+
              ") in RetrieveTxnRequest");
              hashes = true; // if we're not sure.. just send it
          }
          
          if(!hashes) // this handle doesn't belong on the requesting server
            continue;
        }
        
        // write a transaction record
        out.writeByte(HANDLE_RECORD);
        out.writeLong(txn.txnId);
        out.writeInt(txn.handle==null ? 0 : txn.handle.length);
        if(txn.handle!=null)
          out.write(txn.handle, 0, txn.handle.length);
        out.writeByte(txn.action);
        out.writeLong(txn.date);
        
        // send the current value of the handle record
        switch(txn.action) {
          case Transaction.ACTION_CREATE_HANDLE:
          case Transaction.ACTION_UPDATE_HANDLE:
            byte hdlValue[][] = storage.getRawHandleValues(txn.handle,null,null);
            if(hdlValue==null)
              hdlValue = storage.getRawHandleValues(Util.upperCase(txn.handle),null,null);
            if(hdlValue==null) {
              out.writeInt(0);
            } else {
              out.writeInt(hdlValue.length);
              for(int i=0; i<hdlValue.length; i++) {
                if(hdlValue[i]==null) {
                  out.writeInt(0);
                } else {
                  out.writeInt(hdlValue[i].length);
                  out.write(hdlValue[i]);
                }
              }
            }
            break;
          case Transaction.ACTION_DELETE_HANDLE:
          default:
            break;
        }
        
        // sign this transaction record
        sout.signBlock();
        
        out.flush();
        Thread.yield();
      }
    } finally {
      scanner.close();

    }
  }
  
}
