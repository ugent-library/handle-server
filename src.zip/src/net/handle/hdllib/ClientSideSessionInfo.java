/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

public class ClientSideSessionInfo
    extends SessionInfo
{
    public ServerInfo server;
    private byte[] exchangeKeyHandle = null;
    private int exchangeKeyIndex = -1;
    private byte[] exchangePublicKey = null;
    
    public ClientSideSessionInfo(int sessionid, byte[] sessionkey,
                                 byte[] identityHandle, int identityindex,
                                 ServerInfo server, int majorProtocolVersion, int minorProtocolVersion)
    {
        super(sessionid, sessionkey, identityHandle, identityindex, majorProtocolVersion, minorProtocolVersion);
        this.server = server;
    }
    
    public void setExchangeKeyRef(byte keyrefHandle[], int keyrefindex) {
        this.exchangeKeyHandle =  keyrefHandle;
        this.exchangeKeyIndex = keyrefindex;
    }
    
    public void setExchangePublicKey(byte key[]){
        this.exchangePublicKey = key;
        
    }
    
    public byte[] getExchangeKeyRefHandle() { return exchangeKeyHandle;}
    public int getExchangeKeyRefindex() { return exchangeKeyIndex;}
    public byte[] getExchagePublicKey() { return exchangePublicKey;}
    
    public void takeValuesFromOption(SessionSetupInfo option){
      if (option.authInfo != null) {
        this.identityKeyHandle = option.authInfo.getUserIdHandle();
        this.identityKeyIndex = option.authInfo.getUserIdIndex();
      }
      this.exchangeKeyHandle = option.exchangeKeyHandle;
      this.exchangeKeyIndex = option.exchangeKeyIndex;
      this.exchangePublicKey = option.publicExchangeKey;
      this.timeOut = option.timeout;
      this.encryptMessage = option.encrypted;
      this.authenticateMessage = option.authenticated;
    }

  /** Returns true if the given object is an equivalent ClientSideSessionInfo
      object */
  public boolean equals(Object obj) {
    if(obj==this) return true;

    if(obj.getClass()!=this.getClass())
      return false;

    ClientSideSessionInfo info = (ClientSideSessionInfo)obj;
    
    if((server==null && info.server!=null) ||
       (server!=null && info.server==null) ||
       (server!=null && !server.equals(info)))
      return false;

    if(exchangeKeyIndex!=info.getExchangeKeyRefindex())
      return false;

    if(!Util.equals(exchangeKeyHandle, info.getExchangeKeyRefHandle()))
      return false;

    if(!Util.equals(exchangePublicKey, info.getExchagePublicKey()))
      return false;

    return super.equals(info);
  }
    
}
