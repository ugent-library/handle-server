/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;


public class Attribute {
  public byte name[];
  public byte value[];

  public Attribute() {}

  public Attribute(byte name[], byte value[])
  {
    this.name = name;
    this.value = value;
  }

  public Attribute cloneAttribute() {
    return new Attribute(Util.duplicateByteArray(name),
                         Util.duplicateByteArray(value));
  }
  
  public String toString() 
  {
    if(name!=null && value!=null)
      return new String(name) + ':' + new String(value);
    if(name!=null)
      return new String(name)+':';
    if(value!=null)
      return ":"+new String(value);
    return "<null>";
    
  }
}
