/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.util.Arrays;


public class ValueReference
{
  public byte handle[];
  public int index;

  public ValueReference() {}

  public ValueReference(byte handle[], int index) 
  {
    this.handle = handle;
    this.index = index;
  }

  public String toString() {
    return String.valueOf(index)+':'+Util.decodeString(handle);
  }

  @Override
  public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + Arrays.hashCode(Util.upperCasePrefix(handle));
      result = prime * result + index;
      return result;
  }

  @Override
  public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (getClass() != obj.getClass()) return false;
      ValueReference other = (ValueReference) obj;
      if (!Util.equalsPrefixCI(handle,other.handle)) return false;
      if (index != other.index) return false;
      return true;
  }
}
