/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/***************************************************************************
 * Request used to retrieve a list of handles from a given naming authority
 * from a server.  When sending this request, clients should be prepared to
 * authenticate as an administrator with list-handles permission in the
 * naming authority handle.  Clients should also send a ListHandlesRequest
 * to every server in a site in order to get all of the handles for a
 * particular naming authority.
 *
 * The corresponding response - ListHandlesResponse - is usually sent
 * using continuation messages, so clients should probably provide a
 * callback to the HandleResolver object when sending messages of this
 * type.
 *
 * For ListHandlesRequests the 'handle' member will contain the handle
 * for the naming authority that we want the handles for.
 ***************************************************************************/

public class ListHandlesRequest
  extends AbstractRequest
{

  public ListHandlesRequest(byte naHandle[], AuthenticationInfo authInfo) {
    super( naHandle, OC_LIST_HANDLES, authInfo);
    this.requiresConnection = true;
  }

}

