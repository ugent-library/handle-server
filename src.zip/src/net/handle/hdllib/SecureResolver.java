/**********************************************************************\
  © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.io.*;
import java.util.*;
import java.security.*;
//import javax.xml.parsers.*;
//import org.w3c.dom.*;
import net.cnri.simplexml.*;


/**
 * Class that resolves handles while verifying digital signatures on
 * those values.  This provides a higher level of security because handle values
 * can be signed by private keys that are kept offline instead of on a handle
 * server.  This also allows the verification of keys based on third party 
 * signatures from key pairs that are referenced outside of the handle system and
 * not dependent on any "root" keys associated with the handle system or any 
 * particular namespace.
 */
public class SecureResolver {
  public static final String SIGNED_INDEX_TAGNAME = "ofindex";
  public static final String SIG_ALG_TAGNAME = "alg";
  public static final String SIG_TAGNAME = "sig";
  public static final String DEFAULT_ALGORITHM = "DSA";
  public static final String VALUE_HASH_ELEMENT_NAME = "val";
  public static final String VALUE_INDEX_ATTRIBUTE = "index";
  public static final String SIG_HANDLE_ATTRIBUTE = "hdl";
  public static final String SIGNER_HANDLE_ATTRIBUTE = "signer";
  public static final String SIGNER_INDEX_ATTRIBUTE = "signerIndex";
  public static final String VALUE_MD5HASH_ATTRIBUTE = "md5";
  public static final String VALUE_SHA1HASH_ATTRIBUTE = "sha1";
  public static final int VALUE_DIGEST_OFFSET = Encoder.INT_SIZE*2;
  
  public static final byte[] METADATA_TYPE = Util.encodeString("10320/sig.digest");
  public static final byte[] SIGNATURE_TYPE = Util.encodeString("10320/sig.sig");
  private static final boolean STRICT_PARSING = true;
  
  // the resolver to use when getting handle values
  private final HandleResolver resolver;
  
  // if true, trust keys that are provided by higher level namespaces
  private boolean trustNamespaceKeys = true;
  
  // the set of keys that are trusted by this resolver
  private volatile Map<ValueReference,PublicKey> trustedKeys = new HashMap<ValueReference,PublicKey>();
  private Map<String,Integer> trustedKeysCount = new HashMap<String,Integer>();
  private final Object keysLock = new Object();
  
  // If an unsigned value is encountered during secure resolution.
  // This applies to values that have no signatures - not values
  // that have invalid signatures.
  public boolean ignoreUnsignedValues = true;
  
  // reportMissingValues tells the resolver whether to throw an exception
  // if there are values in the digest but not in the resolution results.
  public boolean reportMissingValues = false;
  
  // If we encounter a broken signature then an exception is thrown 
  // unless ignoreInvalidSignatures is true.  The default is false.
  // Even if false, values with invalid signatures will be ignored.
  public boolean ignoreInvalidSignatures = false;
  
  public boolean traceMessages = false;
  
  // construct the XML parser
  private static final XParser parser = new XParser();
  
  /**
   * Construct a SecureResolver using a new instance of the default 
   * HandleResolver to process resolution requests.
   */
  public SecureResolver() {
    this(new HandleResolver());
  }
  
  /**
   * Construct a SecureResolver using the given HandleResolver
   * to process resolution requests.
   */
  public SecureResolver(HandleResolver resolver) {
    this.resolver = resolver;
    setRootKeysAsTrusted();
  }
  
  public void printState() {
    // debugging stuff
      if(traceMessages) {
          System.err.println("trusted keys: "+trustedKeys);
          System.err.println("  trustNSKeys: "+trustNamespaceKeys);
          System.err.println("  ignoreUnsignedValues: "+ignoreUnsignedValues);
          System.err.println("  reportMissingValues: "+reportMissingValues);
          System.err.println("  ignoreInvalidSignatures: "+ignoreInvalidSignatures);
      }
  }
  
  
  public void setRootKeysAsTrusted() {
    Configuration conf = resolver.getConfiguration();
    Map<ValueReference,PublicKey> pubkeys = new HashMap<ValueReference,PublicKey>();
    for(HandleValue rootVal : conf.getGlobalValues()) {
      if(traceMessages) System.err.println("Checking if root value is a pubkey: "+rootVal);
      if(rootVal.hasType(Common.STD_TYPE_HSPUBKEY)) {
        if(traceMessages) System.err.println(">>> it is!");
        try {
          pubkeys.put(new ValueReference(Common.ROOT_HANDLE,rootVal.getIndex()),Util.getPublicKeyFromBytes(rootVal.getData(), 0));
        } catch (Exception e) {
          System.err.println("Warning: error parsing root service public key: "+e);
        }
      }
    }
    if(traceMessages) System.err.println("putting trusted root keys: "+pubkeys);
    setTrustedKeys(pubkeys);
  }
  
  /**
   * Specify the set of identities that are trusted to verify handle values.
   * The given map will include the trusted identifiers as the keys and their
   * associated public keys as the values.
   */
  public void setTrustedKeys(Map<ValueReference,PublicKey> keyIDsMap) {
    Map<ValueReference,PublicKey> newMap = new HashMap<ValueReference,PublicKey>();
    for(Map.Entry<ValueReference,PublicKey> entry : keyIDsMap.entrySet()) {
        newMap.put(new ValueReference(entry.getKey().handle.clone(),entry.getKey().index),entry.getValue());
    }
    synchronized(keysLock) {
      this.trustedKeys = newMap;
      countKeys();
    }
  }
  
  public PublicKey getTrustedKey(ValueReference valRef) {
      return trustedKeys.get(valRef);
  }

  private void countKeys() {
      trustedKeysCount = new HashMap<String,Integer>();
      for(ValueReference valRef : trustedKeys.keySet()) {
          String handleString = Util.decodeString(valRef.handle);
          Integer count = trustedKeysCount.get(handleString);
          if(count==null) count = Integer.valueOf(1);
          else count = Integer.valueOf(count.intValue()+1);
          trustedKeysCount.put(handleString,count);
      }
  }
  
  /**
   * Sets whether or not the resolver should trust keys that are provided by
   * higher level namespaces (ie contained in naming authority handles).
   * These higher level namespaces must themselves be signed by the root
   * namespace keys.  Any levels of indirection that might occur can also be
   * accompanied by another level of keys to which trust of the sub-namespace
   * can be delegated.
   */
  public void setTrustNamespaceKeys(boolean trustThem) {
    this.trustNamespaceKeys = trustThem;
  }
  
  /**
   * Resolve the given handle retrieving only the given types and indexes,
   * if any.  This will verify that any values returned are signed according
   * to the policy of this object.
   */
  public HandleValue[] resolveHandle(byte handle[], byte types[][], int indexes[]) 
    throws HandleException
  {
    return resolveHandle(new ResolutionRequest(handle, types, indexes, null));
  }
  

  /** Process the given ResolutionRequest while verifying that any values returned are
    * signed according to the policy of this object. */
  public HandleValue[] resolveHandle(ResolutionRequest req) 
    throws HandleException
  {
    // if any types or indexes were requested, add the metadata and signature
    // types to them
    byte types[][] = req.requestedTypes;
    int indexes[] = req.requestedIndexes;
    if((types!=null && types.length>0) || 
      (indexes!=null && indexes.length>0)) {
      // need to add the metadata and signature types to the query...
      if(types==null) {
        // there were no types requested, but there were indexes requested,
        // so we need to add the requested types to make sure they are included
        // in the response
        types = new byte[][] { METADATA_TYPE, SIGNATURE_TYPE };
      } else {
        byte newTypes[][] = new byte[2 + types.length][];
        newTypes[0] = METADATA_TYPE;
        newTypes[1] = SIGNATURE_TYPE;
        System.arraycopy(types, 0, newTypes, 2, types.length);
        types = newTypes;
      }
      req.requestedTypes = types;
      req.requestedIndexes = indexes;
      req.clearBuffers();
    }
    
    // perform a normal resolution...
    HandleValue values[] = null;
    AbstractResponse resp = resolver.processRequest(req);
    if(resp!=null && resp instanceof ResolutionResponse) {
      values = ((ResolutionResponse)resp).getHandleValues();
    } else {
      if(resp.responseCode==AbstractMessage.RC_HANDLE_NOT_FOUND) {
        throw new HandleException(HandleException.HANDLE_DOES_NOT_EXIST);
      } else  if(resp instanceof ErrorResponse){
        String msg = Util.decodeString(((ErrorResponse)resp).message);
        throw new HandleException(resp.responseCode, msg);
      } else {
        throw new HandleException(HandleException.INTERNAL_ERROR, "Unknown response: "+resp);
      }
    }
    
    // If there are no signatures or value metadata then we can't verify the handle
    int numSigs = 0;
    int numMetadata = 0;
    for(int i=0; values!=null && i<values.length; i++) {
      if(values[i]==null) continue;
      if(values[i].hasType(SIGNATURE_TYPE))
        numSigs++;
      if(values[i].hasType(METADATA_TYPE))
        numMetadata++;
    }
    if(numSigs==0 && numMetadata==0) {
      if(ignoreUnsignedValues) return new HandleValue[0];
      else throw new HandleException(HandleException.INVALID_VALUE, 
                                "No signatures found in "+Util.decodeString(req.handle));
    }
    
    try {
      Map<ValueReference,PublicKey> keys = this.trustedKeys;
      if(this.trustNamespaceKeys) {
        // if we trust any namespace keys, then we need to resolve the namespace keys
        Map<ValueReference,PublicKey> localKeys = new HashMap<ValueReference,PublicKey>();
        localKeys.putAll(this.trustedKeys);
        addKeysFromHandle(resolver.getNAHandle(req.handle), localKeys);
        keys = localKeys;
      }
      
      // we now have the trusted keys in the localKeys map and can verify the handle contents
      // based on those keys
      return secureHandleValues(req.handle, values, keys);
    } catch (Exception e) {
      if(e instanceof HandleException) throw (HandleException)e;
      else throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                     "Error verifying signature: "+e);
    }
  }
  
  

  public HandleValue[] secureHandleValues(byte handle[], HandleValue[] values) throws Exception {
    return secureHandleValues(handle, values, this.trustedKeys);
  }
  
  public HandleValue[] secureHandleValues(byte handle[], HandleValue[] aValues, Map<ValueReference,PublicKey> keys) throws Exception {
    HandleValue[] values = new HandleValue[aValues.length];
    System.arraycopy(aValues,0,values,0,aValues.length);
    ArrayList<HDLSignature> sigList = new ArrayList<HDLSignature>();
    
    for(int i=0; i<values.length; i++) {
      if(values[i]==null) continue;
      if(values[i].hasType(SIGNATURE_TYPE)) {
        try {
          List<HDLSignature> sigs = signaturesFromValue(Util.decodeString(handle), values[i], values);
          for(HDLSignature sig : sigs) {
              if(keys.containsKey(sig.getSigner())) {
                  sigList.add(sig);
              }
          }
        } catch (Exception e) {
          if(traceMessages || resolver.traceMessages) {
            System.err.println("Error processing signature: "+values[i]);
            e.printStackTrace(System.err);
          }
        }
      }
    }
    
    // throw out the invalid or untrusted signatures
    for(int i=sigList.size()-1; i>=0; i--) {
      HDLSignature sig = sigList.get(i);
      PublicKey signerKey = keys.get(sig.getSigner());
      if(signerKey==null) {
        if(traceMessages || resolver.traceMessages) { 
          System.err.println("ignoring signature: "+sig.getSigner());
        }
        sigList.remove(i);
        continue;
      }
      if(!sig.verifySignature(signerKey)) {
        // we have keys for this signer, but the signature was not valid
        if(traceMessages || resolver.traceMessages) {
          System.err.println("verify-signature failed: "+sig);
        }
        if(ignoreInvalidSignatures) {
          sigList.remove(i);
          continue;
        } else {
          throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                    "Invalid signature encountered: "+sig);
        }
      }
    }
    
    // Now go through the values and remove all but the ones that are signed.
    // If the policy is to throw an error if any unsigned values are found
    // (except for the signatures themselves) then we throw an error
    for(int i=0; i<values.length; i++) {
      HandleValue value = values[i];
      if(value==null) continue;
      boolean noSigNeeded = false;
      if(!valueNeedsSignature(value)) {
        // values[i] = null;
        // continue;
        noSigNeeded = true;
      }
      
      // see if this value matches a signature...
      boolean isSigned = false;
      for(int sigIdx=sigList.size()-1; sigIdx>=0; sigIdx--) {
        // if this value matches a signature
        HDLSignature sig = sigList.get(sigIdx);
        if(sig.verifyValue(value)) {
          // the signature was valid, we don't need to check any more signatures
          isSigned = true;
          break;
        }
      }
      
      // if the value was signed by one of the signatures then it is good.
      if(isSigned) {
        continue;
      }
      
      // if not, then we act according to our policy (throw out the value or
      // just remove it from the results).
      if(ignoreUnsignedValues || noSigNeeded) {
        values[i] = null;
      } else {
        throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                  "Encountered unsigned value: "+value);
      }
    }
    
    // if there are any missing values, remove them and return a compressed array
    int numVals = 0;
    for(int i=values.length-1; i>=0; i--) { 
      if(values[i]!=null) numVals++;
    }
    HandleValue returnVals[] = new HandleValue[numVals];
    for(int i=values.length-1; i>=0; i--) {
      if(values[i]!=null)
        returnVals[--numVals] = values[i];
    }
    return returnVals;
  }
  
  private static class LazyDigestInitializer { 
      private static MessageDigest md5 = null;
      private static MessageDigest sha1 = null;
      static {
          try {
              md5 = MessageDigest.getInstance("MD5");
          }
          catch(NoSuchAlgorithmException e) {
              e.printStackTrace();
          }
          try {
              sha1 = MessageDigest.getInstance("SHA1");
          }
          catch(NoSuchAlgorithmException e) {
              e.printStackTrace();
          }
      }
  }
  
  private static MessageDigest getMD5() 
  throws NoSuchAlgorithmException
  {
      return LazyDigestInitializer.md5;
  }
  
  private static MessageDigest getSHA1() 
  throws NoSuchAlgorithmException
  {
      return LazyDigestInitializer.sha1;
  }
 

  public List<HDLSignature> signaturesFromValue(String handle, HandleValue sigValue, HandleValue allValues[]) 
    throws Exception
  {
    if(handle==null) throw new NullPointerException();
    if(sigValue==null) throw new NullPointerException();
    if(allValues==null) throw new NullPointerException();
    
    List<HDLSignature> res = new ArrayList<SecureResolver.HDLSignature>();
    
    // parse the handle metadata and signature
    XTag sigXML = 
      parser.parse(new InputStreamReader(new ByteArrayInputStream(sigValue.getData()),"UTF8"),
                   STRICT_PARSING);
    if(!sigXML.getStrAttribute(SIG_HANDLE_ATTRIBUTE, "").equalsIgnoreCase(handle)) {
      throw new Exception("Wrong handle found in signature: "+sigXML);
    }
    
    String defaultSigner = sigXML.getStrAttribute(SIGNER_HANDLE_ATTRIBUTE, null);
    int defaultIndex = sigXML.getIntAttribute(SIGNER_INDEX_ATTRIBUTE,300);
    
    // find the metadata that corresponds to this signature...
    int metadataIdx = sigXML.getIntAttribute(SIGNED_INDEX_TAGNAME, -1);
    HandleValue metadataValue = null;
    for(int i=0; allValues!=null && i<allValues.length; i++) {
      if(allValues[i]==null) continue;
      if(allValues[i].getIndex()==metadataIdx) {
        metadataValue = allValues[i];
        break;
      }
    }
    if(metadataValue==null) {
      throw new Exception("No metadata found for signature: "+sigValue);
    }
    XTag metadataXML = 
      parser.parse(new InputStreamReader(new ByteArrayInputStream(metadataValue.getData()),"UTF8"),
                   STRICT_PARSING);
    if(!metadataXML.getStrAttribute(SIG_HANDLE_ATTRIBUTE, "").equalsIgnoreCase(handle)) {
      throw new Exception("Wrong handle found in digest: "+metadataXML);
    }
    
    int count = sigXML.getSubTagCount();
    for(int i = 0; i < count; i++) {
        XTag sigtag = sigXML.getSubTag(i);
        if(!SIG_TAGNAME.equals(sigtag.getName())) continue;

        String signer = sigtag.getStrAttribute(SIGNER_HANDLE_ATTRIBUTE, defaultSigner);
        if(signer==null) throw new Exception("No signer found in signature: "+sigtag);
        int index = sigtag.getIntAttribute(SIGNER_INDEX_ATTRIBUTE,defaultIndex);
        String signatureAlg = sigtag.getStrAttribute(SIG_ALG_TAGNAME, DEFAULT_ALGORITHM);
        String sigStr = sigtag.getStrValue();
        if(sigStr==null) throw new Exception("No signature bytes (sigbytes) found in "+sigtag);
        byte signature[] = Util.encodeHexString(sigStr);
        
        res.add(new HDLSignature(handle,metadataValue,metadataXML,new ValueReference(Util.encodeString(signer),index),signatureAlg,signature));
    }
    
    return res;
  }

  public List<HDLSignature> signaturesFromValues(String handle, HandleValue allValues[]) throws Exception {
      List<HDLSignature> res = new ArrayList<SecureResolver.HDLSignature>();
      for(HandleValue value : allValues) {
          if(value!=null && value.hasType(SIGNATURE_TYPE)) {
              res.addAll(signaturesFromValue(handle,value,allValues));
          }
      }
      return res;
  }

  
  public class HDLSignature {
    private final String handle;
    private final HandleValue metadataValue;
    private final XTag metadataXML;
    private final ValueReference signer;
    private final String signatureAlg;
    private final byte[] signature;
    
    public HDLSignature(String handle, HandleValue metadataValue, XTag metadataXML, ValueReference signer, String signatureAlg, byte[] signature) {
        this.handle = handle;
        this.metadataValue = metadataValue;
        this.metadataXML = metadataXML;
        this.signer = signer;
        this.signatureAlg = signatureAlg;
        this.signature = signature;
    }

    public String toString() {
      return "HDLSignature: signer="+signer+"; md="+metadataValue.getIndex();
    }
    
    /** Return the identifier for signing entity (unverified until verifySignature()
      * is called). */
    public final ValueReference getSigner() {
      return this.signer;
    }
    
    /** Returns true if the metadata signature has been signed by the
      * given key.  Note that this alone does not ensure that the handle 
      * values are valid - you must also call verifyValue() on each handle 
      * value to determine if the signature for that specific value is valid. 
      * This allows for the possibility of partial signatures and unsigned values
      * in a handle. */
    public final boolean verifySignature(PublicKey pubkey) 
      throws Exception
    {
      byte dataToBeSigned[] = new byte[Encoder.calcStorageSize(metadataValue)];
      int dataLen = Encoder.encodeHandleValue(dataToBeSigned, 0, metadataValue);
      String alg = signatureAlg;
      if(alg==null) alg = Util.getSigIdFromHashAlgId(Common.HASH_ALG_SHA1,pubkey.getAlgorithm());
      Signature sig = Signature.getInstance(alg);
      sig.initVerify(pubkey);
      sig.update(dataToBeSigned, VALUE_DIGEST_OFFSET, dataLen - VALUE_DIGEST_OFFSET);
      if(traceMessages) System.err.println("checking key: "+pubkey);
      if(sig.verify(signature)) {
          if(traceMessages) System.err.println("  success!");
          return true;
      } else {
          if(traceMessages) System.err.println("  nope :(");
      }
      return false;
    }
    
    
    /** Return true if the given value was properly signed.  Note that this does
      * not ensure that the signer is trusted.  That should be done by the calling
      * code using the getSigner() */
    public final boolean verifyValue(HandleValue value) 
      throws Exception
    {
      if(value==null) throw new NullPointerException();
      if(value.getIndex()<=0) 
        throw new Exception("Was asked to verify value with non-positive index: "+value);
      
      // if the value is the metadata value itself then it is valid since it
      // is verified with a call to verifySignature()
      if(value==metadataValue) {
        return true; // the digest itself is always 'valid'
      }
      
      if(metadataXML==null) throw new Exception("No metadata available");
      
      boolean haveSigForValue = false;
      for(int i=0; i<metadataXML.getSubTagCount(); i++) {
        XTag subtag = metadataXML.getSubTag(i);
        if(!subtag.getName().equals(VALUE_HASH_ELEMENT_NAME)) continue;
        if(subtag.getIntAttribute(VALUE_INDEX_ATTRIBUTE, -1)!=value.getIndex()) continue;
        // compute and compare the hash of the value
        byte encVal[] = new byte[Encoder.calcStorageSize(value)];
        Encoder.encodeHandleValue(encVal, 0, value);
        int hashMatches = 0;
        String md5Val = subtag.getAttribute(VALUE_MD5HASH_ATTRIBUTE, null);
        if(md5Val!=null) {
          MessageDigest md5 = getMD5();
          synchronized (md5) {
            md5.reset();
            md5.update(encVal, VALUE_DIGEST_OFFSET, encVal.length-VALUE_DIGEST_OFFSET);
            byte digest[] = md5.digest();
            if(!Util.equals(digest, Util.encodeHexString(md5Val))) {
              // the md5 hash doesn't match
              return false;
            }
          }
          hashMatches++;
        }
        String sha1Val = subtag.getAttribute(VALUE_SHA1HASH_ATTRIBUTE, null);
        if(sha1Val!=null) {
          MessageDigest sha1 = getSHA1();
          synchronized (sha1) {
            sha1.reset();
            sha1.update(encVal, VALUE_DIGEST_OFFSET, encVal.length-VALUE_DIGEST_OFFSET);
            if(!Util.equals(sha1.digest(), Util.encodeHexString(sha1Val))) {
              // the sha1 hash doesn't match
              return false;
            }
          }
          hashMatches++;
        }
        if(hashMatches>0) return true;
      }
      
      return false;
    }
  }
  
  
  /** Generate an XML string containing the metadata (including digests) for the given set
    * of handle values */
  public static final String createDigestOfValues(String handle, HandleValue values[]) 
  throws HandleException, NoSuchAlgorithmException
  {
    XTag digests = new XTag("digests");
    digests.setAttribute(SIG_HANDLE_ATTRIBUTE, handle);
    for(int i=0; values!=null && i<values.length; i++) {
      HandleValue value = values[i];
      if(value==null) continue;
      byte buf[] = value.cachedBuf;
      int offset = value.cachedBufOffset;
      int length = value.cachedBufLength;
      if(buf==null) {
        buf = new byte[Encoder.calcStorageSize(value)];
        offset = 0;
        length = Encoder.encodeHandleValue(buf, 0, value);
      }
      
      XTag valueDigest = new XTag(VALUE_HASH_ELEMENT_NAME);
      valueDigest.setAttribute(VALUE_INDEX_ATTRIBUTE, value.getIndex());
      MessageDigest md5 = getMD5();
      synchronized (md5) {
        md5.update(buf, offset + VALUE_DIGEST_OFFSET, length - VALUE_DIGEST_OFFSET);
        valueDigest.setAttribute(VALUE_MD5HASH_ATTRIBUTE, Util.decodeHexString(md5.digest(), false));
      }
      MessageDigest sha1 = getSHA1();
      synchronized (sha1) {
        sha1.update(buf, offset + VALUE_DIGEST_OFFSET, length - VALUE_DIGEST_OFFSET);
        valueDigest.setAttribute(VALUE_SHA1HASH_ATTRIBUTE, Util.decodeHexString(sha1.digest(), false));
      }
      digests.addSubTag(valueDigest);
    }
    return digests.toString();
  }
  
  
  
  /** Sign some handle value data (usually a table of handle value digests) with the given 
   *  signer's public key. */
  public static final String signValue(String signerHDL, int signerIndex, PrivateKey privKey, String signedHDL, 
                                       HandleValue valueToBeSigned)
  throws HandleException, NoSuchAlgorithmException, SignatureException, InvalidKeyException
  {
    XTag sigXML = new XTag("signature");
    sigXML.setAttribute(SIG_HANDLE_ATTRIBUTE, signedHDL);
    sigXML.setAttribute(SIGNED_INDEX_TAGNAME, valueToBeSigned.getIndex());
    XTag sigtag = new XTag(SIG_TAGNAME);
    String alg = Util.getSigIdFromHashAlgId(Common.HASH_ALG_SHA1,privKey.getAlgorithm());
    sigtag.setAttribute(SIG_ALG_TAGNAME, alg);
    sigtag.setAttribute(SIGNER_HANDLE_ATTRIBUTE, signerHDL);
    sigtag.setAttribute(SIGNER_INDEX_ATTRIBUTE, signerIndex);
    Signature sig = Signature.getInstance(alg);
    sig.initSign(privKey);
    
    byte dataToBeSigned[] = new byte[Encoder.calcStorageSize(valueToBeSigned)];
    int dataLen = Encoder.encodeHandleValue(dataToBeSigned, 0, valueToBeSigned);
    sig.update(dataToBeSigned, VALUE_DIGEST_OFFSET, dataLen - VALUE_DIGEST_OFFSET);
    sigtag.setValue(Util.decodeHexString(sig.sign(), false));
    sigXML.addSubTag(sigtag);
    return sigXML.toString();
  }
  
  
  /**
   * Adds keys from the given handle if the handle does not already have any keys for it.
   * Any handles that are resolved are also verified before adding them to the trusted
   * key map.
   */
  private void addKeysFromHandle(byte[] trustedHandle, Map<ValueReference,PublicKey> trustedKeys)
    throws Exception
  {
    String handleStr = Util.decodeString(trustedHandle);
    HandleValue values[] = null;
    if(Util.equalsCI(trustedHandle,Common.ROOT_HANDLE)) {
      // the root values....
      values = resolver.getConfiguration().getGlobalValues();
    } else {
      values = resolveHandle(trustedHandle, new byte[][]{ Common.STD_TYPE_HSPUBKEY }, null);
    }
    
    for(int i=0; values!=null && i<values.length; i++) {
      if(values[i].hasType(Common.STD_TYPE_HSPUBKEY)) {
        try {
          trustedKeys.put(new ValueReference(trustedHandle,values[i].getIndex()), Util.getPublicKeyFromBytes(values[i].getData(),0));
        } catch (Exception e) {
          System.err.println("Error loading namespace key: "+e);
        }
      }
    }
  }
  
  
  
  public static void main(String argv[])
  throws Exception
  {
    if(argv.length<=0) {
      System.err.println("usage: java net.handle.hdllib.SecureResolver <handle1> [<handle2>...]");
    }
    SecureResolver r = new SecureResolver();
    for(String hdl : argv) {
      System.out.println("Resolving "+hdl);
      HandleValue values[] = r.resolveHandle(Util.encodeString(hdl), null, null);
      for(HandleValue val : values) {
        System.out.println("  "+val);
      }
    }
    
  }
  
  /**
   * Verify the given handle values and return only those which have been signed 
   * by a majority of the public keys in the given key map.  The key map should 
   * contain the set of public keys from the previously trusted handle values.
   * This should be used to verify the validity of 
   */
  public HandleValue[] verifyValuesByMajority(byte handle[], HandleValue aValues[])
    throws Exception
  {
    Map<ValueReference,PublicKey> keys;
    Map<String,Integer> keysCount;
    synchronized(keysLock) {
        keys = trustedKeys;
        keysCount = trustedKeysCount;
    }
    
    HandleValue[] values = new HandleValue[aValues.length];
    System.arraycopy(aValues, 0, values, 0, aValues.length);
    
    ArrayList<HDLSignature> sigList = new ArrayList<HDLSignature>(values.length);
    
    for(HandleValue value : values) {
      if(value==null) continue;
      if(value.hasType(SIGNATURE_TYPE)) {
        sigList.addAll(signaturesFromValue(Util.decodeString(handle), value, values));
      }
    }
    
    // determine how many signatures are valid
    Map<String,Integer> howManySignatures = new HashMap<String,Integer>();
    for(int i = sigList.size() - 1; i >= 0; i--) {
      HDLSignature sig = sigList.get(i);
      PublicKey signerKey = keys.get(sig.getSigner());
      if(signerKey==null) {
        if(traceMessages || resolver.traceMessages) System.err.println("ignoring signature from unknown signer: "+sig);
        sigList.remove(i);
        continue;
      }
      if(!sig.verifySignature(signerKey)) {
        sigList.remove(i);
      }
      else {
          String handleString = Util.decodeString(sig.getSigner().handle);
          Integer count = howManySignatures.get(handleString);
          if(count==null) count = Integer.valueOf(1);
          else count = Integer.valueOf(count.intValue()+1);
          howManySignatures.put(handleString,count);
      }
    }

    for(HDLSignature sig : sigList) {
        String handleString = Util.decodeString(sig.getSigner().handle);
        if(howManySignatures.get(handleString).intValue() < keysCount.get(handleString).intValue()/2) {
            sigList.remove(sig);
        }
    }
    
    if(sigList.size()<=0) {
      throw new HandleException(HandleException.ENCRYPTION_ERROR, 
                                "Unable to find signature of '"+Util.decodeString(handle)+
                                "' from majority of keys");
    }
    
    // Now go through the values and remove all but the ones that are signed.
    // If the policy is to throw an error if any unsigned values are found
    // (except for the signatures themselves) then we throw an error
    ArrayList<HandleValue> secureValues = new ArrayList<HandleValue>();
    for(HandleValue value : values) {
      if(value==null) continue;
      if(!valueNeedsSignature(value)) {
        secureValues.add(value);
        continue;
      }
      
      // see if this value matches a signature...
      boolean isSigned = false;
      for(HDLSignature sig : sigList) {
        // if this value matches a signature
        if(sig.verifyValue(value)) {
          // the signature was valid, we don't need to check any more signatures
          //secureValues.add(value);
          isSigned = true;
          break;
        }
      }
      
      // if the value was not in one of the majority-signed signatures then it is good
      if(isSigned) {
        secureValues.add(value);
      } else {
        // if not, throw an error
        throw new HandleException(HandleException.ENCRYPTION_ERROR, 
                                  "Unable to find signature for value: "+value);
      }
    }
    
    return secureValues.toArray(new HandleValue[secureValues.size()]);
  }
  
  public static boolean valueNeedsSignature(HandleValue value) {
      if(value.hasType(SIGNATURE_TYPE) || value.hasType(METADATA_TYPE) || !value.publicRead) return false;
      else return true;

  }
}
