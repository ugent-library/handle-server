/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.security.*;
import java.util.Random;

/***********************************************************************
 * Object used to represent a challenge sent to a user asking for
 * proof of their identity.  The challenge includes a nonce (a random
 * unpredictable set of bytes) as well as a digest of the request that
 * is being challenged (so that the user can verify that they are only
 * authorizing a specific operation).
 ***********************************************************************/
public class ChallengeResponse
  extends AbstractResponse
{
  private static Random random = null;
  private static final String randomLock = "randomLock";
  
  public byte nonce[];
  
  /**********************************************************************
   * Construct a challenge to the specified request.  This
   * constructor is used on the client side, when decoding messages.
   **********************************************************************/
  public ChallengeResponse(int opCode, byte nonce[]) {
    super(opCode, AbstractMessage.RC_AUTHENTICATION_NEEDED);
    this.nonce = nonce;
  }

  /**********************************************************************
   * Construct a challenge to the specified request.  This
   * constructor is used on the server side.
   **********************************************************************/
  public ChallengeResponse(AbstractRequest req)
    throws HandleException
  {
    super(req, AbstractMessage.RC_AUTHENTICATION_NEEDED);

    // if the request didn't ask for a request digest, we'll compute one anyway.
    // because they are essential for security of the challenge/response exchange.
    // request digests are normally computed in the AbstractResponse constructor.
    if(requestDigest==null) {
      takeDigestOfRequest(req);
    }
    
    this.returnRequestDigest = true; 
    generateChallenge(req);
  }


  public static final void initializeRandom() {
    initializeRandom(null);
  }
  public static final void initializeRandom(byte seed[]) {
    if(random==null) {
      synchronized(randomLock) {
        if(random==null) {
          if (seed == null) {
              random = new SecureRandom();
              random.setSeed(System.nanoTime());
          }
          else random = new SecureRandom(seed);
          random.nextInt();
        }
      }
    }
  }

  private static Random getRandom() {
    if(random==null) 
      initializeRandom();
    return random;
  }

  /**********************************************************************
   * Generate a nonce, and a digest as a challenge to the specified
   * request.  This challenge should be very non-guessable.
   **********************************************************************/
  private void generateChallenge(AbstractRequest req)
    throws HandleException
  {
    // generate a nonce to make this a unique non-repeatable challenge
    nonce = new byte[Common.CHALLENGE_NONCE_SIZE];
    getRandom().nextBytes(nonce);
  }
  
}
