/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/**
 * Same format as ResolutionResponse, but allows values to be empty.  Used for RC_NA_DELEGATE and RC_SERVICE_REFERRAL.
 */
public class ServiceReferralResponse extends AbstractResponse {

  public byte handle[];
  public byte values[][];
  
  public ServiceReferralResponse(int responseCode, byte handle[], byte values[][]) 
  {
    super(OC_RESOLUTION, responseCode);
    this.handle = handle;
    this.values = values;
  }

  public ServiceReferralResponse(AbstractRequest req, int responseCode, byte handle[],
                            byte clumps[][])
    throws HandleException
  {
    super(req, responseCode);
    this.handle = handle;
    this.values = clumps;
  }
  

  public HandleValue[] getHandleValues() 
    throws HandleException
  {
    if(values==null) return null;
    HandleValue retValues[] = new HandleValue[values.length];
    for(int i=0; i<retValues.length; i++) {
      retValues[i] = new HandleValue();
      Encoder.decodeHandleValue(values[i],0,retValues[i]);
    }
    return retValues;
  }
  
  public String toString() {
    StringBuffer sb = new StringBuffer(super.toString());
    sb.append(' ');
    if(handle==null)
      sb.append(String.valueOf(handle));
    else
      sb.append(new String(handle));
    sb.append("\n");
    
    if(values!=null) {
      try {
	HandleValue vals[] = getHandleValues();
	for(int i=0; i<vals.length; i++) {
	  sb.append("   ");
          sb.append(String.valueOf(vals[i]));
	  sb.append('\n');
	}
      } catch (HandleException e) {}
    }
    return sb.toString();
  }

}
