/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

/**
 *
 * Table that never exceeds a maximum number of elements.  Uses a Least
 * Recently Used(LRU) replacement strategy.
 *
 * Adding, removing, getting, and contains key all have an additional
 * overhead of O(lg(n))
 * 
 * 
 **/

package net.handle.util;

import java.util.*;

public class LRUCacheTable<K,V> {
  private long counter = 0;
  private int maxsize;
  private TreeSet<Entry> lru;
  private HashMap<K,Entry> map;
  
  class Entry {
    long atime;
    K key;
    V val;
    public String toString() { return "key="+key+"; val="+val+"; time="+atime; }
    public boolean equals(Object o2) {
      return this==o2;
    }
  }

  public LRUCacheTable(int maxsize){
    this.maxsize = maxsize;
    map = new HashMap<K,Entry>(maxsize);
    lru = new TreeSet<Entry>(new Comparator<Entry>(){
        public int compare(Entry o1, Entry o2){
          return (int)(o1.atime - o2.atime);
        }
    });
  }
  
  public int size() {
    return map.size();
  }
  
  public int getMaxSize(){
    return maxsize;
  }

  public void setMaxSize(int newsize) {
    maxsize = newsize;
  }
  
  public synchronized Object put(K key, V val){
    Entry oldentry = map.get(key);
    Entry newentry = new Entry();
    newentry.key = key;
    newentry.val = val;
    newentry.atime = counter++;
    if (oldentry != null) lru.remove(oldentry);
    map.put(key, newentry);
    lru.add(newentry);
    
    evict();
    return oldentry==null ? null : oldentry.val;
  }

  public synchronized void remove(K key) {
      Entry oldentry = map.get(key);
      if (oldentry != null) lru.remove(oldentry);
      map.remove(key);
  }
  
  public synchronized void clear() {
    map.clear();
    lru.clear();
  }
  
  private synchronized void evict() {
    if (lru.size() > maxsize ) { 
      // if we've hit the limit, delete 25% of the items in the table
      int toEvict = Math.round(maxsize/4f);
      // System.err.println("evicting "+toEvict+" of "+lru.size()+" entries from lrutable");
      while(toEvict > 0) {
        Entry e = lru.first();
        map.remove(e.key);
        lru.remove(e);
        toEvict--;
      }
    }
  }
  
  /**
   * Returns key of least recently used object
   **/
  public synchronized K getLruKey(){
    Entry e = lru.first();
    return e.key;
  }
  
  public synchronized V get(K key){
    Entry entry = map.get(key);
    if (entry == null) return null;
    lru.remove(entry);
    entry.atime = counter++;
    lru.add(entry);
    return entry.val;
  }

  public static void main(String argv[]) {
    LRUCacheTable map = new LRUCacheTable(3);
    map.put("a", "a");
    map.put("b", "a");
    map.put("c", "a");
    map.put("d", "a");
    System.exit(0);
  }

}
