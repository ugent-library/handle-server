/**********************************************************************\
 © COPYRIGHT 2013 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

import java.util.*;

/***********************************************************************
 * Class that works just like a java.util.Hashtable except the keys are
 * always integers (eliminating the need to creating Integer objects just
 * to act as keys to the table).
 ***********************************************************************/
public class IntTable {
  private transient TableEntry table[];
  private transient int count;
  private int threshold;
  private float loadFactor;
  
  public IntTable(int initialCapacity, float loadFactor) {
    if ((initialCapacity <= 0) || (loadFactor <= 0.0)) {
      throw new IllegalArgumentException();
    }
    this.loadFactor = loadFactor;
    table = new TableEntry[initialCapacity];
    threshold = (int)(initialCapacity * loadFactor);
  }

  public IntTable(int initialCapacity) {
    this(initialCapacity, 0.75f);
  }

  public IntTable() {
    this(101, 0.75f);
  }

  public int size() { return count; }

  public boolean isEmpty() { return count == 0; }

  public synchronized IntTableEnumerator keys() {
    return new IntTableEnumerator();
  }

  public synchronized boolean contains(Object value) {
    if (value == null) {
      throw new NullPointerException();
    }
    TableEntry tab[] = table;
    for (int i = tab.length ; i-- > 0 ;) {
      for (TableEntry e = tab[i] ; e != null ; e = e.next) {
	if (e.value.equals(value)) {
	  return true;
	}
      }
    }
    return false;
  }

  public synchronized boolean containsKey(int key) {
    TableEntry tab[] = table;
    int hash = (int)((key & 0xffffffff) | ((key&0xffffffff00000000L)>>32));
    int index = (hash & 0x7FFFFFFF) % tab.length;
    for (TableEntry e = tab[index] ; e != null ; e = e.next) {
      if ((e.key == key) && (e.hash==hash)) {
	return true;
      }
    }
    return false;
  }
  
  public synchronized Object get(int key) {
    TableEntry tab[] = table;
    int hash = (int)((key & 0xffffffff) | ((key&0xffffffff00000000L)>>32));
    int index = (hash & 0x7FFFFFFF) % tab.length;
    for (TableEntry e = tab[index] ; e != null ; e = e.next) {
      if ((e.key == key) && (e.hash== hash)) {
	return e.value;
      }
    }
    return null;
  }

  protected void rehash() {
    int oldCapacity = table.length;
    TableEntry oldTable[] = table;
    
    int newCapacity = oldCapacity * 2 + 1;
    TableEntry newTable[] = new TableEntry[newCapacity];
    
    threshold = (int)(newCapacity * loadFactor);
    table = newTable;
    
    for (int i = oldCapacity ; i-- > 0 ;) {
      for (TableEntry old = oldTable[i] ; old != null ; ) {
	TableEntry e = old;
	old = old.next;
	
	int index = (e.hash & 0x7FFFFFFF) % newCapacity;
	e.next = newTable[index];
	newTable[index] = e;
      }
    }
  }
  
  public synchronized Object put(int key, Object value) {
    // Make sure the value is not null
    if (value == null) {
      throw new NullPointerException();
    }
    
    // Makes sure the key is not already in the hashtable.
    TableEntry tab[] = table;
    int hash = (int)((key & 0xffffffff) | ((key&0xffffffff00000000L)>>32));
    int index = (hash & 0x7FFFFFFF) % tab.length;
    for (TableEntry e = tab[index] ; e != null ; e = e.next) {
        if ((e.key==key) && (e.hash == hash)) {
            Object res = e.value;
            e.value = value;
            return res;
        }
    }
    
    if (count >= threshold) {
      // Rehash the table if the threshold is exceeded
      rehash();
      return put(key,value);
    } 
    
    // Creates the new entry.
    TableEntry e = new TableEntry();
    e.hash = hash;
    e.key = key;
    e.value = value;
    e.next = tab[index];
    tab[index] = e;
    count++;
    return null;
  }
  
  public synchronized void remove(int key) {
    TableEntry tab[] = table;	
    int hash = (int)((key & 0xffffffff) | ((key&0xffffffff00000000L)>>32));
    int index = (hash & 0x7FFFFFFF) % tab.length;
    for (TableEntry e = tab[index], prev = null ; e != null ; prev = e, e = e.next) {
      if ((e.key == key) && (e.hash == hash)) {
	if (prev != null) {
	  prev.next = e.next;
	} else {
	  tab[index] = e.next;
	}
	count--;
	return;
      }
    }
    return;
  }

  public synchronized void clear() {
    TableEntry tab[] = table;
    for (int index = tab.length; --index >= 0; )
      tab[index] = null;
    count = 0;
  }


  public class IntTableEnumerator
  {
    private int index = table.length;
    private TableEntry entry = null;

    public boolean hasMoreElements() {
      if (entry != null) {
        return true;
      }
      while (--index >= 0) {
        if ((entry = table[index]) != null) {
          return true;
        }
      }
      return false;
    }
  
    public int nextKey() {
      if (entry == null) {
        while ((index-- > 0) && ((entry = table[index]) == null)) {}
      }
      if (entry != null) {
        TableEntry e = entry;
        entry = e.next;
        return e.key;
      }
      throw new NoSuchElementException("IntTableEnumerator");
    }
    
  }


  private class TableEntry {
    int hash;
    int key;
    Object value;
    TableEntry next;
    
    protected Object clone() 
    {
      TableEntry entry = new TableEntry();
      entry.hash = hash;
      entry.key = key;
      entry.value = value;
      entry.next = (next != null) ? (TableEntry)next.clone() : null;
      return entry;
    }
  }



}
